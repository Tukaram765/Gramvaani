<?php
include 'connection.inc.php';


function generateRandomPassword($length = 12) {
    return bin2hex(random_bytes($length / 2));
}
$password = generateRandomPassword(12);

$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

$to = 'badboyrocky197@gmail.com'; 
$subject = 'Your New Password';
$message = "Hello,\n\nYour new password is: $password\n\nPlease keep it safe.";
$headers = "From: admin@yourwebsite.com\r\n";
$headers .= "Reply-To: support@yourwebsite.com\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

if (mail($to, $subject, $message, $headers)) {
    echo "A new password has been sent to your email.";
} else {
    echo "Failed to send email.";
}
?>



?>