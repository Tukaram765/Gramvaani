<?php
// error_reporting(0);
include 'connection.inc.php';
if(isset($_POST['mobile'])){

     $name=$_POST['name']?? '';
     $email=$_POST['email']?? '';
     $gender = $_POST['gender'];
     $mobile=$_POST['mobile']?? '';
     $address=$_POST['address']?? '';
     $city=$_POST['city']?? '';
     $state=$_POST['state']?? '';
     $taluk=$_POST['taluk']?? '';
     $pincode=$_POST['pincode']?? '';
     $complaint_title=$_POST['complaint_title']?? '';
     $issue=$_POST['issue']?? '';
     $issue_detail=$_POST['issue_detail']?? '';
     $priority=$_POST['priority']?? '';
     $accused_name = $_POST['accused_name']?? '';
     $accused_gender = $_POST['accused_gender']?? '';
     $accused_age = $_POST['accused_age']?? '';
     $accused_address = $_POST['accused_address']?? '';
     $accused_mobile = $_POST['accused_mobile']?? '';
     $accused_desigantion = $_POST['accused_desigantion']?? '';

     $fileI = null;
     $totalFiles = count($_FILES['images']['name']);

     for ($i = 0; $i < $totalFiles; $i++) {
         $fileName = $_FILES['images']['name'][$i];
         $fileTmpName = $_FILES['images']['tmp_name'][$i];
         $fileSize = $_FILES['images']['size'][$i];
         $fileError = $_FILES['images']['error'][$i];
         $fileType = $_FILES['images']['type'][$i];
   
   
         $allowed = ['jpg', 'jpeg', 'png', 'gif'];
         $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
   
         if (in_array($fileExt, $allowed)) {
             if ($fileError === 0) {
                 if ($fileSize < 5000000) {
                     $fileNewName = uniqid('', true) . "." . $fileExt;
                     $fileDestination = 'uploads/images/' . $fileNewName;
   
                     if (move_uploaded_file($fileTmpName, $fileDestination)) {
                        $fileI = $fileDestination;
                    
                     } else {
                        $fileI  = null;
                    }
                }
            }
        }
    }
    
   $fileA = null;
    $totalaudios = count($_FILES['audio']['name']);
   
    for($i = 0; $i<$totalaudios; $i++){
        $fileName = $_FILES['audio']['name'][$i];
        $fileTmpName = $_FILES['audio']['tmp_name'][$i];
        $fileSize = $_FILES['audio']['size'][$i];
        $fileError = $_FILES['audio']['error'][$i];
        $fileType = $_FILES['audio']['type'][$i];
   
        $allowed = ['mp3','wav','aac','m4a','falc'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
   
        if(in_array($fileExt, $allowed)){
   
            if($fileError===0){
                if($fileSize<10485760){
                    $fileNewName = uniqid('',true)."." .$fileExt;
                    $fileDestination = 'uploads/audios/' . $fileNewName;
   
                    if(move_uploaded_file($fileTmpName,$fileDestination)){
                        $fileA = $fileDestination;


                    }else{
                        $fileA = null;
                    }
                }
            }
        }
   
    }
   
  
   
    $fileV = null;
        $totalVideos = count($_FILES['videos']['name']);
    
        for ($i = 0; $i < $totalVideos; $i++) {
            $fileName = $_FILES['videos']['name'][$i];
            $fileTmpName = $_FILES['videos']['tmp_name'][$i];
            $fileSize = $_FILES['videos']['size'][$i];
            $fileError = $_FILES['videos']['error'][$i];
            $fileType = $_FILES['videos']['type'][$i];
    
   
            $allowed = ['mp4', 'avi', 'mkv', 'm4v', 'mov', '3gp'];
    
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
   
            if (in_array($fileExt, $allowed)) {
                if ($fileError === UPLOAD_ERR_OK) {
                    if ($fileSize < 15728640) {
                        $fileNewName = uniqid('', true) . "." . $fileExt; 
                        $fileDestination = 'uploads/videos/' . $fileNewName; 
    
                        if (move_uploaded_file($fileTmpName, $fileDestination)) {
                            $fileV = $fileDestination;
                        } else {
                            $fileV = null;
                        }
                    }
                }
            }
        }
    }

$lastname = substr($name,0,4);
$lastnum = substr($mobile,-4);
$password = $lastname . "@" . $lastnum;
$GLOBALS['password'];

function generateUniqueNumber() {
    return mt_rand(100000000000, 999999999999); 
  }
  $uniqueNumber = generateUniqueNumber();
  $GLOBALS['uniqueNumber'];

$check_user = $conn->query("SELECT * FROM `Users` WHERE `username`='$name' OR `phone`='$mobile'");

if ($check_user->num_rows > 0) {  echo "<script type='text/javascript'>
    alert('User already exists! Please Login.');
    setTimeout(function() {
        window.location.href = '../../login.php';
    }, 0000);
  </script>";

    // echo "<script type='text/javascript'>alert('User already exists! Please Login.');</script>";
    // header("Location: ../../login.php");

} elseif ($check_user->num_rows == 0) {
    $sql = "INSERT INTO `users`(`username`, `gender`, `email`, `phone`,`pass`, `address`, `city`, `state`, `taluk`, `pincode`) VALUES('$name','$gender','$email','$mobile','$password','$address','$city','$state','$taluk','$pincode')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script type='text/javascript'>alert('created successfully!');</script>";

        // echo <<<HTML


        // <form action="">
        //     <h2>Complaint Registered Successfully!</h2>
        //     <p>Password: $password</p>
        //     <p>Complaint Id: $uniqueNumber</p>
        //     <button type="button">Print</button>
        // </form>



        // HTML;
        
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }


// function generateUniqueNumber() {
//   return mt_rand(100000000000, 999999999999); 
// }
// $uniqueNumber = generateUniqueNumber();
// $GLOBALS['uniqueNumber'];

$check_user = $conn->query("select * from `complaints` where `complaint_id`='$uniqueNumber'");


if($check_user->num_rows>0){
 echo "<script type ='text/javascript'>alert('Complanint ID Exists!');</script>";

}else{
  $complaint_check = $conn->query("SELECT * FROM `Users` WHERE `username`='$name' OR `phone`='$mobile'");

  if ($complaint_check) {
      while ($row = $complaint_check->fetch_assoc()) {
          $user_id = $row['user_id'];
          $phone = $row['phone'];
      }
  } 
  $sql = "INSERT INTO `complaints` (`user_id`, `complaint_id`, `complaint_title`, `issue`, `issue_detail`, `priority`, `audio`, `image`, `video`, `status`, `filed_at`, `updated_at`) VALUES ('$user_id', '$uniqueNumber', '$complaint_title', '$issue', '$issue_detail', '$priority', '$fileA', '$fileI', '$fileV', 'pending', NOW(), NOW())";
  

if ($conn->query($sql) === TRUE) {
    // echo "<script type='text/javascript'>alert('Inserted!');</script>";
} else {
    echo "Error: " . $conn->error;
}
$accused_data ="INSERT INTO `accused_data`(`complaint_id`,`accused_name`, `accused_gender`, `accused_age`, `accused_address`, `accused_mobile`, `accused_designation`) VALUES ('$uniqueNumber','$accused_name','$accused_gender','$accused_age','$accused_address','$accused_mobile','$accused_desigantion')";
if($conn->query($accused_data)==TRUE){
    // echo "<script type='text/javascript'>alert('Inserted!');</script>";
}else{
    echo "Error: " . $conn->error;
}
  } 
  }
     
?>

<!DOCTYPE html>
<!--
 =========================================================
* Soft UI Dashboard PRO - v1.1.1
=========================================================

* Product Page:  https://www.creative-tim.com/product/soft-ui-dashboard-pro 
* Copyright 2023 Creative Tim (https://www.creative-tim.com)
* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
-->
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="apple-touch-icon" sizes="76x76" href="../../images/g_logo.png">
<link rel="icon" type="image/png" href="../../images/g_logo.png">
<title>
    Complaint Acknoledgement
  </title>


<link rel="canonical" href="https://www.creative-tim.com/product/soft-ui-dashboard-pro">

<meta name="keywords" content="creative tim, html dashboard, html css dashboard, web dashboard, bootstrap 5 dashboard, bootstrap 5, css3 dashboard, bootstrap 5 admin, soft ui dashboard bootstrap 5 dashboard, frontend, responsive bootstrap 5 dashboard, soft design, soft dashboard bootstrap 5 dashboard">
<meta name="description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">

<meta name="twitter:card" content="product">
<meta name="twitter:site" content="@creativetim">
<meta name="twitter:title" content="Soft UI Dashboard PRO by Creative Tim">
<meta name="twitter:description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">
<meta name="twitter:creator" content="@creativetim">
<meta name="twitter:image" content="https://s3.amazonaws.com/creativetim_bucket/products/487/thumb/opt_sdp_thumbnail.jpg">

<meta property="fb:app_id" content="655968634437471">
<meta property="og:title" content="Soft UI Dashboard PRO by Creative Tim">
<meta property="og:type" content="article">
<meta property="og:url" content="https://demos.creative-tim.com/soft-ui-dashboard-pro/pages/dashboards/default.html">
<meta property="og:image" content="https://s3.amazonaws.com/creativetim_bucket/products/487/thumb/opt_sdp_thumbnail.jpg">
<meta property="og:description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">
<meta property="og:site_name" content="Creative Tim">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

<link href="../../complaintAcknoledgement/css/css-nucleo-icons.css" rel="stylesheet">
<link href="../../complaintAcknoledgement/css/css-nucleo-svg.css" rel="stylesheet">

<script src="../../complaintAcknoledgement/js/42d5adcbca.js" crossorigin="anonymous"></script>
<link href="../../complaintAcknoledgement/css/css-nucleo-svg.css" rel="stylesheet">

<link id="pagestyle" href="../../complaintAcknoledgement/css/css-soft-ui-dashboard.min.css" rel="stylesheet">

<style>
    .async-hide {
      opacity: 0 !important
    }
  </style>
</head>
<body class="g-sidenav-show bg-gray-100">


<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKDMSK6" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>


<main class="main-content max-height-vh-100 h-100">
<nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl  position-sticky mt-4 top-1 z-index-sticky" id="navbarBlur" data-scroll="true">
<div class="container-fluid py-1 px-3">
<nav aria-label="breadcrumb">
<ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
<li class="breadcrumb-item text-sm">
<a class="opacity-3 text-dark" href="javascript:;.html">
<svg width="12px" height="12px" class="mb-1" viewbox="0 0 45 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<title>Complaint Acknoledgement</title>
<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
<g transform="translate(-1716.000000, -439.000000)" fill="#252f40" fill-rule="nonzero">
<g transform="translate(1716.000000, 291.000000)">
<g transform="translate(0.000000, 148.000000)">
</g>
</g>
</g>
</g>
</svg>
</a>
</li>
</ol>

</nav>
<div class="sidenav-toggler sidenav-toggler-inner d-xl-block d-none me-auto">
<a href="javascript:;.html" class="nav-link text-body p-0">
</a>
</div>
<div class="collapse navbar-collapse me-md-0 me-sm-4 mt-sm-0 mt-2" id="navbar">
<ul class="navbar-nav justify-content-end ms-auto">
<li class="nav-item d-xl-none ps-3 pe-0 d-flex align-items-center">
<a href="javascript:;.html" class="nav-link text-body p-0" id="iconNavbarSidenav">
<div class="sidenav-toggler-inner">
<i class="sidenav-toggler-line"></i>
<i class="sidenav-toggler-line"></i>
<i class="sidenav-toggler-line"></i>
</div>
</a>
</li>
</ul>
</div>
</div>
</nav>
<div  class="acknolodgement container-fluid my-3 py-3">
<div class="row">
<div class="col-md-8 col-sm-10 mx-auto">
<form class action="index.html" method="post">
<div id="acknolodgement" class="card my-sm-5">
<div class="card-header text-center">
<div class="row justify-content-between">
<div class="col-md-4 text-start">
<h6  class="font-weight-bolder ps-20">Complaint Acknoledgement</h6>
<img class="mb-2 w-25 p-2" src="../../images/g_logo.png" alt="Logo">
<h6>
<?php echo $name?>,<?php echo $email?><br>
<?php echo $address?>
</h6>
<p class="d-block text-secondary">tel: <?php echo $phone?></p>
</div>
<div class="col-lg-3 col-md-7 text-md-end text-start mt-5">
<h6 class="d-block mt-2 mb-0"><?php echo $accused_name?></h6>
<p class="text-secondary"><?php echo $accused_desigantion?><br>
<?php echo $accused_address?><br>
tel: <?php echo $accused_mobile?>
</p>
</div>
</div>
<br>
<div class="row justify-content-md-between">
<div class="col-md-4 mt-auto">
<h6 class="mb-0 text-start text-secondary">
Complaint Id:
</h6>
<h6 class="text-start mb-0">
<?php echo $uniqueNumber?>
</h6>
<h6 class="mb-0 text-start text-secondary">
Password:
</h6>
<h6 class="text-start mb-0">
<?php echo $password?>
</h6>
</div>
<div class="col-lg-5 col-md-7 mt-auto">
<div class="row mt-md-5 mt-4 text-md-end text-start">
<div class="col-md-6">
<h6 class="text-secondary mb-0">state:</h6>
</div>
<div class="col-md-6">
<h6 class="text-dark mb-0"><?php echo $state?></h6>
</div>
</div>
<div class="row text-md-end text-start">
<div class="col-md-6">
<h6 class="text-secondary mb-0">City:</h6>
</div>
<div class="col-md-6">
<h6 class="text-dark mb-0"><?php echo $city?></h6>
</div>
</div>
</div>
</div>
</div>
<div class="card-body">
<div class="row">
<div class="col-12">
<div class="table-responsive">
<table class="table text-right">
<thead class="bg-default">
<tr>
<th scope="col" class="pe-2 text-start ps-2">Complaint Details:</th>
</tr>
</thead>
<tbody>
<tr>
<td class="text-start">Complaint Title:</td>
<td class="ps-4"><?php echo $complaint_title?></td>
</tr>
<tr>
<td class="text-start">Problem:</td>
<td class="ps-4"><?php echo $issue?></td>
</tr>
<tr>
<td class="text-start">Problem description:</td>
<td class="ps-4"><textarea id="issuedescription" cols="50" rows="20" style="border: none;"><?php echo $issue_detail?></textarea></td>
</tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
<div class="card-footer mt-md-5 mt-2">
<div class="row">
<div class="col-lg-5 text-left">
<h5>Thank you!</h5>
<p class="text-secondary text-sm">If you want to know your Complaint status check websiste:</p>
<h6 class="text-secondary mb-0">
email:
<span class="text-dark"><a href="email-protection.html" class="__cf_email__" data-cfemail="07747277776875734764756266736e71622a736e6a2964686a">[email&nbsp;protected]</a></span>
</h6>
</div>

</div>
</div>
</div>
<div class="col-lg-7 text-md-end mt-md-0 mt-3">
<button class="btn bg-gradient-info mt-lg-7 mb-0" onclick="printDiv()" type="button" name="button">Print</button>
</div>
</form>
</div>
</div>
<footer class="footer pt-3  ">
<div class="container-fluid">
<div class="row align-items-center justify-content-lg-between">
<div class="col-lg-6 mb-lg-0 mb-4">
<div class="copyright text-center text-sm text-muted text-lg-start">
&copy; <script data-cfasync="false" src="../../complaintAcknoledgement/js/cloudflare-static-email-decode.min.js"></script><script>
                  document.write(new Date().getFullYear())
                </script>,
made with <i class="fa fa-heart"></i> by
<a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Zilitech</a>
for a better web.
</div>
</div>
<div class="col-lg-6">
<ul class="nav nav-footer justify-content-center justify-content-lg-end">
<li class="nav-item">
<a href="https://www.creative-tim.com" class="nav-link text-muted" target="_blank">Zilitech</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/presentation" class="nav-link text-muted" target="_blank">About Us</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/blog" class="nav-link text-muted" target="_blank">Blog</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/license" class="nav-link pe-0 text-muted" target="_blank">License</a>
</li>
</ul>
</div>
</div>
</div>
</footer>
</div>
</main>
<div class="fixed-plugin">
<a class="fixed-plugin-button text-dark position-fixed px-3 py-2" href="account.html">
<i class="fa fa-cog py-2"> </i>
</a>
<div class="card shadow-lg blur">
<div class="card-header pb-0 pt-3  bg-transparent ">
<div class="float-start">
<h5 class="mt-3 mb-0">Soft UI Configurator</h5>
<p>See our dashboard options.</p>
</div>
<div class="float-end mt-4">
<button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
<i class="fa fa-close"></i>
</button>
</div>

</div>
<hr class="horizontal dark my-1">
<div class="card-body pt-sm-3 pt-0">

<div>
<h6 class="mb-0">Sidebar Colors</h6>
</div>
<a href="javascript:void(0)" class="switch-trigger background-color">
<div class="badge-colors my-2 text-start">
<span class="badge filter bg-gradient-primary active" data-color="primary" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-dark" data-color="dark" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-info" data-color="info" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-success" data-color="success" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-warning" data-color="warning" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-danger" data-color="danger" onclick="sidebarColor(this)"></span>
</div>
</a>

<div class="mt-3">
<h6 class="mb-0">Sidenav Type</h6>
<p class="text-sm">Choose between 2 different sidenav types.</p>
</div>
<div class="d-flex">
<button class="btn bg-gradient-primary w-100 px-3 mb-2 active" data-class="bg-transparent" onclick="sidebarType(this)">Transparent</button>
<button class="btn bg-gradient-primary w-100 px-3 mb-2 ms-2" data-class="bg-white" onclick="sidebarType(this)">White</button>
</div>
<p class="text-sm d-xl-none d-block mt-2">You can change the sidenav type just on desktop view.</p>

<div class="mt-3">
<h6 class="mb-0">Navbar Fixed</h6>
</div>
<div class="form-check form-switch ps-0">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarFixed" onclick="navbarFixed(this)">
</div>
<hr class="horizontal dark mb-1 d-xl-block d-none">
<div class="mt-2 d-xl-block d-none">
<h6 class="mb-0">Sidenav Mini</h6>
</div>
<div class="form-check form-switch ps-0 d-xl-block d-none">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarMinimize" onclick="navbarMinimize(this)">
</div>
<hr class="horizontal dark mb-1 d-xl-block d-none">
<div class="mt-2 d-xl-block d-none">
<h6 class="mb-0">Light/Dark</h6>
</div>
<div class="form-check form-switch ps-0 d-xl-block d-none">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="dark-version" onclick="darkMode(this)">
</div>
<hr class="horizontal dark my-sm-4">
<a class="btn bg-gradient-info w-100" href="https://www.creative-tim.com/product/soft-ui-dashboard-pro">Buy now</a>
<a class="btn bg-gradient-dark w-100" href="https://www.creative-tim.com/product/soft-ui-dashboard">Free demo</a>
<a class="btn btn-outline-dark w-100" href="https://www.creative-tim.com/learning-lab/bootstrap/overview/soft-ui-dashboard">View documentation</a>
<div class="w-100 text-center">
<a class="github-button" href="https://github.com/creativetimofficial/ct-soft-ui-dashboard-pro" data-icon="octicon-star" data-size="large" data-show-count="true" aria-label="Star creativetimofficial/soft-ui-dashboard on GitHub">Star</a>
<h6 class="mt-3">Thank you for sharing!</h6>
<a href="https://twitter.com/intent/tweet?text=Check%20Soft%20UI%20Dashboard%20PRO%20made%20by%20%40CreativeTim%20%23webdesign%20%23dashboard%20%23bootstrap5&amp;url=https%3A%2F%2Fwww.creative-tim.com%2Fproduct%2Fsoft-ui-dashboard-pro" class="btn btn-dark mb-0 me-2" target="_blank">
<i class="fab fa-twitter me-1" aria-hidden="true"></i> Tweet
</a>
<a href="https://www.facebook.com/sharer/sharer.php?u=https://www.creative-tim.com/product/soft-ui-dashboard-pro" class="btn btn-dark mb-0 me-2" target="_blank">
<i class="fab fa-facebook-square me-1" aria-hidden="true"></i> Share
</a>
</div>
</div>
</div>
</div>

<script src="../../complaintAcknoledgement/js/core-popper.min.js"></script>
<script src="../../complaintAcknoledgement/js/core-bootstrap.min.js"></script>
<script src="../../complaintAcknoledgement/js/plugins-perfect-scrollbar.min.js"></script>
<script src="../../complaintAcknoledgement/js/plugins-smooth-scrollbar.min.js"></script>

<script src="../../complaintAcknoledgement/js/dragula-dragula.min.js"></script>
<script src="../../complaintAcknoledgement/js/jkanban-jkanban.js"></script>
<script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>

<script async defer src="../../complaintAcknoledgement/js/buttons.github.io-buttons.js"></script>

<script src="../../complaintAcknoledgement/js/js-soft-ui-dashboard.min.js"></script>
</body>
</html>

<script>
function printDiv() {
    var printContents = document.getElementById('acknolodgement').innerHTML;
    var originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;

    window.print();

    document.body.innerHTML = originalContents;
    location.reload(); // Reload to restore the original content
}
</script>




    
  





  
