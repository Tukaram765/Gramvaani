<?php
// Include database connection
include('db_connection.php'); 

// Start session if user is logged in
session_start();

if (!isset($_SESSION['user_id'])) {
    // Redirect if the user is not logged in
    header("Location: login.php");
    exit();
}

// Get user data from the database
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Check if form is submitted
if (isset($_POST['update'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Update user data in the database
    $update_query = "UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param("sssi", $name, $email, $password, $user_id);

    if ($stmt->execute()) {
        // Send email with the updated password
        $to = $email;
        $subject = "Your Profile Has Been Updated";
        $message = "Hello $name,\n\nYour profile has been successfully updated. Here are your updated details:\n\n";
        $message .= "Name: $name\nEmail: $email\nPassword: $password\n\n";
        $message .= "If you did not request this update, please contact support immediately.";

        // Headers for email
        $headers = "From: admin@yourwebsite.com\r\n";
        $headers .= "Reply-To: support@yourwebsite.com\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

        // Send the email
        if (mail($to, $subject, $message, $headers)) {
            echo "Profile updated successfully! A confirmation email has been sent.";
        } else {
            echo "Profile updated, but failed to send email.";
        }
    } else {
        echo "Error updating profile: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile</title>
</head>
<body>
    <h2>Edit Profile</h2>

    <form method="POST" action="">
        <label for="name">Name:</label>
        <input type="text" name="name" value="<?php echo $user['name']; ?>" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo $user['email']; ?>" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" value="<?php echo $user['password']; ?>" required><br>

        <button type="submit" name="update">Update Profile</button>
    </form>
</body>
</html>