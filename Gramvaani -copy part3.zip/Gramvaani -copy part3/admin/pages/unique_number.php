<?php

include 'connection.inc.php';


// Function to generate unique 12-digit number
function generateUniqueNumber() {
    // Generate a 12-digit number using a random number generator
    // Using mt_rand ensures the number is pseudo-random
    return mt_rand(100000000000, 999999999999); // Generates a 12-digit number
}
echo $uniqueNumber = generateUniqueNumber();

// Check if the number is unique in the database
// function isNumberUnique($conn, $uniqueNumber) {
//     $sql = "SELECT COUNT(*) FROM `complaints` where `complaints_id`='1234'";
//     $stmt = $conn->prepare($sql);
//     $stmt->execute(['complaints_id' => $uniqueNumber]);
//     return $stmt->fetchColumn() == 0;
// }

// // Generate and insert a unique 12-digit number
// function insertUniqueNumber($conn) {
//     do {
//         // Generate a number
//        echo $uniqueNumber = generateUniqueNumber();
//     } while (!isNumberUnique($conn, $uniqueNumber)); // Loop until a unique number is found

//     // Insert the unique number into the database
//     $sql = "INSERT INTO complaints VALUES complaints_id ";
//     $stmt = $conn->prepare($sql);
//     $stmt->execute(['complaints_id' => $uniqueNumber]);

//     echo "The unique 12-digit number $uniqueNumber has been inserted into the database.<br>";
// }

// // Insert the generated unique number
// insertUniqueNumber($conn);
// ?>