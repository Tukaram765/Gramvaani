<?php
session_start();
ob_start();
    

include '../templates/connection.inc.php';
echo $phone=$_SESSION['phone'];

if(isset($_POST['complaint_title'])){
 echo $complaint_title = $_POST['complaint_title']?? '';
  $issue = $_POST['issue']?? '';
  $issue_detail = $_POST['issue_detail']?? '';
  $priority = $_POST['priority']?? '';
  $accused_name = $_POST['accused_name'];
  $accused_gender = $_POST['accused_gender'];
  $accused_age = $_POST['accused_age'];
  $accused_address = $_POST['accused_address'];
  $accused_mobile = $_POST['accused_mobile'];
  $accused_desigantion = $_POST['accused_desigantion'];

    $fileI = null;
     $totalFiles = count($_FILES['images']['name']);

     for ($i = 0; $i < $totalFiles; $i++) {
         $fileName = $_FILES['images']['name'][$i];
         $fileTmpName = $_FILES['images']['tmp_name'][$i];
         $fileSize = $_FILES['images']['size'][$i];
         $fileError = $_FILES['images']['error'][$i];
         $fileType = $_FILES['images']['type'][$i];
   
   
         $allowed = ['jpg', 'jpeg', 'png', 'gif'];
         $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
   
         if (in_array($fileExt, $allowed)) {
             if ($fileError === 0) {
                 if ($fileSize < 5000000) {
                     $fileNewName = uniqid('', true) . "." . $fileExt;
                     $fileDestination = 'uploads/images/' . $fileNewName;
   
                     if (move_uploaded_file($fileTmpName, $fileDestination)) {
                        $fileI = $fileDestination;
                        $fileI = $_FILES['fileI'];
                     } else {
                        $fileI  = null;
                    }
                }
            }
        }
    }
    
   $fileA = null;
    $totalaudios = count($_FILES['audio']['name']);
   
    for($i = 0; $i<$totalaudios; $i++){
        $fileName = $_FILES['audio']['name'][$i];
        $fileTmpName = $_FILES['audio']['tmp_name'][$i];
        $fileSize = $_FILES['audio']['size'][$i];
        $fileError = $_FILES['audio']['error'][$i];
        $fileType = $_FILES['audio']['type'][$i];
   
        $allowed = ['mp3','wav','aac','m4a','falc'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
   
        if(in_array($fileExt, $allowed)){
   
            if($fileError===0){
                if($fileSize<10485760){
                    $fileNewName = uniqid('',true)."." .$fileExt;
                    $fileDestination = 'uploads/audios/' . $fileNewName;
   
                    if(move_uploaded_file($fileTmpName,$fileDestination)){
                        $fileA = $fileDestination;


                    }else{
                        $fileA = null;
                    }
                }
            }
        }
   
    }
   
  
   
    $fileV = null;
        $totalVideos = count($_FILES['videos']['name']);
    
        for ($i = 0; $i < $totalVideos; $i++) {
            $fileName = $_FILES['videos']['name'][$i];
            $fileTmpName = $_FILES['videos']['tmp_name'][$i];
            $fileSize = $_FILES['videos']['size'][$i];
            $fileError = $_FILES['videos']['error'][$i];
            $fileType = $_FILES['videos']['type'][$i];
    
   
            $allowed = ['mp4', 'avi', 'mkv', 'm4v', 'mov', '3gp'];
    
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
   
            if (in_array($fileExt, $allowed)) {
                if ($fileError === UPLOAD_ERR_OK) {
                    if ($fileSize < 15728640) {
                        $fileNewName = uniqid('', true) . "." . $fileExt; 
                        $fileDestination = 'uploads/videos/' . $fileNewName; 
    
                        if (move_uploaded_file($fileTmpName, $fileDestination)) {
                            $fileV = $fileDestination;
                        } else {
                            $fileV = null;
                        }
                    }
                }
            }
        }
    


function generateUniqueNumber() {
    return mt_rand(100000000000, 999999999999); 
  }
  echo $uniqueNumber = generateUniqueNumber();
  echo $GLOBALS['uniqueNumber'];



    $check_user = $conn->query("select * from `complaints` where `complaint_id`='$uniqueNumber'");


if($check_user->num_rows>0){
 echo "<script type ='text/javascript'>alert('Complanint ID Exists!');</script>";
 

}else{
  $complaint_check = $conn->query("SELECT * FROM `users` WHERE `phone`='$phone'");
  $user_id = null;

  if ($complaint_check) {
      while ($row = $complaint_check->fetch_assoc()) {
          $user_id = $row['user_id'];
      }
    }
   
  $sql = "INSERT INTO `complaints` (`user_id`, `complaint_id`, `complaint_title`, `issue`, `issue_detail`, `priority`, `audio`, `image`, `video`, `status`, `filed_at`, `updated_at`) VALUES ('$user_id', '$uniqueNumber', '$complaint_title', '$issue', '$issue_detail', '$priority', '$fileA', '$fileI', '$fileV', 'pending', NOW(), NOW())";
  

if ($conn->query($sql) == true) {
    echo "<script type='text/javascript'>
    alert('Complaint Registered Successfully!');
    setTimeout(function() {
        window.location.href = '../admin/pages/user_dashboard.php';
    }, 0000);
  </script>";
} else {
    echo "Error: " . $conn->error;
}
  }
}






?>


