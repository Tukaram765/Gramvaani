<?php

  // Page vars    
  $__title      = "Sign in - Gramvaani.com";
  $__meta_title = "Gramvaani ";    
  $__meta_description = "Login in now";
  $__meta_keywords    = "Gramvaani, Raise the Complaints,Track the complaints, feedback";

  // Page class & id
  $__class  = "login-page";
  $__id     = "login-page";

  // Change between (true) and (false) to show or hide (Header, Footer, Live Chat Bubble).
  $__hide_header      = 'true';
  $__hide_footer      = 'true';
  $__hide_chat_bubble = 'true';

  // Include (init.php) file.
  include 'core/init.php';
      
?>

  <!-- Section I -->
  <div class="se-i">
    <!-- user-form -->
    <form class="user-form" action="#" method="POST" id="login-form" style="margin-left: 40%;">
      <!-- logo -->
      <a href="index.php" class="logo">
      <img src="images/g_logow.png" class="dt-img img-fluid" alt="Gramvaani">
      <img src="images/g_logo.png" class="lt-img img-fluid" alt="Gramvaani">
      </a>
      <!-- title-1 -->
      <h1 class="title-1"><img data-src="assets/images/pages/user/waving-hand.png" class="lazy img-fluid" alt="Icon">User Login</h1>
      <!-- form-label -->
      <label class="form-label" for="email">
        <!-- form-input -->
        <input class="form-input" type="number" name="phone" id="phone" placeholder="Enter phone No." required>
        <!-- state -->
        <span class="state"></span>
      </label>
      <!-- form-label -->
      <label class="form-label" for="password">
        <!-- form-input -->
        <input class="form-input" type="password" name="pass" id="password" placeholder="Password">
        <!-- state -->
        <span class="state"></span>
      </label>
      <!-- div -->
      <div class="text-right">
        <!-- pass-link -->
        <a href="reset-pass.php" class="pass-link">Forget Password?</a>
      </div>
      <!-- buttons -->
      <div class="buttons mt-2">
        <button type="submit" class="btn btn-sm btn-fill-success shadow-off text-uppercase w-100">Sign In</button>
      </div>
      <!-- or -->
      <div class="or mt-3 mb-3 text-center"><span>or</span></div>
      <!-- social-links -->
      <div class="social-links d-flex align-items-center justify-content-center">
        <!-- social-link -->
        <a href="https://r.search.yahoo.com/_ylt=Awr1TeRXFO1mDQIAV3G7HAx.;_ylu=Y29sbwNzZzMEcG9zAzEEdnRpZAMEc2VjA3Ny/RV=2/RE=1728022872/RO=10/RU=https%3a%2f%2fwww.facebook.com%2fzilitech%2f/RK=2/RS=iHCPbRV3e1u_sniI913oti8SsUQ-" class="social-link">
          <img data-src="assets/images/pages/user/facebook.svg"  class="lazy img-fluid" alt="Gramvaani">
        </a>
        <!-- social-link -->
        <a href="https://zilitech.com/" class="social-link">
          <img data-src="assets/images/pages/user/google.svg" class="lazy img-fluid" alt="Gramvaani">
        </a>
        <!-- social-link -->
        <a href="#" class="social-link">
          <img data-src="assets/images/pages/user/twitter.svg" class="lazy img-fluid" alt="Gramvaani">
        </a>
      </div>
      <!-- comment -->
      <p class="comment text-center" style="margin-left: 40%;">New to Gramvaani? <a href="register.php">Sign up</a></p>
    </form>
    <form id="otp-form" style="display: none;">
    <input type="text" id="otp" placeholder="Enter OTP" required>
    <button type="submit">Verify OTP</button>
</form>
    <!-- text -->
    <div class="text">
      <!-- links -->
      <div class="links d-flex align-items-center justify-content-lg-start justify-content-center">
        <a href="index.php" class="d-inline-flex">Home</a>
        <a href="kb-2.php" class="d-inline-flex">Help Center</a>
        <a href="terms.php" class="d-inline-flex">Privacy Policy</a>
      </div>
      <!-- para-3 -->
      <!-- <p class="para-3">Use of this Site is subject to express terms of use.<br>By using this site, you signify that you agree to be bound by these <a href="terms.php">Universal Terms of Service</a>.</p> -->
    </div>
  </div>

<?php
  // Footer
  include 'templates/footer.inc.php';
?>

<!-- <a href="./admin/pages/user_dashboard.php" -->

<?php

include 'templates/connection.inc.php';
?>

<?php


if($_SERVER['REQUEST_METHOD']=='POST'){
 $phone = $conn->real_escape_string($_POST['phone']);
  $pass = $conn->real_escape_string($_POST['pass']);


  $result = $conn->query("SELECT * FROM `users` WHERE `phone`='$phone'");
  if($result){
    while($user= $result->fetch_assoc()){

     $dpass = $user['pass'];
       $_SESSION['phone'] = $user['phone'];
    
      // $row=base64_decode($dpass);
      // $databasepass = openssl_decrypt($row,'aes-256-cbc',OPENSSL_RAW_DATA);

      if( $pass == $dpass){
        echo "<script type ='text/javascript'>alert('Login Successfull!');</script>";
        header("Location:./admin/pages/user_dashboard.php");
        
        
          // }
        
        
      }else{
        echo "<script type ='text/javascript'>alert('Invalid password!');</script>";
      }
        
      }

    }
  }
   


    
  // }else{
  //   echo "<script type ='text/javascript'>alert('user not found!');</script>";
  // }

$conn->close();


?>

<script>


document.getElementById('login-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const phoneNumber = document.getElementById('phone').value;

    // Send request to your server to generate and send OTP
    const response = await fetch('/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber })
    });

    if (response.ok) {
        // Show OTP form after sending OTP
        document.getElementById('login-form').style.display = 'none';
        document.getElementById('otp-form').style.display = 'block';
    } else {
        // Handle error (e.g., invalid phone number)
    }
});

</script>

<script>
document.getElementById('otp-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const otp = document.getElementById('otp').value;

    // Send request to your server to verify the OTP
    const response = await fetch('/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ otp })
    });

    if (response.ok) {
        // Successful login
        // Redirect or show success message
    } else {
        // Handle error (e.g., invalid OTP)
    }
});





</script>
<script>

app.post('/send-otp', async (req, res) => {
    const { phoneNumber } = req.body;

    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    await saveOtpToDatabase(phoneNumber, otp);

    await sendSms(phoneNumber, `Your OTP is ${otp}`);

    res.status(200).send({ message: 'OTP sent successfully' });
});

</script>
<script>

app.post('/verify-otp', async (req, res) => {
    const { phoneNumber, otp } = req.body;

    const validOtp = await verifyOtpFromDatabase(phoneNumber, otp);
    
    if (validOtp) {
        res.status(200).send({ message: 'Login successful' });
    } else {
        res.status(400).send({ message: 'Invalid or expired OTP' });
    }
});

  </script>