
<?php
session_start();

include '../templates/connection.inc.php';


if(isset($_SESSION['complaint_id'])){
   $complaint_id = $_SESSION['complaint_id'];


 $getcomplaintid =$conn->query("SELECT * FROM `complaints` WHERE `complaint_id` = '$complaint_id'");

    $uploadcomplaintdata = [];
    if($getcomplaintid->num_rows>0){
    while($row = $getcomplaintid->fetch_assoc()){
       $uploadcomplaintdata[] = $row;
        
    }
    
    }


}





?>

<?php
$getassigned = $conn->query("SELECT * FROM `employee_complaints` WHERE `complaint_id` = '$complaint_id' ");
$uploadassigned = [];
if($getassigned->num_rows>0){
    while($row = $getassigned->fetch_assoc()){
      $uploadassigned[] = $row;
    }
}
?>

<!DOCTYPE html>
<!--
=========================================================
* Soft UI Dashboard PRO - v1.1.1
=========================================================

* Product Page:  https://www.creative-tim.com/product/soft-ui-dashboard-pro 
* Copyright 2023 Creative Tim (https://www.creative-tim.com)
* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
--><html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="apple-touch-icon" sizes="76x76" href="../images/g_logo.png">
<link rel="icon" type="image/png" href="../images/g_logo.png">
<title>
    Track Your Complaints
  </title>


<link rel="canonical" href="https://www.creative-tim.com/product/soft-ui-dashboard-pro">

<meta name="keywords" content="creative tim, html dashboard, html css dashboard, web dashboard, bootstrap 5 dashboard, bootstrap 5, css3 dashboard, bootstrap 5 admin, soft ui dashboard bootstrap 5 dashboard, frontend, responsive bootstrap 5 dashboard, soft design, soft dashboard bootstrap 5 dashboard">
<meta name="description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">

<meta name="twitter:card" content="product">
<meta name="twitter:site" content="@creativetim">
<meta name="twitter:title" content="Soft UI Dashboard PRO by Creative Tim">
<meta name="twitter:description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">
<meta name="twitter:creator" content="@creativetim">
<meta name="twitter:image" content="https://s3.amazonaws.com/creativetim_bucket/products/487/thumb/opt_sdp_thumbnail.jpg">

<meta property="fb:app_id" content="655968634437471">
<meta property="og:title" content="Soft UI Dashboard PRO by Creative Tim">
<meta property="og:type" content="article">
<meta property="og:url" content="https://demos.creative-tim.com/soft-ui-dashboard-pro/pages/dashboards/default.html">
<meta property="og:image" content="https://s3.amazonaws.com/creativetim_bucket/products/487/thumb/opt_sdp_thumbnail.jpg">
<meta property="og:description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">
<meta property="og:site_name" content="Creative Tim">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

<link href="css/css-nucleo-icons.css" rel="stylesheet">
<link href="css/css-nucleo-svg.css" rel="stylesheet">

<script src="js/42d5adcbca.js" crossorigin="anonymous"></script>
<link href="css/css-nucleo-svg.css" rel="stylesheet">

<link id="pagestyle" href="css/css-soft-ui-dashboard.min.css" rel="stylesheet">

<style>
    .async-hide {
      opacity: 0 !important
    }
  </style>
</head>
<body class="g-sidenav-show  bg-gray-100">


<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKDMSK6" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

<nav class="navbar navbar-main navbar-expand-lg position-sticky mt-4 top-1 px-0 mx-4 shadow-none border-radius-xl z-index-sticky" id="navbarBlur" data-scroll="true">
<div class="container-fluid py-1 px-3">
<nav aria-label="breadcrumb">
<ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
<li class="breadcrumb-item text-sm">
<a class="opacity-3 text-dark" href="javascript:;.html">
<svg width="12px" height="12px" class="mb-1" viewbox="0 0 45 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<title>Track Your Complaints</title>
<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
<g transform="translate(-1716.000000, -439.000000)" fill="#252f40" fill-rule="nonzero">
<g transform="translate(1716.000000, 291.000000)">
<g transform="translate(0.000000, 148.000000)">
</g>
</g>
</g>
</g>
</svg>
</a>
</li>
<h6 class="font-weight-bolder mb-0">Your Complaint Status</h6>
</ol>
</nav>
</div>
</nav>

<div class="container-fluid py-4">
<div class="row gx-4">
<div class="col-lg-12">
<div class="card">
<div class="card-header pb-0">
<h6>Timeline of Your Complaint</h6>
</div>
<div class="card-body p-3">
<div class="timeline timeline-one-side" data-timeline-axis-style="dotted">
<?php foreach($uploadcomplaintdata as $row):?>
    <?php  $cur_status=$row['status']?>

    <?php
switch ($cur_status) {
  case "Received":
    ?>
    <style>
    .glowing-dot {
    width: 20px; 
    height: 20px; 
    border-radius: 50%; 
    background-color: blue;
    position: absolute; 
    top: 50%; 
    left: 50%;
    transform: translate(-50%, -50%); 
    box-shadow: 0 0 20px blue;
    animation: pulse 1.5s infinite; 
}

@keyframes pulse {
    0% {
        box-shadow: 0 0 20px blue;
    }
    50% {
        box-shadow: 0 0 40px blue;
    }
    100% {
        box-shadow: 0 0 20px blue;
    }
}


</style>

<div class="timeline-block mb-3">
<span class="timeline-step">

<div class="glowing-dot">
<i class="text-success text-gradient"></i>
</div>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Received</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['filed_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['issue_detail']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Investigation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
    No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class=" fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Proposed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Implementation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Final Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Complaint Closed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>

<?php
    break;


  case "Review":
    ?>
    <style>
    .glowing-dot {
    width: 20px; 
    height: 20px; 
    border-radius: 50%; 
    background-color: blue;
    position: absolute; 
    top: 50%; 
    left: 50%;
    transform: translate(-50%, -50%); 
    box-shadow: 0 0 20px blue;
    animation: pulse 1.5s infinite; 
}

@keyframes pulse {
    0% {
        box-shadow: 0 0 20px blue;
    }
    50% {
        box-shadow: 0 0 40px blue;
    }
    100% {
        box-shadow: 0 0 20px blue;
    }
}

</style>
<div class="timeline-block mb-3">
<span class="timeline-step">

<i class="fa fa-check text-success text-gradient"></i>

</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Received</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['filed_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['issue_detail']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<div class="glowing-dot">
<i class="text-success text-gradient"></i>
</div>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['updated_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['issue_detail']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Investigation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
    No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Proposed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Implementation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Final Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Complaint Closed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
</div>
</div>
<?php
    break;
  case "Investigation":
    ?>
    <style>
    .glowing-dot {
    width: 20px; 
    height: 20px; 
    border-radius: 50%; 
    background-color: blue;
    position: absolute; 
    top: 50%; 
    left: 50%;
    transform: translate(-50%, -50%); 
    box-shadow: 0 0 20px blue;
    animation: pulse 1.5s infinite; 
}

@keyframes pulse {
    0% {
        box-shadow: 0 0 20px blue;
    }
    50% {
        box-shadow: 0 0 40px blue;
    }
    100% {
        box-shadow: 0 0 20px blue;
    }
}

</style>
<div class="timeline-block mb-3">
<span class="timeline-step">

<i class="fa fa-check text-success text-gradient"></i>

</span>

<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Received</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['filed_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['issue_detail']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>

<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>

<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['updated_at']?></p>
<p class="text-sm mt-3 mb-2">
Complaint Reviewed and Forworded Concern Department
</p>
<span class="badge badge-sm bg-gradient-info"><?php echo $row['complaint_title']?></span>
</div>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<div class="glowing-dot">
<i class=" text-success text-gradient"></i>
</div>
</span>
<div class="timeline-block mb-3">
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Investigation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['updated_at']?></p>
<p class="text-sm mt-3 mb-2">
    <?php echo $row['issue_detail']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class=" fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Proposed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Implementation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-primary"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Final Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Complaint Closed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>

</div>
</div>
<?php
    break;
    case "Resolution Proposed":
        ?>
        <style>
    .glowing-dot {
    width: 20px; 
    height: 20px; 
    border-radius: 50%; 
    background-color: blue;
    position: absolute; 
    top: 50%; 
    left: 50%;
    transform: translate(-50%, -50%); 
    box-shadow: 0 0 20px blue;
    animation: pulse 1.5s infinite; 
}

@keyframes pulse {
    0% {
        box-shadow: 0 0 20px blue;
    }
    50% {
        box-shadow: 0 0 40px blue;
    }
    100% {
        box-shadow: 0 0 20px blue;
    }
}

</style>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Received</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['filed_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['issue_detail']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>

<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['updated_at']?></p>
<p class="text-sm mt-3 mb-2">
Complaint Reviewed and Forworded
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Investigation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['updated_at']?></p>
<p class="text-sm mt-3 mb-2">
    Complaint Investigation is Completed
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>

<div class="timeline-block mb-3">
<span class="timeline-step">


<div class="glowing-dot">
<i class="text-primary text-gradient"></i>
</div>


</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Proposed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['proposed_at']?></p>
<p class="text-sm mt-3 mb-2">

<?php echo $row['remark_1']?>

</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Implementation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Final Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Complaint Closed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>

</div>
</div>
<?php
        break;
        case "Resolution Implementation":
            ?>
            <style>
    .glowing-dot {
    width: 20px; 
    height: 20px; 
    border-radius: 50%; 
    background-color: blue;
    position: absolute; 
    top: 50%; 
    left: 50%;
    transform: translate(-50%, -50%); 
    box-shadow: 0 0 20px blue;
    animation: pulse 1.5s infinite; 
}

@keyframes pulse {
    0% {
        box-shadow: 0 0 20px blue;
    }
    50% {
        box-shadow: 0 0 40px blue;
    }
    100% {
        box-shadow: 0 0 20px blue;
    }
}

</style>
<div class="timeline-block mb-3">
<span class="timeline-step">

<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Received</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['filed_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['issue_detail']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['updated_at']?></p>
<p class="text-sm mt-3 mb-2">
Complaint Reviewed and Forworded Successfully
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Investigation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['created_at']?></p>
<p class="text-sm mt-3 mb-2">
    Complaint Investigation is Completed and Forworded Successfully
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class=" fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Proposed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['proposed_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['remark_1']?>
</p>
<span class="badge badge-sm bg-gradient-warning"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<div class="glowing-dot">
<i class=" text-danger text-gradient"></i>
</div>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Implementation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php $row['implementation_at']?></p>

<p class="text-sm mt-3 mb-2">
    <?php echo $row['remark_2']?>
</p>

<span class="badge badge-sm bg-gradient-primary"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Final Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
    <span class="badge badge-sm bg-gradient-primary"><?php echo $row['complaint_title']?></span>
    
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Complaint Closed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
    <span class="badge badge-sm bg-gradient-primary"><?php echo $row['complaint_title']?></span>
</div>
</div>
<?php
            break;

            case "Final Review":
                ?>
                <style>
                .glowing-dot {
                width: 20px; 
                height: 20px; 
                border-radius: 50%; 
                background-color: blue;
                position: absolute; 
                top: 50%; 
                left: 50%;
                transform: translate(-50%, -50%); 
                box-shadow: 0 0 20px blue;
                animation: pulse 1.5s infinite; 
            }
            
            @keyframes pulse {
                0% {
                    box-shadow: 0 0 20px blue;
                }
                50% {
                    box-shadow: 0 0 40px blue;
                }
                100% {
                    box-shadow: 0 0 20px blue;
                }
            }
            
            
            </style>
            <div class="timeline-block mb-3">
<span class="timeline-step">

<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Received</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['filed_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['issue_detail']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['updated_at']?></p>
<p class="text-sm mt-3 mb-2">
Complaint Reviewed and Forworded Successfully
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Investigation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['updated_at']?></p>
<p class="text-sm mt-3 mb-2">
 Complaint Investigation is Completed and Forworded Successfully
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Proposed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['proposed_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['remark_1']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Implementation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['implementation_at']?></p>
<p class="text-sm mt-3 mb-2"><p class="text-sm mt-3 mb-2">
<?php echo $row['remark_2']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
           <div class="timeline-block">
<span class="timeline-step">
<div class="glowing-dot">
<i class="text-danger text-gradient"></i>
</div>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Final Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['final_review_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['remark_3']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
<i class="fa fa-remove text-danger text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Complaint Closed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0">Not Updated</p>
<p class="text-sm mt-3 mb-2">
No data found
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>

</div>
</div>
            <?php
                break;

                case "Closed":
                    ?>
                    <style>
                    .glowing-dot {
                    width: 20px; 
                    height: 20px; 
                    border-radius: 50%; 
                    background-color: blue;
                    position: absolute; 
                    top: 50%; 
                    left: 50%;
                    transform: translate(-50%, -50%); 
                    box-shadow: 0 0 20px blue;
                    animation: pulse 1.5s infinite; 
                }
                
                @keyframes pulse {
                    0% {
                        box-shadow: 0 0 20px blue;
                    }
                    50% {
                        box-shadow: 0 0 40px blue;
                    }
                    100% {
                        box-shadow: 0 0 20px blue;
                    }
                }
                
                
                </style>
                        <div class="timeline-block mb-3">
<span class="timeline-step">

<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Received</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['filed_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['issue_detail']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['updated_at']?></p>
<p class="text-sm mt-3 mb-2">
Complaint Reviewed and Forworded Successfully
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Investigation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['created_at']?></p>
<p class="text-sm mt-3 mb-2">
 Complaint Investigation is Completed and Forworded Successfully
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Proposed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['proposed_at']?></p>
<?php echo $row['remark_1']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block mb-3">
<span class="timeline-step">
<i class="fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Resolution Implementation</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['implementation_at']?></p>
<p class="text-sm mt-3 mb-2"><p class="text-sm mt-3 mb-2">
<?php echo $row['remark_2']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
           <div class="timeline-block">
<span class="timeline-step">
<i class=" fa fa-check text-success text-gradient"></i>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Final Review</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['final_review_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['remark_3']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>
</div>
</div>
<div class="timeline-block">
<span class="timeline-step">
    <div class="glowing-dot">
<i class="text-danger text-gradient"></i>
</div>
</span>
<div class="timeline-content">
<h6 class="text-dark text-sm font-weight-bold mb-0">Complaint Closed</h6>
<p class="text-secondary font-weight-bold text-xs mt-1 mb-0"><?php echo $row['updated_at']?></p>
<p class="text-sm mt-3 mb-2">
<?php echo $row['issue_detail']?>
</p>
<span class="badge badge-sm bg-gradient-success"><?php echo $row['complaint_title']?></span>

</div>
</div>
                <?php
                    break;
  default:
    echo "Pending";
}
?>
</div>
</div>
<?php endforeach;?>
</div>
</div>
</div>
<footer class="footer pt-3  ">
<div class="container-fluid">
<div class="row align-items-center justify-content-lg-between">
<div class="col-lg-6 mb-lg-0 mb-4">
<div class="copyright text-center text-sm text-muted text-lg-start">
&copy; <script>
                  document.write(new Date().getFullYear())
                </script>,
made with <i class="fa fa-heart"></i> by
<a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Zilitech</a>
for a better web.
</div>
</div>
<div class="col-lg-6">
<ul class="nav nav-footer justify-content-center justify-content-lg-end">
<li class="nav-item">
<a href="https://www.creative-tim.com" class="nav-link text-muted" target="_blank">Zilitech</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/presentation" class="nav-link text-muted" target="_blank">About Us</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/blog" class="nav-link text-muted" target="_blank">Blog</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/license" class="nav-link pe-0 text-muted" target="_blank">License</a>
</li>
</ul>
</div>
</div>
</div>
</footer>
</div>
</main>
<div class="fixed-plugin">
<a class="fixed-plugin-button text-dark position-fixed px-3 py-2" href="projects.html">
<i class="fa fa-cog py-2"> </i>
</a>
<div class="card shadow-lg blur">
<div class="card-header pb-0 pt-3  bg-transparent ">
<div class="float-start">
<h5 class="mt-3 mb-0">Soft UI Configurator</h5>
<p>See our dashboard options.</p>
</div>
<div class="float-end mt-4">
<button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
<i class="fa fa-close"></i>
</button>
</div>

</div>
<hr class="horizontal dark my-1">
<div class="card-body pt-sm-3 pt-0">

<div>
<h6 class="mb-0">Sidebar Colors</h6>
</div>
<a href="javascript:void(0)" class="switch-trigger background-color">
<div class="badge-colors my-2 text-start">
<span class="badge filter bg-gradient-primary active" data-color="primary" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-dark" data-color="dark" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-info" data-color="info" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-success" data-color="success" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-warning" data-color="warning" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-danger" data-color="danger" onclick="sidebarColor(this)"></span>
</div>
</a>

<div class="mt-3">
<h6 class="mb-0">Sidenav Type</h6>
<p class="text-sm">Choose between 2 different sidenav types.</p>
</div>
<div class="d-flex">
<button class="btn bg-gradient-primary w-100 px-3 mb-2 active" data-class="bg-transparent" onclick="sidebarType(this)">Transparent</button>
<button class="btn bg-gradient-primary w-100 px-3 mb-2 ms-2" data-class="bg-white" onclick="sidebarType(this)">White</button>
</div>
<p class="text-sm d-xl-none d-block mt-2">You can change the sidenav type just on desktop view.</p>

<div class="mt-3">
<h6 class="mb-0">Navbar Fixed</h6>
</div>
<div class="form-check form-switch ps-0">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarFixed" onclick="navbarFixed(this)">
</div>
<hr class="horizontal dark mb-1 d-xl-block d-none">
<div class="mt-2 d-xl-block d-none">
<h6 class="mb-0">Sidenav Mini</h6>
</div>
<div class="form-check form-switch ps-0 d-xl-block d-none">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarMinimize" onclick="navbarMinimize(this)">
</div>
<hr class="horizontal dark mb-1 d-xl-block d-none">
<div class="mt-2 d-xl-block d-none">
<h6 class="mb-0">Light/Dark</h6>
</div>
<div class="form-check form-switch ps-0 d-xl-block d-none">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="dark-version" onclick="darkMode(this)">
</div>
<hr class="horizontal dark my-sm-4">
<a class="btn bg-gradient-info w-100" href="https://www.creative-tim.com/product/soft-ui-dashboard-pro">Buy now</a>
<a class="btn bg-gradient-dark w-100" href="https://www.creative-tim.com/product/soft-ui-dashboard">Free demo</a>
<a class="btn btn-outline-dark w-100" href="https://www.creative-tim.com/learning-lab/bootstrap/overview/soft-ui-dashboard">View documentation</a>
<div class="w-100 text-center">
<a class="github-button" href="https://github.com/creativetimofficial/ct-soft-ui-dashboard-pro" data-icon="octicon-star" data-size="large" data-show-count="true" aria-label="Star creativetimofficial/soft-ui-dashboard on GitHub">Star</a>
<h6 class="mt-3">Thank you for sharing!</h6>
<a href="https://twitter.com/intent/tweet?text=Check%20Soft%20UI%20Dashboard%20PRO%20made%20by%20%40CreativeTim%20%23webdesign%20%23dashboard%20%23bootstrap5&amp;url=https%3A%2F%2Fwww.creative-tim.com%2Fproduct%2Fsoft-ui-dashboard-pro" class="btn btn-dark mb-0 me-2" target="_blank">
<i class="fab fa-twitter me-1" aria-hidden="true"></i> Tweet
</a>
<a href="https://www.facebook.com/sharer/sharer.php?u=https://www.creative-tim.com/product/soft-ui-dashboard-pro" class="btn btn-dark mb-0 me-2" target="_blank">
<i class="fab fa-facebook-square me-1" aria-hidden="true"></i> Share
</a>
</div>
</div>
</div>
</div>

<script src="js/core-popper.min.js"></script>
<script src="js/core-bootstrap.min.js"></script>
<script src="js/plugins-perfect-scrollbar.min.js"></script>
<script src="js/plugins-smooth-scrollbar.min.js"></script>

<script src="js/dragula-dragula.min.js"></script>
<script src="js/jkanban-jkanban.js"></script>
<script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>

<script async defer src="js/buttons.github.io-buttons.js"></script>

<script src="js/js-soft-ui-dashboard.min.js"></script>
</body>
</html>
