

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="apple-touch-icon" sizes="76x76" href="../images/g_logo.png">
    <link rel="icon" type="image/png" href="../images/g_logo.png">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <title>Enter Complaint Id</title>

    <title>Complaint Form</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;  
            height: 100vh;         
            margin: 0;             
            font-family: Arial, sans-serif;
            background-color: 3DC2EC;
        }
        form{
            background-color:blanchedalmond;
            width: 500px;
            height: 200px;
            border: 1px solid burlywood;
            border-radius: 1rem;
            text-align: center;

        }
        h4{
            text-align: center;
        }
        #submit{
            color: white;
            margin-top: 20px;
            background-color: green;
            height: 40px;
            width: 80px;
            cursor: pointer;
            margin-left: 200px;
            border-radius: 0.5rem;
        }
        #input{
            margin-top: 20px;
            margin-left: 110px;
            border-radius: 0.5rem;
            width: 300px;

        }
        
    </style>
</head>
<body>
<form action="../timeline/timeline_NoRegister.php" method="post">
<h4>Track Your Complaint</h4>
  <div class="row">
    <div class="col-md-6">
      <div class="form-group has-success text-center">
        <input type="text" placeholder="Enter Complaint Id" id="input" name="complaint_id" class="form-control is-valid" />
      </div>
      <button class="form-control" type="submit" id="submit" name="submit">Submit</button>
    </div>
  </div>
</form>
</body>
</html>