<!DOCTYPE html>
<!--
 =========================================================
* Soft UI Dashboard PRO - v1.1.1
=========================================================

* Product Page:  https://www.creative-tim.com/product/soft-ui-dashboard-pro 
* Copyright 2023 Creative Tim (https://www.creative-tim.com)
* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
--><html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="apple-touch-icon" sizes="76x76" href="favicons/img-apple-icon.png">
<link rel="icon" type="image/png" href="favicons/img-favicon.png">
<title>
    Gramvaani Employee dashbord
  </title>


<link rel="canonical" href="https://www.creative-tim.com/product/soft-ui-dashboard-pro">

<meta name="keywords" content="creative tim, html dashboard, html css dashboard, web dashboard, bootstrap 5 dashboard, bootstrap 5, css3 dashboard, bootstrap 5 admin, soft ui dashboard bootstrap 5 dashboard, frontend, responsive bootstrap 5 dashboard, soft design, soft dashboard bootstrap 5 dashboard">
<meta name="description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">

<meta name="twitter:card" content="product">
<meta name="twitter:site" content="@creativetim">
<meta name="twitter:title" content="Soft UI Dashboard PRO by Creative Tim">
<meta name="twitter:description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">
<meta name="twitter:creator" content="@creativetim">
<meta name="twitter:image" content="https://s3.amazonaws.com/creativetim_bucket/products/487/thumb/opt_sdp_thumbnail.jpg">

<meta property="fb:app_id" content="655968634437471">
<meta property="og:title" content="Soft UI Dashboard PRO by Creative Tim">
<meta property="og:type" content="article">
<meta property="og:url" content="https://demos.creative-tim.com/soft-ui-dashboard-pro/pages/dashboards/default.html">
<meta property="og:image" content="https://s3.amazonaws.com/creativetim_bucket/products/487/thumb/opt_sdp_thumbnail.jpg">
<meta property="og:description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">
<meta property="og:site_name" content="Creative Tim">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

<link href="css/css-nucleo-icons.css" rel="stylesheet">
<link href="css/css-nucleo-svg.css" rel="stylesheet">

<script src="js/42d5adcbca.js" crossorigin="anonymous"></script>
<link href="css/css-nucleo-svg.css" rel="stylesheet">

<link id="pagestyle" href="css/css-soft-ui-dashboard.min.css" rel="stylesheet">

<style>
    .async-hide {
      opacity: 0 !important
    }
  </style>
<script>
    (function(a, s, y, n, c, h, i, d, e) {
      s.className += ' ' + y;
      h.start = 1 * new Date;
      h.end = i = function() {
        s.className = s.className.replace(RegExp(' ?' + y), '')
      };
      (a[n] = a[n] || []).hide = h;
      setTimeout(function() {
        i();
        h.end = null
      }, c);
      h.timeout = c;
    })(window, document.documentElement, 'async-hide', 'dataLayer', 4000, {
      'GTM-K9BGS8K': true
    });
  </script>

<script>
    (function(i, s, o, g, r, a, m) {
      i['GoogleAnalyticsObject'] = r;
      i[r] = i[r] || function() {
        (i[r].q = i[r].q || []).push(arguments)
      }, i[r].l = 1 * new Date();
      a = s.createElement(o),
        m = s.getElementsByTagName(o)[0];
      a.async = 1;
      a.src = g;
      m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');
    ga('create', 'UA-46172202-22', 'auto', {
      allowLinker: true
    });
    ga('set', 'anonymizeIp', true);
    ga('require', 'GTM-K9BGS8K');
    ga('require', 'displayfeatures');
    ga('require', 'linker');
    ga('linker:autoLink', ["2checkout.com", "avangate.com"]);
  </script>


<script>
    (function(w, d, s, l, i) {
      w[l] = w[l] || [];
      w[l].push({
        'gtm.start': new Date().getTime(),
        event: 'gtm.js'
      });
      var f = d.getElementsByTagName(s)[0],
        j = d.createElement(s),
        dl = l != 'dataLayer' ? '&l=' + l : '';
      j.async = true;
      j.src =
        'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
      f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-NKDMSK6');
  </script>



<script defer data-site="demos.creative-tim.com" src="js/js-nepcha-analytics.js"></script>
</head>
<body class="g-sidenav-show bg-gray-100">


<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKDMSK6" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<aside class="sidenav navbar navbar-vertical navbar-expand-xs border-0 border-radius-xl my-3 fixed-start ms-3 " id="sidenav-main">
<div class="sidenav-header">
<i class="fas fa-times p-3 cursor-pointer text-secondary opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
<a class="navbar-brand m-0" href="default.html" target="_blank">
<img src="images/g_logo.png" class="navbar-brand-img h-100" alt="main_logo">
<span class="ms-1 font-weight-bold">Gramvaani</span>
</a>
</div>
<hr class="horizontal dark mt-0">
<div class="collapse navbar-collapse  w-auto h-auto" id="sidenav-collapse-main">
<ul class="navbar-nav">
<li class="nav-item">
          <a class="nav-link  active" href="admin/pages/dashboard.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 45 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>dashboard</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1716.000000, -439.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g transform="translate(0.000000, 148.000000)">
                        <path class="color-background opacity-6" d="M46.7199583,10.7414583 L40.8449583,0.949791667 C40.4909749,0.360605034 39.8540131,0 39.1666667,0 L7.83333333,0 C7.1459869,0 6.50902508,0.360605034 6.15504167,0.949791667 L0.280041667,10.7414583 C0.0969176761,11.0460037 -1.23209662e-05,11.3946378 -1.23209662e-05,11.75 C-0.00758042603,16.0663731 3.48367543,19.5725301 7.80004167,19.5833333 L7.81570833,19.5833333 C9.75003686,19.5882688 11.6168794,18.8726691 13.0522917,17.5760417 C16.0171492,20.2556967 20.5292675,20.2556967 23.494125,17.5760417 C26.4604562,20.2616016 30.9794188,20.2616016 33.94575,17.5760417 C36.2421905,19.6477597 39.5441143,20.1708521 42.3684437,18.9103691 C45.1927731,17.649886 47.0084685,14.8428276 47.0000295,11.75 C47.0000295,11.3946378 46.9030823,11.0460037 46.7199583,10.7414583 Z"></path>
                        <path class="color-background" d="M39.198,22.4912623 C37.3776246,22.4928106 35.5817531,22.0149171 33.951625,21.0951667 L33.92225,21.1107282 C31.1430221,22.6838032 27.9255001,22.9318916 24.9844167,21.7998837 C24.4750389,21.605469 23.9777983,21.3722567 23.4960833,21.1018359 L23.4745417,21.1129513 C20.6961809,22.6871153 17.4786145,22.9344611 14.5386667,21.7998837 C14.029926,21.6054643 13.533337,21.3722507 13.0522917,21.1018359 C11.4250962,22.0190609 9.63246555,22.4947009 7.81570833,22.4912623 C7.16510551,22.4842162 6.51607673,22.4173045 5.875,22.2911849 L5.875,44.7220845 C5.875,45.9498589 6.7517757,46.9451667 7.83333333,46.9451667 L19.5833333,46.9451667 L19.5833333,33.6066734 L27.4166667,33.6066734 L27.4166667,46.9451667 L39.1666667,46.9451667 C40.2482243,46.9451667 41.125,45.9498589 41.125,44.7220845 L41.125,22.2822926 C40.4887822,22.4116582 39.8442868,22.4815492 39.198,22.4912623 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/complaints.php">
            <div class="fa fa-book icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>complaints</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1869.000000, -293.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g id="office" transform="translate(153.000000, 2.000000)">
                        <path class="color-background opacity-6" d="M12.25,17.5 L8.75,17.5 L8.75,1.75 C8.75,0.78225 9.53225,0 10.5,0 L31.5,0 C32.46775,0 33.25,0.78225 33.25,1.75 L33.25,12.25 L29.75,12.25 L29.75,3.5 L12.25,3.5 L12.25,17.5 Z"></path>
                        <path class="color-background" d="M40.25,14 L24.5,14 C23.53225,14 22.75,14.78225 22.75,15.75 L22.75,38.5 L19.25,38.5 L19.25,22.75 C19.25,21.78225 18.46775,21 17.5,21 L1.75,21 C0.78225,21 0,21.78225 0,22.75 L0,40.25 C0,41.21775 0.78225,42 1.75,42 L40.25,42 C41.21775,42 42,41.21775 42,40.25 L42,15.75 C42,14.78225 41.21775,14 40.25,14 Z M12.25,36.75 L7,36.75 L7,33.25 L12.25,33.25 L12.25,36.75 Z M12.25,29.75 L7,29.75 L7,26.25 L12.25,26.25 L12.25,29.75 Z M35,36.75 L29.75,36.75 L29.75,33.25 L35,33.25 L35,36.75 Z M35,29.75 L29.75,29.75 L29.75,26.25 L35,26.25 L35,29.75 Z M35,22.75 L29.75,22.75 L29.75,19.25 L35,19.25 L35,22.75 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Complaints</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/register.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 43 36" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>register</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-2169.000000, -745.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g transform="translate(453.000000, 454.000000)">
                        <path class="color-background opacity-6" d="M43,10.7482083 L43,3.58333333 C43,1.60354167 41.3964583,0 39.4166667,0 L3.58333333,0 C1.60354167,0 0,1.60354167 0,3.58333333 L0,10.7482083 L43,10.7482083 Z"></path>
                        <path class="color-background" d="M0,16.125 L0,32.25 C0,34.2297917 1.60354167,35.8333333 3.58333333,35.8333333 L39.4166667,35.8333333 C41.3964583,35.8333333 43,34.2297917 43,32.25 L43,16.125 L0,16.125 Z M19.7083333,26.875 L7.16666667,26.875 L7.16666667,23.2916667 L19.7083333,23.2916667 L19.7083333,26.875 Z M35.8333333,26.875 L28.6666667,26.875 L28.6666667,23.2916667 L35.8333333,23.2916667 L35.8333333,26.875 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Register</span>
          </a>
        </li>
        <li class="nav-item">
<a data-bs-toggle="collapse" href="#dashboardsExamples" class="nav-link " aria-controls="dashboardsExamples" role="button" aria-expanded="false">
<div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center d-flex align-items-center justify-content-center  me-2">
<svg width="12px" height="12px" viewbox="0 0 45 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<title>Complaints </title>
<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
<g transform="translate(-1716.000000, -439.000000)" fill="#FFFFFF" fill-rule="nonzero">
<g transform="translate(1716.000000, 291.000000)">
<g transform="translate(0.000000, 148.000000)">
<path class="color-background" d="M46.7199583,10.7414583 L40.8449583,0.949791667 C40.4909749,0.360605034 39.8540131,0 39.1666667,0 L7.83333333,0 C7.1459869,0 6.50902508,0.360605034 6.15504167,0.949791667 L0.280041667,10.7414583 C0.0969176761,11.0460037 -1.23209662e-05,11.3946378 -1.23209662e-05,11.75 C-0.00758042603,16.0663731 3.48367543,19.5725301 7.80004167,19.5833333 L7.81570833,19.5833333 C9.75003686,19.5882688 11.6168794,18.8726691 13.0522917,17.5760417 C16.0171492,20.2556967 20.5292675,20.2556967 23.494125,17.5760417 C26.4604562,20.2616016 30.9794188,20.2616016 33.94575,17.5760417 C36.2421905,19.6477597 39.5441143,20.1708521 42.3684437,18.9103691 C45.1927731,17.649886 47.0084685,14.8428276 47.0000295,11.75 C47.0000295,11.3946378 46.9030823,11.0460037 46.7199583,10.7414583 Z" opacity="0.598981585"></path>
<path class="color-background" d="M39.198,22.4912623 C37.3776246,22.4928106 35.5817531,22.0149171 33.951625,21.0951667 L33.92225,21.1107282 C31.1430221,22.6838032 27.9255001,22.9318916 24.9844167,21.7998837 C24.4750389,21.605469 23.9777983,21.3722567 23.4960833,21.1018359 L23.4745417,21.1129513 C20.6961809,22.6871153 17.4786145,22.9344611 14.5386667,21.7998837 C14.029926,21.6054643 13.533337,21.3722507 13.0522917,21.1018359 C11.4250962,22.0190609 9.63246555,22.4947009 7.81570833,22.4912623 C7.16510551,22.4842162 6.51607673,22.4173045 5.875,22.2911849 L5.875,44.7220845 C5.875,45.9498589 6.7517757,46.9451667 7.83333333,46.9451667 L19.5833333,46.9451667 L19.5833333,33.6066734 L27.4166667,33.6066734 L27.4166667,46.9451667 L39.1666667,46.9451667 C40.2482243,46.9451667 41.125,45.9498589 41.125,44.7220845 L41.125,22.2822926 C40.4887822,22.4116582 39.8442868,22.4815492 39.198,22.4912623 Z"></path>
</g>
</g>
</g>
</g>
</svg>
</div>
<span class="nav-link-text ms-1">Complaints</span>
</a>
<div class="collapse " id="dashboardsExamples">
<ul class="nav ms-4 ps-3">
<li class="nav-item ">
<a class="nav-link " href="recivedcomplaints/recived_complaints.php">
<span class="sidenav-mini-icon"> N </span>
<span class="sidenav-normal"> New Complaints </span>
</a>
</li>
<li class="nav-item ">
<a class="nav-link " href="recivedcomplaints/assigned_complaints.php">
<span class="sidenav-mini-icon"> A </span>
<span class="sidenav-normal"> Assigned Complaints </span>
</a>
</li>
<li class="nav-item ">
<a class="nav-link " href="recivedcomplaints/solved_complaints.php">
<span class="sidenav-mini-icon"> R </span>
<span class="sidenav-normal"> Resolved Complaints </span>
</a>
</li>
</ul>
        <li class="nav-item mt-3">
          <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">SetUp</h6>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/Department.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>Department</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1869.000000, -293.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g id="office" transform="translate(153.000000, 2.000000)">
                        <path class="color-background opacity-6" d="M12.25,17.5 L8.75,17.5 L8.75,1.75 C8.75,0.78225 9.53225,0 10.5,0 L31.5,0 C32.46775,0 33.25,0.78225 33.25,1.75 L33.25,12.25 L29.75,12.25 L29.75,3.5 L12.25,3.5 L12.25,17.5 Z"></path>
                        <path class="color-background" d="M40.25,14 L24.5,14 C23.53225,14 22.75,14.78225 22.75,15.75 L22.75,38.5 L19.25,38.5 L19.25,22.75 C19.25,21.78225 18.46775,21 17.5,21 L1.75,21 C0.78225,21 0,21.78225 0,22.75 L0,40.25 C0,41.21775 0.78225,42 1.75,42 L40.25,42 C41.21775,42 42,41.21775 42,40.25 L42,15.75 C42,14.78225 41.21775,14 40.25,14 Z M12.25,36.75 L7,36.75 L7,33.25 L12.25,33.25 L12.25,36.75 Z M12.25,29.75 L7,29.75 L7,26.25 L12.25,26.25 L12.25,29.75 Z M35,36.75 L29.75,36.75 L29.75,33.25 L35,33.25 L35,36.75 Z M35,29.75 L29.75,29.75 L29.75,26.25 L35,26.25 L35,29.75 Z M35,22.75 L29.75,22.75 L29.75,19.25 L35,19.25 L35,22.75 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Department</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/Designation.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>Desigantion</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1869.000000, -293.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g id="office" transform="translate(153.000000, 2.000000)">
                        <path class="color-background opacity-6" d="M12.25,17.5 L8.75,17.5 L8.75,1.75 C8.75,0.78225 9.53225,0 10.5,0 L31.5,0 C32.46775,0 33.25,0.78225 33.25,1.75 L33.25,12.25 L29.75,12.25 L29.75,3.5 L12.25,3.5 L12.25,17.5 Z"></path>
                        <path class="color-background" d="M40.25,14 L24.5,14 C23.53225,14 22.75,14.78225 22.75,15.75 L22.75,38.5 L19.25,38.5 L19.25,22.75 C19.25,21.78225 18.46775,21 17.5,21 L1.75,21 C0.78225,21 0,21.78225 0,22.75 L0,40.25 C0,41.21775 0.78225,42 1.75,42 L40.25,42 C41.21775,42 42,41.21775 42,40.25 L42,15.75 C42,14.78225 41.21775,14 40.25,14 Z M12.25,36.75 L7,36.75 L7,33.25 L12.25,33.25 L12.25,36.75 Z M12.25,29.75 L7,29.75 L7,26.25 L12.25,26.25 L12.25,29.75 Z M35,36.75 L29.75,36.75 L29.75,33.25 L35,33.25 L35,36.75 Z M35,29.75 L29.75,29.75 L29.75,26.25 L35,26.25 L35,29.75 Z M35,22.75 L29.75,22.75 L29.75,19.25 L35,19.25 L35,22.75 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Desigantion</span>
          </a>
        </li>
        <li class="nav-item mt-3">
          <h6 class="ps-4 ms-2 text-uppercase text-xs font-weight-bolder opacity-6">System Settings</h6>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/profile.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 46 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>profile</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1717.000000, -291.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g transform="translate(1.000000, 0.000000)">
                        <path class="color-background opacity-6" d="M45,0 L26,0 C25.447,0 25,0.447 25,1 L25,20 C25,20.379 25.214,20.725 25.553,20.895 C25.694,20.965 25.848,21 26,21 C26.212,21 26.424,20.933 26.6,20.8 L34.333,15 L45,15 C45.553,15 46,14.553 46,14 L46,1 C46,0.447 45.553,0 45,0 Z"></path>
                        <path class="color-background" d="M22.883,32.86 C20.761,32.012 17.324,31 13,31 C8.676,31 5.239,32.012 3.116,32.86 C1.224,33.619 0,35.438 0,37.494 L0,41 C0,41.553 0.447,42 1,42 L25,42 C25.553,42 26,41.553 26,41 L26,37.494 C26,35.438 24.776,33.619 22.883,32.86 Z"></path>
                        <path class="color-background" d="M13,28 C17.432,28 21,22.529 21,18 C21,13.589 17.411,10 13,10 C8.589,10 5,13.589 5,18 C5,22.529 8.568,28 13,28 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Profile</span>
          </a>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/backup.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>backup</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1869.000000, -293.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g id="office" transform="translate(153.000000, 2.000000)">
                        <path class="color-background opacity-6" d="M12.25,17.5 L8.75,17.5 L8.75,1.75 C8.75,0.78225 9.53225,0 10.5,0 L31.5,0 C32.46775,0 33.25,0.78225 33.25,1.75 L33.25,12.25 L29.75,12.25 L29.75,3.5 L12.25,3.5 L12.25,17.5 Z"></path>
                        <path class="color-background" d="M40.25,14 L24.5,14 C23.53225,14 22.75,14.78225 22.75,15.75 L22.75,38.5 L19.25,38.5 L19.25,22.75 C19.25,21.78225 18.46775,21 17.5,21 L1.75,21 C0.78225,21 0,21.78225 0,22.75 L0,40.25 C0,41.21775 0.78225,42 1.75,42 L40.25,42 C41.21775,42 42,41.21775 42,40.25 L42,15.75 C42,14.78225 41.21775,14 40.25,14 Z M12.25,36.75 L7,36.75 L7,33.25 L12.25,33.25 L12.25,36.75 Z M12.25,29.75 L7,29.75 L7,26.25 L12.25,26.25 L12.25,29.75 Z M35,36.75 L29.75,36.75 L29.75,33.25 L35,33.25 L35,36.75 Z M35,29.75 L29.75,29.75 L29.75,26.25 L35,26.25 L35,29.75 Z M35,22.75 L29.75,22.75 L29.75,19.25 L35,19.25 L35,22.75 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">BackUp</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/mail setup.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>mail setup</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1869.000000, -293.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g id="office" transform="translate(153.000000, 2.000000)">
                        <path class="color-background opacity-6" d="M12.25,17.5 L8.75,17.5 L8.75,1.75 C8.75,0.78225 9.53225,0 10.5,0 L31.5,0 C32.46775,0 33.25,0.78225 33.25,1.75 L33.25,12.25 L29.75,12.25 L29.75,3.5 L12.25,3.5 L12.25,17.5 Z"></path>
                        <path class="color-background" d="M40.25,14 L24.5,14 C23.53225,14 22.75,14.78225 22.75,15.75 L22.75,38.5 L19.25,38.5 L19.25,22.75 C19.25,21.78225 18.46775,21 17.5,21 L1.75,21 C0.78225,21 0,21.78225 0,22.75 L0,40.25 C0,41.21775 0.78225,42 1.75,42 L40.25,42 C41.21775,42 42,41.21775 42,40.25 L42,15.75 C42,14.78225 41.21775,14 40.25,14 Z M12.25,36.75 L7,36.75 L7,33.25 L12.25,33.25 L12.25,36.75 Z M12.25,29.75 L7,29.75 L7,26.25 L12.25,26.25 L12.25,29.75 Z M35,36.75 L29.75,36.75 L29.75,33.25 L35,33.25 L35,36.75 Z M35,29.75 L29.75,29.75 L29.75,26.25 L35,26.25 L35,29.75 Z M35,22.75 L29.75,22.75 L29.75,19.25 L35,19.25 L35,22.75 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Mail SetUp</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/roles and permission.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>rolles and permission</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1869.000000, -293.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g id="office" transform="translate(153.000000, 2.000000)">
                        <path class="color-background opacity-6" d="M12.25,17.5 L8.75,17.5 L8.75,1.75 C8.75,0.78225 9.53225,0 10.5,0 L31.5,0 C32.46775,0 33.25,0.78225 33.25,1.75 L33.25,12.25 L29.75,12.25 L29.75,3.5 L12.25,3.5 L12.25,17.5 Z"></path>
                        <path class="color-background" d="M40.25,14 L24.5,14 C23.53225,14 22.75,14.78225 22.75,15.75 L22.75,38.5 L19.25,38.5 L19.25,22.75 C19.25,21.78225 18.46775,21 17.5,21 L1.75,21 C0.78225,21 0,21.78225 0,22.75 L0,40.25 C0,41.21775 0.78225,42 1.75,42 L40.25,42 C41.21775,42 42,41.21775 42,40.25 L42,15.75 C42,14.78225 41.21775,14 40.25,14 Z M12.25,36.75 L7,36.75 L7,33.25 L12.25,33.25 L12.25,36.75 Z M12.25,29.75 L7,29.75 L7,26.25 L12.25,26.25 L12.25,29.75 Z M35,36.75 L29.75,36.75 L29.75,33.25 L35,33.25 L35,36.75 Z M35,29.75 L29.75,29.75 L29.75,26.25 L35,26.25 L35,29.75 Z M35,22.75 L29.75,22.75 L29.75,19.25 L35,19.25 L35,22.75 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Roles & permission</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/custom module.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 42 42" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>custom module</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1869.000000, -293.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g id="office" transform="translate(153.000000, 2.000000)">
                        <path class="color-background opacity-6" d="M12.25,17.5 L8.75,17.5 L8.75,1.75 C8.75,0.78225 9.53225,0 10.5,0 L31.5,0 C32.46775,0 33.25,0.78225 33.25,1.75 L33.25,12.25 L29.75,12.25 L29.75,3.5 L12.25,3.5 L12.25,17.5 Z"></path>
                        <path class="color-background" d="M40.25,14 L24.5,14 C23.53225,14 22.75,14.78225 22.75,15.75 L22.75,38.5 L19.25,38.5 L19.25,22.75 C19.25,21.78225 18.46775,21 17.5,21 L1.75,21 C0.78225,21 0,21.78225 0,22.75 L0,40.25 C0,41.21775 0.78225,42 1.75,42 L40.25,42 C41.21775,42 42,41.21775 42,40.25 L42,15.75 C42,14.78225 41.21775,14 40.25,14 Z M12.25,36.75 L7,36.75 L7,33.25 L12.25,33.25 L12.25,36.75 Z M12.25,29.75 L7,29.75 L7,26.25 L12.25,26.25 L12.25,29.75 Z M35,36.75 L29.75,36.75 L29.75,33.25 L35,33.25 L35,36.75 Z M35,29.75 L29.75,29.75 L29.75,26.25 L35,26.25 L35,29.75 Z M35,22.75 L29.75,22.75 L29.75,19.25 L35,19.25 L35,22.75 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Custom Module</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/sign-in.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="12px" viewBox="0 0 40 44" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>sign-in</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1870.000000, -591.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g transform="translate(154.000000, 300.000000)">
                        <path class="color-background opacity-6" d="M40,40 L36.3636364,40 L36.3636364,3.63636364 L5.45454545,3.63636364 L5.45454545,0 L38.1818182,0 C39.1854545,0 40,0.814545455 40,1.81818182 L40,40 Z"></path>
                        <path class="color-background" d="M30.9090909,7.27272727 L1.81818182,7.27272727 C0.814545455,7.27272727 0,8.08727273 0,9.09090909 L0,41.8181818 C0,42.8218182 0.814545455,43.6363636 1.81818182,43.6363636 L30.9090909,43.6363636 C31.9127273,43.6363636 32.7272727,42.8218182 32.7272727,41.8181818 L32.7272727,9.09090909 C32.7272727,8.08727273 31.9127273,7.27272727 30.9090909,7.27272727 Z M18.1818182,34.5454545 L7.27272727,34.5454545 L7.27272727,30.9090909 L18.1818182,30.9090909 L18.1818182,34.5454545 Z M25.4545455,27.2727273 L7.27272727,27.2727273 L7.27272727,23.6363636 L25.4545455,23.6363636 L25.4545455,27.2727273 Z M25.4545455,20 L7.27272727,20 L7.27272727,16.3636364 L25.4545455,16.3636364 L25.4545455,20 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Sign In</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link  " href="admin/pages/sign-up.php">
            <div class="icon icon-shape icon-sm shadow border-radius-md bg-white text-center me-2 d-flex align-items-center justify-content-center">
              <svg width="12px" height="20px" viewBox="0 0 40 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <title>sign-up</title>
                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-1720.000000, -592.000000)" fill="#FFFFFF" fill-rule="nonzero">
                    <g transform="translate(1716.000000, 291.000000)">
                      <g transform="translate(4.000000, 301.000000)">
                        <path class="color-background" d="M39.3,0.706666667 C38.9660984,0.370464027 38.5048767,0.192278529 38.0316667,0.216666667 C14.6516667,1.43666667 6.015,22.2633333 5.93166667,22.4733333 C5.68236407,23.0926189 5.82664679,23.8009159 6.29833333,24.2733333 L15.7266667,33.7016667 C16.2013871,34.1756798 16.9140329,34.3188658 17.535,34.065 C17.7433333,33.98 38.4583333,25.2466667 39.7816667,1.97666667 C39.8087196,1.50414529 39.6335979,1.04240574 39.3,0.706666667 Z M25.69,19.0233333 C24.7367525,19.9768687 23.3029475,20.2622391 22.0572426,19.7463614 C20.8115377,19.2304837 19.9992882,18.0149658 19.9992882,16.6666667 C19.9992882,15.3183676 20.8115377,14.1028496 22.0572426,13.5869719 C23.3029475,13.0710943 24.7367525,13.3564646 25.69,14.31 C26.9912731,15.6116662 26.9912731,17.7216672 25.69,19.0233333 L25.69,19.0233333 Z"></path>
                        <path class="color-background opacity-6" d="M1.855,31.4066667 C3.05106558,30.2024182 4.79973884,29.7296005 6.43969145,30.1670277 C8.07964407,30.6044549 9.36054508,31.8853559 9.7979723,33.5253085 C10.2353995,35.1652612 9.76258177,36.9139344 8.55833333,38.11 C6.70666667,39.9616667 0,40 0,40 C0,40 0,33.2566667 1.855,31.4066667 Z"></path>
                        <path class="color-background opacity-6" d="M17.2616667,3.90166667 C12.4943643,3.07192755 7.62174065,4.61673894 4.20333333,8.04166667 C3.31200265,8.94126033 2.53706177,9.94913142 1.89666667,11.0416667 C1.5109569,11.6966059 1.61721591,12.5295394 2.155,13.0666667 L5.47,16.3833333 C8.55036617,11.4946947 12.5559074,7.25476565 17.2616667,3.90166667 L17.2616667,3.90166667 Z"></path>
                        <path class="color-background opacity-6" d="M36.0983333,22.7383333 C36.9280725,27.5056357 35.3832611,32.3782594 31.9583333,35.7966667 C31.0587397,36.6879974 30.0508686,37.4629382 28.9583333,38.1033333 C28.3033941,38.4890431 27.4704606,38.3827841 26.9333333,37.845 L23.6166667,34.53 C28.5053053,31.4496338 32.7452344,27.4440926 36.0983333,22.7383333 L36.0983333,22.7383333 Z"></path>
                      </g>
                    </g>
                  </g>
                </g>
              </svg>
            </div>
            <span class="nav-link-text ms-1">Sign Up</span>
          </a>
        </li>
</ul>
</div>
<div class="sidenav-footer mx-3 mt-3 pt-3">
<div class="card card-background shadow-none card-background-mask-secondary" id="sidenavCard">
<div class="full-background" style="background-image: url('../../../assets/img/curved-images/white-curved.jpg')"></div>
<div class="card-body text-start p-3 w-100">
<div class="icon icon-shape icon-sm bg-white shadow text-center mb-3 d-flex align-items-center justify-content-center border-radius-md">
<i class="ni ni-diamond text-dark text-gradient text-lg top-0" aria-hidden="true" id="sidenavCardIcon"></i>
</div>
<div class="docs-info">
<h6 class="text-white up mb-0">Need help?</h6>
<p class="text-xs font-weight-bold">Please check our docs</p>
<a href="https://www.creative-tim.com/learning-lab/bootstrap/overview/soft-ui-dashboard" target="_blank" class="btn btn-white btn-sm w-100 mb-0">Documentation</a>
</div>
</div>
</div>
</div>
</aside>
<main class="main-content max-height-vh-100 h-100">
<nav class="navbar navbar-main navbar-expand-lg px-0 mx-4 shadow-none border-radius-xl ">
<div class="container-fluid py-1 px-3">
<nav aria-label="breadcrumb">
<ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
<li class="breadcrumb-item text-sm">
<a class="opacity-3 text-dark" href="javascript:;.html">
<svg width="12px" height="12px" class="mb-1" viewbox="0 0 45 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<title>shop </title>
<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
<g transform="translate(-1716.000000, -439.000000)" fill="#252f40" fill-rule="nonzero">
<g transform="translate(1716.000000, 291.000000)">
<g transform="translate(0.000000, 148.000000)">
<path d="M46.7199583,10.7414583 L40.8449583,0.949791667 C40.4909749,0.360605034 39.8540131,0 39.1666667,0 L7.83333333,0 C7.1459869,0 6.50902508,0.360605034 6.15504167,0.949791667 L0.280041667,10.7414583 C0.0969176761,11.0460037 -1.23209662e-05,11.3946378 -1.23209662e-05,11.75 C-0.00758042603,16.0663731 3.48367543,19.5725301 7.80004167,19.5833333 L7.81570833,19.5833333 C9.75003686,19.5882688 11.6168794,18.8726691 13.0522917,17.5760417 C16.0171492,20.2556967 20.5292675,20.2556967 23.494125,17.5760417 C26.4604562,20.2616016 30.9794188,20.2616016 33.94575,17.5760417 C36.2421905,19.6477597 39.5441143,20.1708521 42.3684437,18.9103691 C45.1927731,17.649886 47.0084685,14.8428276 47.0000295,11.75 C47.0000295,11.3946378 46.9030823,11.0460037 46.7199583,10.7414583 Z">
</path>
<path d="M39.198,22.4912623 C37.3776246,22.4928106 35.5817531,22.0149171 33.951625,21.0951667 L33.92225,21.1107282 C31.1430221,22.6838032 27.9255001,22.9318916 24.9844167,21.7998837 C24.4750389,21.605469 23.9777983,21.3722567 23.4960833,21.1018359 L23.4745417,21.1129513 C20.6961809,22.6871153 17.4786145,22.9344611 14.5386667,21.7998837 C14.029926,21.6054643 13.533337,21.3722507 13.0522917,21.1018359 C11.4250962,22.0190609 9.63246555,22.4947009 7.81570833,22.4912623 C7.16510551,22.4842162 6.51607673,22.4173045 5.875,22.2911849 L5.875,44.7220845 C5.875,45.9498589 6.7517757,46.9451667 7.83333333,46.9451667 L19.5833333,46.9451667 L19.5833333,33.6066734 L27.4166667,33.6066734 L27.4166667,46.9451667 L39.1666667,46.9451667 C40.2482243,46.9451667 41.125,45.9498589 41.125,44.7220845 L41.125,22.2822926 C40.4887822,22.4116582 39.8442868,22.4815492 39.198,22.4912623 Z">
</path>
</g>
</g>
</g>
</g>
</svg>
</a>
</li>
<li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;.html">Pages</a></li>
<li class="breadcrumb-item text-sm"><a class="opacity-5 text-dark" href="javascript:;.html">Account</a></li>
<li class="breadcrumb-item text-sm text-dark active" aria-current="page">Settings</li>
</ol>
<h6 class="font-weight-bolder">Account</h6>
</nav>
<div class="sidenav-toggler sidenav-toggler-inner d-xl-block d-none me-auto">
<a href="javascript:;.html" class="nav-link text-body p-0">
<div class="sidenav-toggler-inner">
<i class="sidenav-toggler-line"></i>
<i class="sidenav-toggler-line"></i>
<i class="sidenav-toggler-line"></i>
</div>
</a>
</div>
<div class="collapse navbar-collapse me-md-0 me-sm-4 mt-sm-0 mt-2" id="navbar">
<ul class="navbar-nav justify-content-end ms-auto">
<li class="nav-item d-xl-none ps-3 pe-0 d-flex align-items-center">
<a href="javascript:;.html" class="nav-link text-body p-0" id="iconNavbarSidenav">
<div class="sidenav-toggler-inner">
<i class="sidenav-toggler-line"></i>
<i class="sidenav-toggler-line"></i>
<i class="sidenav-toggler-line"></i>
</div>
</a>
</li>
</ul>
</div>
</div>
</nav>
<div class="container-fluid mt-4">
<div class="row align-items-center">
<div class="col-lg-4 col-sm-8">
<div class="nav-wrapper position-relative end-0">
<ul class="nav nav-pills nav-fill p-1" role="tablist">
<li class="nav-item">
<a class="nav-link mb-0 px-0 py-1 active  active " data-bs-toggle="tab" href="settings.html" role="tab" aria-selected="true">
Messages
</a>
</li>
<li class="nav-item">
<a class="nav-link mb-0 px-0 py-1 " data-bs-toggle="tab" href="billing.html" role="tab" aria-selected="false">
Social
</a>
</li>
<li class="nav-item">
<a class="nav-link mb-0 px-0 py-1 " data-bs-toggle="tab" href="invoice.html" role="tab" aria-selected="false">
Notifications
</a>
</li>
<li class="nav-item">
<a class="nav-link mb-0 px-0 py-1 " data-bs-toggle="tab" href="security.html" role="tab" aria-selected="false">
Backup
</a>
</li>
</ul>
</div>
</div>
</div>
</div>



<div class="col-lg-12 mt-lg-0 mt-4">

<div class="card card-body" id="profile">
<div class="row justify-content-center align-items-center">
<div class="col-sm-auto col-4">
<div class="avatar avatar-xl position-relative">
<img src="images/img-bruce-mars.jpg" alt="bruce" class="w-100 border-radius-lg shadow-sm">
</div>
</div>
<div class="col-sm-auto col-8 my-auto">
<div class="h-100">
<h5 class="mb-1 font-weight-bolder">
Alec Thompson
</h5>
<p class="mb-0 font-weight-bold text-sm">
CEO / Co-Founder
</p>
</div>
</div>
<div class="col-sm-auto ms-sm-auto mt-sm-0 mt-3 d-flex">
<label class="form-check-label mb-0">
<small id="profileVisibility">
Switch to invisible
</small>
</label>
<div class="form-check form-switch ms-2">
<input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault23" checked onchange="visible()">
</div>
</div>
</div>
</div>

<div class="card mt-4" id="basic-info">
<div class="card-header">
<h5>Add Employees</h5>
</div>
<div class="card-body pt-0">
<div class="row">
<div class="col-6">
<label class="form-label">First Name</label>
<div class="input-group">
<input id="firstName" name="firstName" class="form-control" type="text" placeholder="Enter first name.." required="required">
</div>
</div>
<div class="col-6">
<label class="form-label">Last Name</label>
<div class="input-group">
<input id="lastName" name="lastName" class="form-control" type="text" placeholder="Enter last name" required="required">
</div>
</div>
</div>
<div class="row">
<div class="col-sm-4 col-6">
<label class="form-label mt-4">I'm</label>
<select class="form-control" name="choices-gender" id="choices-gender">
<option value="Male">Male</option>
<option value="Female">Female</option>
</select>
</div>
<div class="col-sm-8">
<div class="row">
<div class="col-sm-5 col-5">
<label class="form-label mt-4">Birth Date</label>
<select class="form-control" name="choices-month" id="choices-month"></select>
</div>
<div class="col-sm-4 col-3">
<label class="form-label mt-4">&nbsp;</label>
<select class="form-control" name="choices-day" id="choices-day"></select>
</div>
<div class="col-sm-3 col-4">
<label class="form-label mt-4">&nbsp;</label>
<select class="form-control" name="choices-year" id="choices-year"></select>
</div>
</div>
</div>
</div>
<div class="row">
<div class="col-6">
<label class="form-label mt-4">Email</label>
<div class="input-group">
<input id="email" name="email" class="form-control" type="email" placeholder="example@email.com">
</div>
</div>
<div class="col-6">
<label class="form-label mt-4">Confirmation Email</label>
<div class="input-group">
<input id="confirmation" name="confirmation" class="form-control" type="email" placeholder="example@email.com">
</div>
</div>
</div>
<div class="row">
<div class="col-6">
<label class="form-label mt-4">Your location</label>
<div class="input-group">
<input id="location" name="location" class="form-control" type="text" placeholder="Sydney, A">
</div>
</div>
<div class="col-6">
<label class="form-label mt-4">Phone Number</label>
<div class="input-group">
<input id="phone" name="phone" class="form-control" type="number" placeholder="+40 735 631 620">
</div>
</div>
</div>
<div class="row">
<div class="col-md-6 align-self-center">
<label class="form-label mt-4">Language</label>
<select class="form-control" name="choices-language" id="choices-language">
<option value="English">English</option>
<option value="French">French</option>
<option value="Spanish">Spanish</option>
</select>
</div>
<div class="col-md-6">
<label class="form-label mt-4">Skills</label>
<input class="form-control" id="choices-skills" type="text" value="vuejs, angular, react" placeholder="Enter something">
</div>
</div>
</div>
</div>

<div class="card mt-4" id="password">
<div class="card-header">
<h5>Change Password</h5>
</div>
<div class="card-body pt-0">
<label class="form-label">Current password</label>
<div class="form-group">
<input class="form-control" type="password" placeholder="Current password">
</div>
<label class="form-label">New password</label>
<div class="form-group">
<input class="form-control" type="password" placeholder="New password">
</div>
<label class="form-label">Confirm new password</label>
<div class="form-group">
<input class="form-control" type="password" placeholder="Confirm password">
</div>
<h5 class="mt-5">Password requirements</h5>
<p class="text-muted mb-2">
Please follow this guide for a strong password:
</p>
<ul class="text-muted ps-4 mb-0 float-start">
<li>
<span class="text-sm">One special characters</span>
</li>
<li>
<span class="text-sm">Min 6 characters</span>
</li>
<li>
<span class="text-sm">One number (2 are recommended)</span>
</li>
<li>
<span class="text-sm">Change it often</span>
</li>
</ul>
<button class="btn bg-gradient-dark btn-sm float-end mt-6 mb-0">Update password</button>
</div>
</div>

<div class="card mt-4" id="2fa">
<div class="card-header d-flex">
<h5 class="mb-0">Two-factor authentication</h5>
<span class="badge badge-success ms-auto">Enabled</span>
</div>
<div class="card-body">
<div class="d-flex">
<p class="my-auto">Security keys</p>
<p class="text-secondary text-sm ms-auto my-auto me-3">No Security Keys</p>
<button class="btn btn-sm btn-outline-dark mb-0" type="button">Add</button>
</div>
<hr class="horizontal dark">
<div class="d-flex">
<p class="my-auto">SMS number</p>
<p class="text-secondary text-sm ms-auto my-auto me-3">+4012374423</p>
<button class="btn btn-sm btn-outline-dark mb-0" type="button">Edit</button>
</div>
<hr class="horizontal dark">
<div class="d-flex">
<p class="my-auto">Authenticator app</p>
<p class="text-secondary text-sm ms-auto my-auto me-3">Not Configured</p>
<button class="btn btn-sm btn-outline-dark mb-0" type="button">Set up</button>
</div>
</div>
</div>

<div class="card mt-4" id="accounts">
<div class="card-header">
<h5>Accounts</h5>
<p class="text-sm">Here you can setup and manage your integration settings.</p>
</div>
<div class="card-body pt-0">
<div class="d-flex">
<img class="width-48-px" src="images/small-logos-logo-slack.svg" alt="logo_slack">
<div class="my-auto ms-3">
<div class="h-100">
<h5 class="mb-0">Slack</h5>
<a class="text-sm text-body" href="javascript:;.html">Show less <i class="fas fa-chevron-up text-xs ms-1" aria-hidden="true"></i></a>
</div>
</div>
<p class="text-sm text-secondary ms-auto me-3 my-auto">Enabled</p>
<div class="form-check form-switch my-auto">
<input class="form-check-input" checked type="checkbox" id="flexSwitchCheckDefault1">
</div>
</div>
<div class="ps-5 pt-3 ms-3">
<p class="mb-0 text-sm">You haven't added your Slack yet or you aren't authorized. Please add our Slack Bot to your account by clicking on <a href="javascript.html">here</a>. When you've added the bot, send your verification code that you have received.</p>
<div class="d-sm-flex bg-gray-100 border-radius-lg p-2 my-4">
<p class="text-sm font-weight-bold my-auto ps-sm-2">Verification Code</p>
<input class="form-control form-control-sm ms-sm-auto mt-sm-0 mt-2 w-sm-15 w-40" type="text" value="1172913" data-bs-toggle="tooltip" data-bs-placement="top" title="Copy!">
</div>
<div class="d-sm-flex bg-gray-100 border-radius-lg p-2 my-4">
<p class="text-sm font-weight-bold my-auto ps-sm-2">Connected account</p>
<h6 class="text-sm ms-auto me-3 my-auto"><a href="email-protection.html" class="__cf_email__" data-cfemail="bfd7dad3d3d0ffdccddadecbd6c9da92cbd6d291dcd0d2">[email&nbsp;protected]</a></h6>
<button class="btn btn-sm bg-gradient-danger my-sm-auto mt-2 mb-0" type="button" name="button">Delete</button>
</div>
</div>
<hr class="horizontal dark">
<div class="d-flex">
<img class="width-48-px" src="images/small-logos-logo-spotify.svg" alt="logo_spotify">
<div class="my-auto ms-3">
<div class="h-100">
<h5 class="mb-0">Spotify</h5>
<p class="mb-0 text-sm">Music</p>
</div>
</div>
<p class="text-sm text-secondary ms-auto me-3 my-auto">Enabled</p>
<div class="form-check form-switch my-auto">
<input class="form-check-input" checked type="checkbox" id="flexSwitchCheckDefault2">
</div>
</div>
<hr class="horizontal dark">
<div class="d-flex">
<img class="width-48-px" src="images/small-logos-logo-atlassian.svg" alt="logo_atlassian">
<div class="my-auto ms-3">
<div class="h-100">
<h5 class="mb-0">Atlassian</h5>
<p class="mb-0 text-sm">Payment vendor</p>
</div>
</div>
<p class="text-sm text-secondary ms-auto me-3 my-auto">Enabled</p>
<div class="form-check form-switch my-auto">
<input class="form-check-input" checked type="checkbox" id="flexSwitchCheckDefault3">
</div>
</div>
<hr class="horizontal dark">
<div class="d-flex">
<img class="width-48-px" src="images/small-logos-logo-asana.svg" alt="logo_asana">
<div class="my-auto ms-3">
<div class="h-100">
<h5 class="mb-0">Asana</h5>
<p class="mb-0 text-sm">Organize your team</p>
</div>
</div>
<div class="form-check form-switch ms-auto my-auto">
<input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault4">
</div>
</div>
</div>
</div>

<div class="card mt-4" id="notifications">
<div class="card-header">
<h5>Notifications</h5>
<p class="text-sm">Choose how you receive notifications. These notification settings apply to the things you&rsquo;re watching.</p>
</div>
<div class="card-body pt-0">
<div class="table-responsive">
<table class="table mb-0">
<thead>
<tr>
<th class="ps-1" colspan="4">
<p class="mb-0">Activity</p>
</th>
<th class="text-center">
<p class="mb-0">Email</p>
</th>
<th class="text-center">
<p class="mb-0">Push</p>
</th>
<th class="text-center">
<p class="mb-0">SMS</p>
</th>
</tr>
</thead>
<tbody>
<tr>
<td class="ps-1" colspan="4">
<div class="my-auto">
<span class="text-dark d-block text-sm">Mentions</span>
<span class="text-xs font-weight-normal">Notify when another user mentions you in a comment</span>
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" checked type="checkbox" id="flexSwitchCheckDefault11">
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault12">
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault13">
</div>
</td>
</tr>
<tr>
<td class="ps-1" colspan="4">
<div class="my-auto">
<span class="text-dark d-block text-sm">Comments</span>
<span class="text-xs font-weight-normal">Notify when another user comments your item.</span>
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" checked type="checkbox" id="flexSwitchCheckDefault14">
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" checked type="checkbox" id="flexSwitchCheckDefault15">
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault16">
</div>
</td>
</tr>
<tr>
<td class="ps-1" colspan="4">
<div class="my-auto">
<span class="text-dark d-block text-sm">Follows</span>
<span class="text-xs font-weight-normal">Notify when another user follows you.</span>
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault17">
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" checked type="checkbox" id="flexSwitchCheckDefault18">
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault19">
</div>
</td>
</tr>
<tr>
<td class="ps-1" colspan="4">
<div class="my-auto">
<p class="text-sm mb-0">Log in from a new device</p>
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" checked type="checkbox" id="flexSwitchCheckDefault20">
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" checked type="checkbox" id="flexSwitchCheckDefault21">
</div>
</td>
<td>
<div class="form-check form-switch mb-0 d-flex align-items-center justify-content-center">
<input class="form-check-input" checked type="checkbox" id="flexSwitchCheckDefault22">
</div>
</td>
</tr>
</tbody>
</table>
</div>
</div>
</div>

<div class="card mt-4" id="sessions">
<div class="card-header pb-3">
<h5>Sessions</h5>
<p class="text-sm">This is a list of devices that have logged into your account. Remove those that you do not recognize.</p>
</div>
<div class="card-body pt-0">
<div class="d-flex align-items-center">
<div class="text-center w-5">
<i class="fas fa-desktop text-lg opacity-6"></i>
</div>
<div class="my-auto ms-3">
<div class="h-100">
<p class="text-sm mb-1">
Bucharest 68.133.163.201
</p>
<p class="mb-0 text-xs">
Your current session
</p>
</div>
</div>
<span class="badge badge-success badge-sm my-auto ms-auto me-3">Active</span>
<p class="text-secondary text-sm my-auto me-3">EU</p>
<a href="javascript:;.html" class="text-primary text-sm icon-move-right my-auto">See more
<i class="fas fa-arrow-right text-xs ms-1" aria-hidden="true"></i>
</a>
</div>
<hr class="horizontal dark">
<div class="d-flex align-items-center">
<div class="text-center w-5">
<i class="fas fa-desktop text-lg opacity-6"></i>
</div>
<p class="my-auto ms-3">Chrome on macOS</p>
<p class="text-secondary text-sm ms-auto my-auto me-3">US</p>
<a href="javascript:;.html" class="text-primary text-sm icon-move-right my-auto">See more
<i class="fas fa-arrow-right text-xs ms-1" aria-hidden="true"></i>
</a>
</div>
<hr class="horizontal dark">
<div class="d-flex align-items-center">
<div class="text-center w-5">
<i class="fas fa-mobile text-lg opacity-6"></i>
</div>
<p class="my-auto ms-3">Safari on iPhone</p>
<p class="text-secondary text-sm ms-auto my-auto me-3">US</p>
<a href="javascript:;.html" class="text-primary text-sm icon-move-right my-auto">See more
<i class="fas fa-arrow-right text-xs ms-1" aria-hidden="true"></i>
</a>
</div>
</div>
</div>

<div class="card mt-4" id="delete">
<div class="card-header">
<h5>Delete Account</h5>
<p class="text-sm mb-0">Once you delete your account, there is no going back. Please be certain.</p>
</div>
<div class="card-body d-sm-flex pt-0">
<div class="d-flex align-items-center mb-sm-0 mb-4">
<div>
<div class="form-check form-switch mb-0">
<input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault0">
</div>
</div>
<div class="ms-2">
<span class="text-dark font-weight-bold d-block text-sm">Confirm</span>
<span class="text-xs d-block">I want to delete my account.</span>
</div>
</div>
<button class="btn btn-outline-secondary mb-0 ms-auto" type="button" name="button">Deactivate</button>
<button class="btn bg-gradient-danger mb-0 ms-2" type="button" name="button">Delete Account</button>
</div>
</div>
</div>
</div>
<footer class="footer pt-3  ">
<div class="container-fluid">
<div class="row align-items-center justify-content-lg-between">
<div class="col-lg-6 mb-lg-0 mb-4">
<div class="copyright text-center text-sm text-muted text-lg-start">
&copy; <script data-cfasync="false" src="js/cloudflare-static-email-decode.min.js"></script><script>
                  document.write(new Date().getFullYear())
                </script>,
made with <i class="fa fa-heart"></i> by
<a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Creative Tim</a>
for a better web.
</div>
</div>
<div class="col-lg-6">
<ul class="nav nav-footer justify-content-center justify-content-lg-end">
<li class="nav-item">
<a href="https://www.creative-tim.com" class="nav-link text-muted" target="_blank">Creative Tim</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/presentation" class="nav-link text-muted" target="_blank">About Us</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/blog" class="nav-link text-muted" target="_blank">Blog</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/license" class="nav-link pe-0 text-muted" target="_blank">License</a>
</li>
</ul>
</div>
</div>
</div>
</footer>
</div>
</main>
<div class="fixed-plugin">
<a class="fixed-plugin-button text-dark position-fixed px-3 py-2" href="account.html">
<i class="fa fa-cog py-2"> </i>
</a>
<div class="card shadow-lg blur">
<div class="card-header pb-0 pt-3  bg-transparent ">
<div class="float-start">
<h5 class="mt-3 mb-0">Soft UI Configurator</h5>
<p>See our dashboard options.</p>
</div>
<div class="float-end mt-4">
<button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
<i class="fa fa-close"></i>
</button>
</div>

</div>
<hr class="horizontal dark my-1">
<div class="card-body pt-sm-3 pt-0">

<div>
<h6 class="mb-0">Sidebar Colors</h6>
</div>
<a href="javascript:void(0)" class="switch-trigger background-color">
<div class="badge-colors my-2 text-start">
<span class="badge filter bg-gradient-primary active" data-color="primary" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-dark" data-color="dark" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-info" data-color="info" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-success" data-color="success" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-warning" data-color="warning" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-danger" data-color="danger" onclick="sidebarColor(this)"></span>
</div>
</a>

<div class="mt-3">
<h6 class="mb-0">Sidenav Type</h6>
<p class="text-sm">Choose between 2 different sidenav types.</p>
</div>
<div class="d-flex">
<button class="btn bg-gradient-primary w-100 px-3 mb-2 active" data-class="bg-transparent" onclick="sidebarType(this)">Transparent</button>
<button class="btn bg-gradient-primary w-100 px-3 mb-2 ms-2" data-class="bg-white" onclick="sidebarType(this)">White</button>
</div>
<p class="text-sm d-xl-none d-block mt-2">You can change the sidenav type just on desktop view.</p>

<div class="mt-3">
<h6 class="mb-0">Navbar Fixed</h6>
</div>
<div class="form-check form-switch ps-0">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarFixed" onclick="navbarFixed(this)">
</div>
<hr class="horizontal dark mb-1 d-xl-block d-none">
<div class="mt-2 d-xl-block d-none">
<h6 class="mb-0">Sidenav Mini</h6>
</div>
<div class="form-check form-switch ps-0 d-xl-block d-none">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarMinimize" onclick="navbarMinimize(this)">
</div>
<hr class="horizontal dark mb-1 d-xl-block d-none">
<div class="mt-2 d-xl-block d-none">
<h6 class="mb-0">Light/Dark</h6>
</div>
<div class="form-check form-switch ps-0 d-xl-block d-none">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="dark-version" onclick="darkMode(this)">
</div>
<hr class="horizontal dark my-sm-4">
<a class="btn bg-gradient-info w-100" href="https://www.creative-tim.com/product/soft-ui-dashboard-pro">Buy now</a>
<a class="btn bg-gradient-dark w-100" href="https://www.creative-tim.com/product/soft-ui-dashboard">Free demo</a>
<a class="btn btn-outline-dark w-100" href="https://www.creative-tim.com/learning-lab/bootstrap/overview/soft-ui-dashboard">View documentation</a>
<div class="w-100 text-center">
<a class="github-button" href="https://github.com/creativetimofficial/ct-soft-ui-dashboard-pro" data-icon="octicon-star" data-size="large" data-show-count="true" aria-label="Star creativetimofficial/soft-ui-dashboard on GitHub">Star</a>
<h6 class="mt-3">Thank you for sharing!</h6>
<a href="https://twitter.com/intent/tweet?text=Check%20Soft%20UI%20Dashboard%20PRO%20made%20by%20%40CreativeTim%20%23webdesign%20%23dashboard%20%23bootstrap5&amp;url=https%3A%2F%2Fwww.creative-tim.com%2Fproduct%2Fsoft-ui-dashboard-pro" class="btn btn-dark mb-0 me-2" target="_blank">
<i class="fab fa-twitter me-1" aria-hidden="true"></i> Tweet
</a>
<a href="https://www.facebook.com/sharer/sharer.php?u=https://www.creative-tim.com/product/soft-ui-dashboard-pro" class="btn btn-dark mb-0 me-2" target="_blank">
<i class="fab fa-facebook-square me-1" aria-hidden="true"></i> Share
</a>
</div>
</div>
</div>
</div>

<script src="js/core-popper.min.js"></script>
<script src="js/core-bootstrap.min.js"></script>
<script src="js/plugins-perfect-scrollbar.min.js"></script>
<script src="js/plugins-smooth-scrollbar.min.js"></script>
<script src="js/plugins-choices.min.js"></script>

<script src="js/dragula-dragula.min.js"></script>
<script src="js/jkanban-jkanban.js"></script>
<script>
    if (document.getElementById('choices-gender')) {
      var gender = document.getElementById('choices-gender');
      const example = new Choices(gender);
    }

    if (document.getElementById('choices-language')) {
      var language = document.getElementById('choices-language');
      const example = new Choices(language);
    }

    if (document.getElementById('choices-skills')) {
      var skills = document.getElementById('choices-skills');
      const example = new Choices(skills, {
        delimiter: ',',
        editItems: true,
        maxItemCount: 5,
        removeItemButton: true,
        addItems: true
      });
    }

    if (document.getElementById('choices-year')) {
      var year = document.getElementById('choices-year');
      setTimeout(function() {
        const example = new Choices(year);
      }, 1);

      for (y = 1900; y <= 2020; y++) {
        var optn = document.createElement("OPTION");
        optn.text = y;
        optn.value = y;

        if (y == 2020) {
          optn.selected = true;
        }

        year.options.add(optn);
      }
    }

    if (document.getElementById('choices-day')) {
      var day = document.getElementById('choices-day');
      setTimeout(function() {
        const example = new Choices(day);
      }, 1);


      for (y = 1; y <= 31; y++) {
        var optn = document.createElement("OPTION");
        optn.text = y;
        optn.value = y;

        if (y == 1) {
          optn.selected = true;
        }

        day.options.add(optn);
      }

    }

    if (document.getElementById('choices-month')) {
      var month = document.getElementById('choices-month');
      setTimeout(function() {
        const example = new Choices(month);
      }, 1);

      var d = new Date();
      var monthArray = new Array();
      monthArray[0] = "January";
      monthArray[1] = "February";
      monthArray[2] = "March";
      monthArray[3] = "April";
      monthArray[4] = "May";
      monthArray[5] = "June";
      monthArray[6] = "July";
      monthArray[7] = "August";
      monthArray[8] = "September";
      monthArray[9] = "October";
      monthArray[10] = "November";
      monthArray[11] = "December";
      for (m = 0; m <= 11; m++) {
        var optn = document.createElement("OPTION");
        optn.text = monthArray[m];
        // server side month start from one
        optn.value = (m + 1);
        // if june selected
        if (m == 1) {
          optn.selected = true;
        }
        month.options.add(optn);
      }
    }

    function visible() {
      var elem = document.getElementById('profileVisibility');
      if (elem) {
        if (elem.innerHTML == "Switch to visible") {
          elem.innerHTML = "Switch to invisible"
        } else {
          elem.innerHTML = "Switch to visible"
        }
      }
    }

    var openFile = function(event) {
      var input = event.target;

      // Instantiate FileReader
      var reader = new FileReader();
      reader.onload = function() {
        imageFile = reader.result;

        document.getElementById("imageChange").innerHTML = '<img width="200" src="' + imageFile + '" class="rounded-circle w-100 shadow" />';
      };
      reader.readAsDataURL(input.files[0]);
    };
  </script>
<script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>

<script async defer src="js/buttons.github.io-buttons.js"></script>

<script src="js/js-soft-ui-dashboard.min.js"></script>
</body>
</html>
