<?php
 $complaint_id = $_GET['complaint_id'];
 $user_id = $_GET['user_id'];

include '../templates/connection.inc.php"';

$getdata = $conn->query("SELECT * FROM `complaints` WHERE `complaint_id`='$complaint_id'");

$uploaddata = [];
if($getdata->num_rows>0){
    while($data = $getdata->fetch_assoc()){
        $uploaddata[]=$data;
    }
}


?>


<?php
$depdata = $conn->query("SELECT * FROM `department`");
$uploaddep = [];
if($depdata->num_rows>0){
    while($getdep= $depdata->fetch_assoc()){
        $uploaddep[]=$getdep;
    }
}

?>

<?php
$desdata = $conn->query("SELECT * FROM `designation`");
$uploaddes = [];
if($desdata->num_rows>0){
    while($getdes= $desdata->fetch_assoc()){
        $uploaddes[]=$getdes;
    }
}

?>
<?php
$getemp = $conn->query("SELECT * FROM `employee`");
$uploademp = [];
if($getemp->num_rows>0){
    while($empdata = $getemp->fetch_assoc()){
        $uploademp[]=$empdata;
    }
}
?>
<?php


$getuserdata = $conn->query("SELECT * FROM `users` WHERE `user_id`= '$user_id'");
$userdata = [];
if($getuserdata->num_rows>0){
  while($putuser = $getuserdata->fetch_assoc()){
    $userdata[] = $putuser;
  
    

  }
}
?>
<?php


$getcitydata = $conn->query("SELECT * FROM `users`");
$city = [];
if($getcitydata->num_rows>0){
  while($putuser = $getcitydata->fetch_assoc()){
    $city[] = $putuser;
  
    

  }
}
json_encode($city);
?>
<?php
$complaintdetails = $conn->query("SELECT * FROM `employee_complaints` WHERE `complaint_id`='$complaint_id'");
$comDetails = [];
if($complaintdetails->num_rows>0){
  while($getdetails = $complaintdetails->fetch_assoc()){
    $comDetails[]=$getdetails;
  }
}
?>
<?php


// $gettalukdata = $conn->query("SELECT `taluk` FROM `users`");
// $taluk = [];
// if($gettalukdata->num_rows>0){
//   while($putuser = $gettalukdata->fetch_assoc()){
//     $taluk[] = $putuser;
  
    

//   }
// }
// json_encode($taluk);
?>
<?php


$getdata = $conn->query("SELECT * FROM `accused_data` WHERE `complaint_id`='$complaint_id'");
$accuseddata = [];
if($getdata->num_rows>0){
  while($putaccused = $getdata->fetch_assoc()){
   $accuseddata[] = $putaccused;
  
    

  }
}
?>


<!DOCTYPE html>
<!--
=========================================================
* Soft UI Dashboard PRO - v1.1.1
=========================================================

* Product Page:  https://www.creative-tim.com/product/soft-ui-dashboard-pro 
* Copyright 2023 Creative Tim (https://www.creative-tim.com)
* Coded by Creative Tim

=========================================================

* The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
--><html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="apple-touch-icon" sizes="76x76" href="../images/g_logo.png">
<link rel="icon" type="image/png" href="../images/g_logo.png">
<title>
    View all Complaints
  </title>


<link rel="canonical" href="https://www.creative-tim.com/product/soft-ui-dashboard-pro">

<meta name="keywords" content="creative tim, html dashboard, html css dashboard, web dashboard, bootstrap 5 dashboard, bootstrap 5, css3 dashboard, bootstrap 5 admin, soft ui dashboard bootstrap 5 dashboard, frontend, responsive bootstrap 5 dashboard, soft design, soft dashboard bootstrap 5 dashboard">
<meta name="description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">

<meta name="twitter:card" content="product">
<meta name="twitter:site" content="@creativetim">
<meta name="twitter:title" content="Soft UI Dashboard PRO by Creative Tim">
<meta name="twitter:description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">
<meta name="twitter:creator" content="@creativetim">
<meta name="twitter:image" content="https://s3.amazonaws.com/creativetim_bucket/products/487/thumb/opt_sdp_thumbnail.jpg">

<meta property="fb:app_id" content="655968634437471">
<meta property="og:title" content="Soft UI Dashboard PRO by Creative Tim">
<meta property="og:type" content="article">
<meta property="og:url" content="https://demos.creative-tim.com/soft-ui-dashboard-pro/pages/dashboards/default.html">
<meta property="og:image" content="https://s3.amazonaws.com/creativetim_bucket/products/487/thumb/opt_sdp_thumbnail.jpg">
<meta property="og:description" content="Soft UI Dashboard PRO is a beautiful Bootstrap 5 admin dashboard with a large number of components, designed to look beautiful, clean and organized. If you are looking for a tool to manage dates about your business, this dashboard is the thing for you.">
<meta property="og:site_name" content="Creative Tim">

<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">

<link href="css/css-nucleo-icons.css" rel="stylesheet">
<link href="css/css-nucleo-svg.css" rel="stylesheet">

<script src="js/42d5adcbca.js" crossorigin="anonymous"></script>
<link href="css/css-nucleo-svg.css" rel="stylesheet">

<link id="pagestyle" href="css/css-soft-ui-dashboard.min.css" rel="stylesheet">

<style>
    .async-hide {
      opacity: 0 !important
    }
  </style>



</head>
<body class="g-sidenav-show  bg-gray-100">


<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-NKDMSK6" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>



<main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">

<nav class="navbar navbar-main navbar-expand-lg position-sticky mt-4 top-1 px-0 mx-4 shadow-none border-radius-xl z-index-sticky" id="navbarBlur" data-scroll="true">
<div class="container-fluid py-1 px-3">
<nav aria-label="breadcrumb">
<ol class="breadcrumb bg-transparent mb-0 pb-0 pt-1 px-0 me-sm-6 me-5">
<li class="breadcrumb-item text-sm">
<a class="opacity-3 text-dark" href="javascript:;.html">
<svg width="12px" height="12px" class="mb-1" viewbox="0 0 45 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<title>view Complaints</title>
<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
<g transform="translate(-1716.000000, -439.000000)" fill="#252f40" fill-rule="nonzero">
<g transform="translate(1716.000000, 291.000000)">
<g transform="translate(0.000000, 148.000000)">
</g>
</g>
</g>
</g>
</svg>
</a>
</li>
</ol>
<h6 class="font-weight-bolder mb-0">Complaint View</h6>
</nav>
</div>
</nav>

<div class="container-fluid py-4">
<div class="row">
<div class="col-12">
<div class="card">
<div class="card-body">
<?php foreach($uploaddata as $row):?>
<h5 class="mb-4"><?php echo "Complaint_id:". $row['complaint_id']?></h5>
<div class="row">
<div class="col-xl-5 col-lg-6 text-center">
<video class="w-100 border-radius-lg shadow-lg mx-auto"  id="videoPlayer" controls>
<source id="videoSource" src="" type="video/mp4">
</video>
<script>
        const videoId = 1;
        document.getElementById('videoSource').src ="../admin/pages/<?php echo $row['video'] ?>";
        document.getElementById('videoPlayer').load();
    </script>
    <?php endforeach?>
<!-- <img class="w-100 border-radius-lg shadow-lg mx-auto" src="images/photo-1616627781431-23b776aad6b2" alt="chair"> -->
 <?php foreach ($uploaddata as $row):?>
<div class="my-gallery d-flex mt-4 pt-2" itemscope itemtype="http://schema.org/ImageGallery">
<figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
<a href="../admin/pages/<?php echo $row['image']?>" itemprop="contentUrl" data-size="500x600">
<img class="w-75 min-height-100 max-height-100 border-radius-lg shadow" src="../admin/pages/<?php echo $row['image']?>" alt="Image description">
</a>
</figure>
<figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
<a href="../admin/pages/<?php echo $row['image']?>" itemprop="contentUrl" data-size="500x600">
<img class="w-75 min-height-100 max-height-100 border-radius-lg shadow" src="../admin/pages/<?php echo $row['image']?>" itemprop="thumbnail" alt="Image description">
</a>
</figure>
<figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
<a href="../admin/pages/<?php echo $row['image']?>" itemprop="contentUrl" data-size="500x600">
<img class="w-75 min-height-100 max-height-100 border-radius-lg shadow" src="../admin/pages/<?php echo $row['image']?>" itemprop="thumbnail" alt="Image description">
</a>
</figure>
<figure itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
<a href="../admin/pages<?php echo $row['audio'] ?>" itemprop="contentUrl" data-size="500x600">
<audio id="audioPlayer" controls>
    <source id="audioSource" src="" type="audio/mp3">
</audio>
<script>
    const audioId = 1;
    document.getElementById('audioSource').src = "../admin/pages<?php echo $row['audio'] ?>";
    document.getElementById('audioPlayer').load();
</script>


<!-- <img class="w-75 min-height-100 max-height-100 border-radius-lg shadow" src="images/ecommerce-chair-wood.jpg" itemprop="thumbnail" alt="Image description"> -->
</a>
<?php endforeach;?>
</figure>


</div>

<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

<div class="pswp__bg"></div>

<div class="pswp__scroll-wrap">


<div class="pswp__container">
<div class="pswp__item"></div>
<div class="pswp__item"></div>
<div class="pswp__item"></div>
</div>

<div class="pswp__ui pswp__ui--hidden">
<div class="pswp__top-bar">

<div class="pswp__counter"></div>
<button class="btn btn-white btn-sm pswp__button pswp__button--close">Close (Esc)</button>
<button class="btn btn-white btn-sm pswp__button pswp__button--fs">Fullscreen</button>
<button class="btn btn-white btn-sm pswp__button pswp__button--arrow--left">Prev
</button>
<button class="btn btn-white btn-sm pswp__button pswp__button--arrow--right">Next
</button>


<div class="pswp__preloader">
<div class="pswp__preloader__icn">
<div class="pswp__preloader__cut">
<div class="pswp__preloader__donut"></div>
</div>
</div>
</div>
</div>
<div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
<div class="pswp__share-tooltip"></div>
</div>
<div class="pswp__caption">
<div class="pswp__caption__center"></div>
</div>
</div>
</div>
</div>
</div>
<?php foreach($uploaddata as $row):?>
<div class="col-lg-5 mx-auto">
<h3 class="mt-lg-0 mt-4"><?php echo $row['complaint_title'] ?></h3>
<h5 class="mb-0 mt-3"><?php  echo $row['issue']?></h5>
<h6 class="mt-lg-0 mt-4"><?php echo"priority :" . $row['priority']?></h6>
<?php endforeach?>
<h4 class="mt-4">Description</h4>
<ul>
<?php foreach($uploaddata as $row):?>
<li><?php echo $row['issue_detail']?></li>
<?php endforeach?>
</ul>
<h5 class="mt-4">Solved By:</h5>
<div class="row mt-4">
<div class="col-lg-6">
<label>Employee Complaint Id:</label>
<?php  foreach($comDetails as $row): ?>
  <p><?php echo $row['empcom_id']?></p>
<?php endforeach;?>
</div>
<div class="col-lg-6">
<label>Name:</label>
<?php foreach($comDetails  as $row):?>
  <p><?php echo $row['eployee_name']?></p>
<?php endforeach;?>
</select>
</div>

<div class="col-lg-6">
<label>Employee Id:</label>
<?php  foreach($comDetails as $row): ?>
  <p><?php echo $row['employee_id']?></p>
<?php endforeach;?>
</div>
<div class="col-lg-6">
<label>Department:</label>
<?php  foreach($comDetails as $row): ?>
  <p><?php echo $row['department']?></p>
<?php endforeach;?>
</div>
<div class="col-lg-6">
<label>Designation:</label>
<?php  foreach($comDetails as $row): ?>
  <p><?php echo $row['designation']?></p>
<?php endforeach;?>
</div>
<div class="col-lg-6">
<label>District:</label>
<?php  foreach($comDetails as $row): ?>
  <p><?php echo $row['district']?></p>
<?php endforeach;?>
</div>
</div>
<div class="row mt-4">
<div class="col-lg-5">
<button class="btn bg-gradient-primary mb-0 mt-lg-auto w-100" type="submit" name="submit" >View Timeline</button>
</div>
</div>
</div>
</div>
<div class="row mt-5">
<div class="col-12">
<h5 class="ms-3">User information</h5>
<div class="table table-responsive">
<table class="table align-items-center mb-0">
<thead>
<tr>
<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Name</th>
<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Gender</th>
<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Phone</th>
<th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">address</th>
<th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Pincode</th>
</tr>
</thead>
<tbody>
<?php foreach($userdata as  $row):?>
<tr>
<td>
<div class="d-flex px-2 py-1">
<div>
<img src="images/ecommerce-black-chair.jpg" class="avatar avatar-md me-3" alt="table image">
</div>
<div class="d-flex flex-column justify-content-center">
<h6 class="mb-0 text-sm"><?php echo $row['username']?></h6>
</div>
</div>
</td>
<td>
<p class="text-sm text-secondary mb-0"><?php echo $row['gender']?></p>
</td>
<td>
<p class="text-sm text-secondary mb-0"><?php echo $row['phone']?></p>
</td>
<td class="align-middle text-sm">
<p class="text-sm text-secondary mb-0"><?php echo $row['address']?></p>
</td>
<td class="align-middle text-center">
<span class="text-secondary text-sm"><?php echo $row['pincode']?></span>
</td>
</tr>
<?php endforeach;?>
</tbody>
</table>
<div class="row mt-5">
<div class="col-12">
<h5 class="ms-3">Accused information</h5>
<div class="table table-responsive">
<table class="table align-items-center mb-0">
<thead>
<tr>
<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Name</th>
<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Gender</th>
<th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Phone</th>
<th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">address</th>
<th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Designation</th>
</tr>
</thead>
<tbody>
<?php foreach($accuseddata as $row):?>
<tr>
<td>
<div class="d-flex px-2 py-1">
<div>
<img src="images/ecommerce-black-chair.jpg" class="avatar avatar-md me-3" alt="table image">
</div>

<div class="d-flex flex-column justify-content-center">

<h6 class="mb-0 text-sm"><?php echo $row['accused_name']?></h6>

</div>

</div>
</td>
<td>
<p class="text-sm text-secondary mb-0"><?php echo $row['accused_gender']?></p>
</td>
<td>
<p class="text-sm text-secondary mb-0"><?php echo $row['accused_mobile']?></p>
</td>
<td class="align-middle text-sm">
<p class="text-sm text-secondary mb-0"><?php echo $row['accused_address']?></p>
</td>
<td class="align-middle text-center">
<span class="text-secondary text-sm"><p class="text-sm text-secondary mb-0"><?php echo $row['accused_designation']?></p></span>
</td>

</tr>
<?php endforeach;?>
</tbody>
</table>

</div>
</div>

</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<footer class="footer pt-3  ">
<div class="container-fluid">
<div class="row align-items-center justify-content-lg-between">
<div class="col-lg-6 mb-lg-0 mb-4">
<div class="copyright text-center text-sm text-muted text-lg-start">
&copy; <script>
                  document.write(new Date().getFullYear())
                </script>,
made with <i class="fa fa-heart"></i> by
<a href="https://www.creative-tim.com" class="font-weight-bold" target="_blank">Zilitech</a>
for a better web.
</div>
</div>
<div class="col-lg-6">
<ul class="nav nav-footer justify-content-center justify-content-lg-end">
<li class="nav-item">
<a href="https://www.creative-tim.com" class="nav-link text-muted" target="_blank">Zilitech</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/presentation" class="nav-link text-muted" target="_blank">About Us</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/blog" class="nav-link text-muted" target="_blank">Blog</a>
</li>
<li class="nav-item">
<a href="https://www.creative-tim.com/license" class="nav-link pe-0 text-muted" target="_blank">License</a>
</li>
</ul>
</div>
</div>
</div>
</footer>
</div>
</main>
<div class="fixed-plugin">
<a class="fixed-plugin-button text-dark position-fixed px-3 py-2" href="products.html">
<i class="fa fa-cog py-2"> </i>
</a>
<div class="card shadow-lg blur">
<div class="card-header pb-0 pt-3  bg-transparent ">
<div class="float-start">
<h5 class="mt-3 mb-0">Soft UI Configurator</h5>
<p>See our dashboard options.</p>
</div>
<div class="float-end mt-4">
<button class="btn btn-link text-dark p-0 fixed-plugin-close-button">
<i class="fa fa-close"></i>
</button>
</div>

</div>
<hr class="horizontal dark my-1">
<div class="card-body pt-sm-3 pt-0">

<div>
<h6 class="mb-0">Sidebar Colors</h6>
</div>
<a href="javascript:void(0)" class="switch-trigger background-color">
<div class="badge-colors my-2 text-start">
<span class="badge filter bg-gradient-primary active" data-color="primary" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-dark" data-color="dark" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-info" data-color="info" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-success" data-color="success" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-warning" data-color="warning" onclick="sidebarColor(this)"></span>
<span class="badge filter bg-gradient-danger" data-color="danger" onclick="sidebarColor(this)"></span>
</div>
</a>

<div class="mt-3">
<h6 class="mb-0">Sidenav Type</h6>
<p class="text-sm">Choose between 2 different sidenav types.</p>
</div>
<div class="d-flex">
<button class="btn bg-gradient-primary w-100 px-3 mb-2 active" data-class="bg-transparent" onclick="sidebarType(this)">Transparent</button>
<button class="btn bg-gradient-primary w-100 px-3 mb-2 ms-2" data-class="bg-white" onclick="sidebarType(this)">White</button>
</div>
<p class="text-sm d-xl-none d-block mt-2">You can change the sidenav type just on desktop view.</p>

<div class="mt-3">
<h6 class="mb-0">Navbar Fixed</h6>
</div>
<div class="form-check form-switch ps-0">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarFixed" onclick="navbarFixed(this)">
</div>
<hr class="horizontal dark mb-1 d-xl-block d-none">
<div class="mt-2 d-xl-block d-none">
<h6 class="mb-0">Sidenav Mini</h6>
</div>
<div class="form-check form-switch ps-0 d-xl-block d-none">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="navbarMinimize" onclick="navbarMinimize(this)">
</div>
<hr class="horizontal dark mb-1 d-xl-block d-none">
<div class="mt-2 d-xl-block d-none">
<h6 class="mb-0">Light/Dark</h6>
</div>
<div class="form-check form-switch ps-0 d-xl-block d-none">
<input class="form-check-input mt-1 ms-auto" type="checkbox" id="dark-version" onclick="darkMode(this)">
</div>
<hr class="horizontal dark my-sm-4">
<a class="btn bg-gradient-info w-100" href="https://www.creative-tim.com/product/soft-ui-dashboard-pro">Buy now</a>
<a class="btn bg-gradient-dark w-100" href="https://www.creative-tim.com/product/soft-ui-dashboard">Free demo</a>
<a class="btn btn-outline-dark w-100" href="https://www.creative-tim.com/learning-lab/bootstrap/overview/soft-ui-dashboard">View documentation</a>
<div class="w-100 text-center">
<a class="github-button" href="https://github.com/creativetimofficial/ct-soft-ui-dashboard-pro" data-icon="octicon-star" data-size="large" data-show-count="true" aria-label="Star creativetimofficial/soft-ui-dashboard on GitHub">Star</a>
<h6 class="mt-3">Thank you for sharing!</h6>
<a href="https://twitter.com/intent/tweet?text=Check%20Soft%20UI%20Dashboard%20PRO%20made%20by%20%40CreativeTim%20%23webdesign%20%23dashboard%20%23bootstrap5&amp;url=https%3A%2F%2Fwww.creative-tim.com%2Fproduct%2Fsoft-ui-dashboard-pro" class="btn btn-dark mb-0 me-2" target="_blank">
<i class="fab fa-twitter me-1" aria-hidden="true"></i> Tweet
</a>
<a href="https://www.facebook.com/sharer/sharer.php?u=https://www.creative-tim.com/product/soft-ui-dashboard-pro" class="btn btn-dark mb-0 me-2" target="_blank">
<i class="fab fa-facebook-square me-1" aria-hidden="true"></i> Share
</a>
</div>
</div>
</div>
</div>

<script src="js/core-popper.min.js"></script>
<script src="js/core-bootstrap.min.js"></script>
<script src="js/plugins-perfect-scrollbar.min.js"></script>
<script src="js/plugins-smooth-scrollbar.min.js"></script>
<script src="js/plugins-choices.min.js"></script>
<script src="js/plugins-photoswipe.min.js"></script>
<script src="js/plugins-photoswipe-ui-default.min.js"></script>
<script>
    if (document.getElementById('choices-quantity')) {
      var element = document.getElementById('choices-quantity');
      const example = new Choices(element, {
        searchEnabled: false,
        itemSelectText: ''
      });
    };

    if (document.getElementById('choices-material')) {
      var element = document.getElementById('choices-material');
      const example = new Choices(element, {
        searchEnabled: false,
        itemSelectText: ''
      });
    };

    if (document.getElementById('choices-colors')) {
      var element = document.getElementById('choices-colors');
      const example = new Choices(element, {
        searchEnabled: false,
        itemSelectText: ''
      });
    };

    // Gallery Carousel
    if (document.getElementById('products-carousel')) {
      var myCarousel = document.querySelector('#products-carousel')
      var carousel = new bootstrap.Carousel(myCarousel)
    }


    // Products gallery

    var initPhotoSwipeFromDOM = function(gallerySelector) {

      // parse slide data (url, title, size ...) from DOM elements
      // (children of gallerySelector)
      var parseThumbnailElements = function(el) {
        var thumbElements = el.childNodes,
          numNodes = thumbElements.length,
          items = [],
          figureEl,
          linkEl,
          size,
          item;

        for (var i = 0; i < numNodes; i++) {

          figureEl = thumbElements[i]; // <figure> element
          // include only element nodes
          if (figureEl.nodeType !== 1) {
            continue;
          }

          linkEl = figureEl.children[0]; // <a> element

          size = linkEl.getAttribute('data-size').split('x');

          // create slide object
          item = {
            src: linkEl.getAttribute('href'),
            w: parseInt(size[0], 10),
            h: parseInt(size[1], 10)
          };

          if (figureEl.children.length > 1) {
            // <figcaption> content
            item.title = figureEl.children[1].innerHTML;
          }

          if (linkEl.children.length > 0) {
            // <img> thumbnail element, retrieving thumbnail url
            item.msrc = linkEl.children[0].getAttribute('src');
          }

          item.el = figureEl; // save link to element for getThumbBoundsFn
          items.push(item);
        }

        return items;
      };

      // find nearest parent element
      var closest = function closest(el, fn) {
        return el && (fn(el) ? el : closest(el.parentNode, fn));
      };

      // triggers when user clicks on thumbnail
      var onThumbnailsClick = function(e) {
        e = e || window.event;
        e.preventDefault ? e.preventDefault() : e.returnValue = false;

        var eTarget = e.target || e.srcElement;

        // find root element of slide
        var clickedListItem = closest(eTarget, function(el) {
          return (el.tagName && el.tagName.toUpperCase() === 'FIGURE');
        });

        if (!clickedListItem) {
          return;
        }

        // find index of clicked item by looping through all child nodes
        // alternatively, you may define index via data- attribute
        var clickedGallery = clickedListItem.parentNode,
          childNodes = clickedListItem.parentNode.childNodes,
          numChildNodes = childNodes.length,
          nodeIndex = 0,
          index;

        for (var i = 0; i < numChildNodes; i++) {
          if (childNodes[i].nodeType !== 1) {
            continue;
          }

          if (childNodes[i] === clickedListItem) {
            index = nodeIndex;
            break;
          }
          nodeIndex++;
        }



        if (index >= 0) {
          // open PhotoSwipe if valid index found
          openPhotoSwipe(index, clickedGallery);
        }
        return false;
      };

      // parse picture index and gallery index from URL (#&pid=1&gid=2)
      var photoswipeParseHash = function() {
        var hash = window.location.hash.substring(1),
          params = {};

        if (hash.length < 5) {
          return params;
        }

        var vars = hash.split('&');
        for (var i = 0; i < vars.length; i++) {
          if (!vars[i]) {
            continue;
          }
          var pair = vars[i].split('=');
          if (pair.length < 2) {
            continue;
          }
          params[pair[0]] = pair[1];
        }

        if (params.gid) {
          params.gid = parseInt(params.gid, 10);
        }

        return params;
      };

      var openPhotoSwipe = function(index, galleryElement, disableAnimation, fromURL) {
        var pswpElement = document.querySelectorAll('.pswp')[0],
          gallery,
          options,
          items;

        items = parseThumbnailElements(galleryElement);

        // define options (if needed)
        options = {

          // define gallery index (for URL)
          galleryUID: galleryElement.getAttribute('data-pswp-uid'),

          getThumbBoundsFn: function(index) {
            // See Options -> getThumbBoundsFn section of documentation for more info
            var thumbnail = items[index].el.getElementsByTagName('img')[0], // find thumbnail
              pageYScroll = window.pageYOffset || document.documentElement.scrollTop,
              rect = thumbnail.getBoundingClientRect();

            return {
              x: rect.left,
              y: rect.top + pageYScroll,
              w: rect.width
            };
          }

        };

        // PhotoSwipe opened from URL
        if (fromURL) {
          if (options.galleryPIDs) {
            // parse real index when custom PIDs are used
            // http://photoswipe.com/documentation/faq.html#custom-pid-in-url
            for (var j = 0; j < items.length; j++) {
              if (items[j].pid == index) {
                options.index = j;
                break;
              }
            }
          } else {
            // in URL indexes start from 1
            options.index = parseInt(index, 10) - 1;
          }
        } else {
          options.index = parseInt(index, 10);
        }

        // exit if index not found
        if (isNaN(options.index)) {
          return;
        }

        if (disableAnimation) {
          options.showAnimationDuration = 0;
        }

        // Pass data to PhotoSwipe and initialize it
        gallery = new PhotoSwipe(pswpElement, PhotoSwipeUI_Default, items, options);
        gallery.init();
      };

      // loop through all gallery elements and bind events
      var galleryElements = document.querySelectorAll(gallerySelector);

      for (var i = 0, l = galleryElements.length; i < l; i++) {
        galleryElements[i].setAttribute('data-pswp-uid', i + 1);
        galleryElements[i].onclick = onThumbnailsClick;
      }

      // Parse URL and open gallery if it contains #&pid=3&gid=1
      var hashData = photoswipeParseHash();
      if (hashData.pid && hashData.gid) {
        openPhotoSwipe(hashData.pid, galleryElements[hashData.gid - 1], true, true);
      }
    };

    // execute above function
    initPhotoSwipeFromDOM('.my-gallery');
  </script>

<script src="js/dragula-dragula.min.js"></script>
<script src="js/jkanban-jkanban.js"></script>
<script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>

<script async defer src="js/buttons.github.io-buttons.js"></script>

<script src="js/js-soft-ui-dashboard.min.js"></script>
</body>
</html>


<!-- <script>
document.addEventListener("DOMContentLoaded", function() {
    fetchDistricts();
});

function fetchDistricts() {
    fetch('view_complaints.php') 
        .then(response => response.json())
        .then(data => {
            const districtSelect = document.getElementById('district');
            districtSelect.innerHTML = '<option value="">Select a District</option>'; 

            data.forEach(district => {
                const option = document.createElement('option');
                option.value = district.user_id;
                option.textContent = district.city; 
                districtSelect.appendChild(option);
            });
        })
        .catch(error => console.error('Error fetching districts:', error));
}

function updateTaluk() {
    const districtSelect = document.getElementById('district');
    const talukSelect = document.getElementById('taluk');

    talukSelect.innerHTML = '<option value="">Select a Taluk</option>'; 
    const districtId = districtSelect.value;

    if (districtId) {
        fetch(`view_complaints.php?user_id=${user_id}`) 
            .then(response => response.json())
            .then(data => {
                data.forEach(taluk => {
                    const option = document.createElement('option');
                    option.value = taluk.user_id; 
                    option.textContent = taluk.taluk; 
                    talukSelect.appendChild(option);
                });
            })
            .catch(error => console.error('Error fetching taluks:', error));
    }
}


document.getElementById('district').addEventListener('change', updatetaluk);
</script> -->






<?php
include '../templates/connection.inc.php';

if(isset($_POST['submit'])){

    $department = $_POST['department'];
    $designation = $_POST['designation'];
    $eployee_name = $_POST['eployee_name'];
    $district = $_POST['district'];
    $taluk = $_POST['taluk'];
    $village = $_POST['village'];
    

    $employeeComplaint_id = $conn->query("SELECT * FROM `employee_complaints`");
    if($employeeComplaint_id->num_rows>0){
      while($row = $employeeComplaint_id->fetch_assoc()){
        $complaints_id=$row['complaint_id'];
        $empcom_id = $row['empcom_id'];
      }
    }
    
    $checkComplaint =$conn->query("SELECT * FROM `employee_complaints` WHERE `complaint_id`='$complaints_id' AND `empcom_id`='$empcom_id'");
    if($checkComplaint){
    if($checkComplaint->num_rows>0){
      echo "<script type='text/javascript'>alert('This Complaint already Assigned!')</script>";
    }else{

    $getdata = $conn->query("SELECT * FROM `accused_data` WHERE `complaint_id`='$complaint_id'");

    if($getdata->num_rows>0){
      while($row=$getdata->fetch_assoc()){
        $accused_id=$row['accused_id'];

      }
    }

    $getemp = $conn->query("SELECT * FROM `employee`");
    
    if($getemp->num_rows>0){
      while($row=$getemp->fetch_assoc()){
        $employee_id=$row['emp_id'];

      }
    }

    $sql = "INSERT INTO `employee_complaints`(`complaint_id`, `department`, `designation`, `eployee_name`, `user_id`, `employee_id`, `accused_id`, `district`, `taluk`, `village`) VALUES ('$complaint_id','$department','$designation','$eployee_name','$user_id','$employee_id','$accused_id','$district','$taluk','$village')";

    if ($conn->query($sql) === true) {
        echo "<script type='text/javascript'>
            alert('Inserted successfully');
            setTimeout(function() {
                window.location.href = '../admin/pages/dashboard.php';
            }, 0000);
        </script>";
    } else {
        echo "<script type='text/javascript'>alert('Error: " . $conn->error . "');</script>";
    }
  }
}
}
?>