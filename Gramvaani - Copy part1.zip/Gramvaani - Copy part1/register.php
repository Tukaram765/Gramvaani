<?php
    
  // Page vars    
  $__title      = "Sign up - Gramvaani.com";
  $__meta_title = "Gramvaani | HTML5 Hosting Template";    
  $__meta_description = "Register in now";
  $__meta_keywords    = "Gramvaani, Raise Your Complaint,Track Your Compplaints, Feeadback";

  // Page class & id
  $__class  = "register-page";
  $__id     = "register-page";

  // Change between (true) and (false) to show or hide (Header, Footer, Live Chat Bubble).
  $__hide_header      = 'true';
  $__hide_footer      = 'true';
  $__hide_chat_bubble = 'true';

  // Include (init.php) file.
  include 'core/init.php';
      
?>

  <!-- Section I -->
  <div class="se-i">
    <!-- user-form -->
    <form class="user-form" action="register.php" method="POST" id="registerForm" style="margin-left: 40%;">
      <!-- logo -->
      <a href="index.php" class="logo">
      <img src="images/g_logow.png" class="dt-img img-fluid" alt="Gramvaani">
      <img src="images/g_logo.png" class="lt-img img-fluid" alt="Gramvaani">
      </a>
      <!-- title-1 -->
      <h1 class="title-1"><img data-src="assets/images/pages/user/raising-hands.png" class="lazy img-fluid" alt="Icon">Register Here!</h1>
      <!-- form-label -->
      <label class="form-label" for="name">
        <!-- form-input -->
        <input class="form-input" type="text" name="username" id="username" placeholder="Full Name" required>
        <!-- state -->
        <span class="state"></span>
      </label>
      <!-- form-label -->
      <label class="form-label" for="email">
        <!-- form-input -->
        <input class="form-input" type="email" name="email" id="email" placeholder="Email Address" required>
        <!-- state -->
        <span class="state"></span>
      </label>
      <label class="form-label" for="phone">
        <!-- form-input -->
        <input class="form-input" type="number" name="phone" id="phone" placeholder="Enter Mobile No." required>
        <!-- state -->
        <span class="state"></span>
      </label>
      <!-- form-label -->
      <label class="form-label" for="password">
        <!-- form-input -->
        <input class="form-input" type="password" name="pass" id="password" placeholder="Password" required>
        <!-- state -->
        <span class="state"></span>
      </label>
      <!-- buttons -->
      <div class="buttons mt-2">
        <button type="submit" class="btn btn-sm btn-fill-success shadow-off text-uppercase w-100">Sign Up</button>
      </div>
      <!-- or -->
      <div class="or mt-3 mb-3 text-center"><span>or sign up with</span></div>
      <!-- social-links -->
      <div class="social-links d-flex align-items-center justify-content-center">
        <!-- social-link -->
        <a href="https://r.search.yahoo.com/_ylt=AwrKEknBFO1mWwIAygu7HAx.;_ylu=Y29sbwNzZzMEcG9zAzMEdnRpZAMEc2VjA3Ny/RV=2/RE=1728022977/RO=10/RU=https%3a%2f%2fwww.facebook.com%2fzilitech%2f/RK=2/RS=0Y.uAcCicQ6XCXlU4x_mjGwQbBk-" class="social-link">
          <img data-src="assets/images/pages/user/facebook.svg" class="lazy img-fluid" alt="Gramvaani">
        </a>
        <!-- social-link -->
        <a href="https://zilitech.com/" class="social-link">
          <img data-src="assets/images/pages/user/google.svg" class="lazy img-fluid" alt="Gramvaani">
        </a>
        <!-- social-link -->
        <a href="#" class="social-link">
          <img data-src="assets/images/pages/user/twitter.svg" class="lazy img-fluid" alt="Gramvaani">
        </a>
      </div>
      <!-- para-2 -->
      <p class="para-2 text-center mt-3">By signing up, you confirm our<br><a href="terms.php">Terms of Use</a> and <a href="terms.php">Privacy Policy</a></p>
      <!-- comment -->
      <p class="comment text-center" style="margin-left: 40%;">Have an account? <a href="login.php">Sign in</a></p>
    </form>
    <!-- text -->
    <div class="text">
      <!-- links -->
      <div class="links d-flex align-items-center justify-content-lg-start justify-content-center">
        <a href="index.php" class="d-inline-flex">Home</a>
        <a href="kb-2.php" class="d-inline-flex">Help Center</a>
        <a href="terms.php" class="d-inline-flex">Privacy Policy</a>
      </div>
      <!-- para-3 -->
      <!-- <p class="para-3">Use of this Site is subject to express terms of use.<br>By using this site, you signify that you agree to be bound by these <a href="terms.php">Universal Terms of Service</a>.</p> -->
    </div>
  </div>

<?php
  // Footer
  include 'templates/footer.inc.php';
?>

<?php
include 'templates/connection.inc.php';
?>


<?php

include 'templates/register.inc.php';
?>


