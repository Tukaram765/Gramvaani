
<?php
include '../Gramvaani/templates/connection.inc.php';
$upload = [];
$get_feedback_review = $conn->query("SELECT * FROM `feedback`");
if($get_feedback_review->num_rows>0){
 while($row = $get_feedback_review->fetch_assoc()){
 $upload[] = $row;
 }
}
 
?>
 
 <?php
    // Page vars    
    $__title      = "Gramvaani.com";
    $__meta_title = "Gramvaani | HTML5 Gramvaani Template";    
    $__meta_description = "A digital platform that allows villagers to report grievances directly to the local authorities, track their complaints, and view updates on government services.";
    $__meta_keywords    = "Users can report issues , app notifications , feedback , User Registration";

    // Page class & id
    $__class  = "index-page";
    $__id     = "index-page";

    // Include (init.php) file.
    include 'core/init.php';
        
  ?>

  <!-- Header -->
  <header class="main-header">
    <div class="container">
      <!-- row -->
      <div class="row align-items-center">

        <!-- col -->
        <div class="col-xl-7 text-xl-left text-center">
          <!-- title-1 & para-1 -->
          <h1 class="title-1 text-uppercase mb-2 mx-xl-0 mx-auto">ನಿಮ್ಮ ಮಾತು , ನಮ್ಮ ಬದಲಾವಣೆ</h1>
          <p class="para-1 mb-2 mx-xl-0 mx-auto">ನಿಮ್ಮ ಹಳ್ಳಿಯ ಯಾವುದೇ ಸಮಸ್ಯೆಗಳು ಮತ್ತು ಕುಂದು ಕೊರತೆಗಳ ಬಗ್ಗೆ ಈ ವೇದಿಕೆಯ ಮೂಲಕ ಮೇಲಾಧಿಕಾರಿಗಳಿಗೆ ದೂರು ಸಲ್ಲಿಸಬಹುದು.</p>
          <!-- notify -->
          <div class="notify glassy mb-4">
            <div class="icon">
              <img data-src="assets/images/icons/bell.svg" class="lazy img-fluid" alt="Bell">
            </div>
            <div class="text">We don't reveal any personal information</div>
          </div>
          <!-- buttons -->
          <div class="buttons">
            <a href="admin/pages/complaint_formate.php" class="btn btn-fill-primary shadow-off mr-1 mb-md-0 mb-1">Raise complaint</a>
            <a href="../Gramvaani/timeline/check_timeline.php" class="btn btn-outline-dark shadow-off">Check Status</a>
          </div>
        </div>

        <!-- col -->
        <div class="col-xl-5 d-xl-block d-none">
          <!-- form-container -->
          <div class="form-container" id="form-container">
            <!-- header-form -->
            <form action="#" method="POST" class="header-form ml-auto" id="header-form">

              <!-- form-title -->
              <h2 class="form-title mb-2">User Login</h2>

              <!-- inputs -->
              <div class="inputs">

                <!-- form-label -->
                <label for="email" class="form-label">
                  <input type="number" name="phone" class="glassy" id="phone" placeholder="Enter phone No." required>
                </label>

                <!-- form-label -->
                <label for="password" class="form-label">
                  <input type="password" name="pass" class="glassy" id="pass" placeholder="Password" required>
                </label>

              </div>

              <a href="admin/pages/user_dashboard.php"><button type="submit" class="btn btn-fill-success shadow-off w-100 font-500 mb-2 mt-1">Login</button></a>

              <!-- hr -->
              <div class="hr position-relative"><span>Or sign up with</span></div>

              <!-- links -->
              <div class="row small-gutters mt-2">

                <!-- col -->
                <div class="col-6">
                  <a href="#" class="btn btn-outline-dark level-up shadow-off w-100 font-500"><img data-src="assets/images/icons/google.svg" class="lazy btn-icon img-fluid" alt="Google">Google</a>
                </div>

                <!-- col -->
                <div class="col-6">
                  <a href="#" class="btn btn-outline-dark level-up shadow-off w-100 font-500"><img data-src="https://cdn.pixabay.com/photo/2017/07/03/15/20/mobile-2468068_640.png" class="lazy btn-icon img-fluid" alt="Google">Phone</a>
                </div>

              </div>

              <!-- form-comment -->
              <div class="form-comment mt-2">The platform will generate performance reports, showing metrics like resolution time, the number of complaints, and unresolved grievances. This helps in monitoring government performance.<a href="terms.php">Terms and conditions</a>.</div>

            </form>
          </div>
        </div>

      </div>
    </div>
  </header>

  <!-- Section I -->
  <div class="se-i text-lg-left text-center">
    <div class="container">
      <!-- row -->
      <div class="row">
        <!-- col -->
        <div class="col-lg-3 col-6 mb-lg-0 mb-2">
          <!-- box -->
          <div class="box">
            <h2 id="number">                  <?php
include '../Gramvaani/templates/connection.inc.php';

$sql = "SELECT COUNT(*) AS total_complaints FROM complaints";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $usersc=$row['total_complaints'];
    echo $usersc;
} else {
    echo "0";
}

$conn->close();
?>
</h2>
            <h2 class="box-title mb-0">Appication accepted</h2>
          </div>
        </div>

        <!-- col -->
        <div class="col-lg-3 col-6 mb-lg-0 mb-2">
          <!-- box -->
          <div class="box">
            <h2 id="number">
            <?php
include '../Gramvaani/templates/connection.inc.php';

$sql = "SELECT COUNT(*) AS total_solved FROM complaints where `status`='solved'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalsolved=$row['total_solved'];
    echo $totalsolved;
} else {
    echo "0";
}

$conn->close();
?>
            </h2>
            <h2 class="box-title mb-0">Appication resolved</h2>
          </div>
        </div>
        <!-- col -->
        <div class="col-lg-3 col-6">
          <!-- box -->
          <div class="box">
            <h2 id="number">
            <?php

include '../Gramvaani/templates/connection.inc.php';
$sql = "SELECT COUNT(*) AS total_pending FROM complaints WHERE `status`!='solved'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalpending=$row['total_pending'];
    echo $totalpending;
} else {
    echo "0";
}

$conn->close();
?>
            </h2>
            <h2 class="box-title mb-0">Appication pending</h2>
          </div>
        </div>

        <!-- col -->
        <div class="col-lg-3 col-6">
          <!-- box -->
          <div class="box">
            <h2 id="number">
              <?php
              include '../Gramvaani/templates/connection.inc.php';

              $get_feedback = $conn->query("SELECT COUNT(*) AS count FROM `feedback`");
              if($get_feedback->num_rows>0){
                while($row = $get_feedback->fetch_assoc()){
                  echo $total_feedback = $row['count'];
                }
              }

              ?>
            </h2>
            <h2 class="box-title mb-0">Feedback recieved</h2>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Section II -->
  <div class="se-ii bg-2">
    <div class="container">
      <!-- row -->
      <div class="row align-items-center">
        <!-- col -->
        <div class="col-xl-4 col-12 text-xl-left text-center mb-xl-0 mb-5">
          <!-- title-1 -->
          <h3 class="mb-1">
            <span >A digital platform</span><br class="d-xl-block d-none">
            <span>That allows villagers to report</span><br class="d-xl-block d-none">
            <!-- <span>Management.</span><br> -->
            <span class="primary-color"> Grievances.</span>
          </h3>
          <!-- para-1 -->
          <p class="para-1 mb-0">Villagers can track the status of their complaint in real time.</p>
        </div>
        <!-- col -->
        <div class="col-xl-8 col-12">
          <!-- row -->
          <div class="row justify-content-center">
            <!-- col -->
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/complaints.png" class="lazy img-fluid" alt="complaints">
                <a href="../Gramvaani/admin/pages/complaint_formate.php"><h3 class="text mb-0">Raise Your complaints</h3></a>
              </div>
            </div>
            <!-- col -->
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/tracking.png" class="lazy img-fluid" alt="status">
                <a href="../Gramvaani/timeline/check_timeline.php"><h3 class="text mb-0">Track Your Application</h3></a>
              </div>
            </div>
            <!-- col -->
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/website.png" class="lazy img-fluid" alt="Gweb">
                <a href="https://r.search.yahoo.com/_ylt=AwrKB3NDag9nJAIApzq7HAx.;_ylu=Y29sbwNzZzMEcG9zAzEEdnRpZAMEc2VjA3Ny/RV=2/RE=1730273092/RO=10/RU=https%3a%2f%2fwww.india.gov.in%2f/RK=2/RS=mf8GXRVRhAbBuownh6S4yZ4Z0AM-"><h3 class="text mb-0">e-Govt Websites</h3></a>
              </div>
            </div>
            <!-- col -->
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/apps.png" class="lazy img-fluid" alt="Gapps">
                <a href="https://r.search.yahoo.com/_ylt=AwrPrKWCag9n7QEA_1W7HAx.;_ylu=Y29sbwNzZzMEcG9zAzEEdnRpZAMEc2VjA3Ny/RV=2/RE=1730273154/RO=10/RU=https%3a%2f%2fapps.mgov.gov.in%2f/RK=2/RS=Nu8vzMIWA9n9MToyQYu8yz416wI-"><h3 class="text mb-0">Government Apps</h3></a>
              </div>
            </div>
            <!-- col -->
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/browser.png" class="lazy img-fluid" alt="Tweb">
                <a href="https://r.search.yahoo.com/_ylt=AwrKDx2zag9noQIAs7e7HAx.;_ylu=Y29sbwNzZzMEcG9zAzEEdnRpZAMEc2VjA3Ny/RV=2/RE=1730273204/RO=10/RU=https%3a%2f%2fblog.feedspot.in%2findian_technology_blogs%2f/RK=2/RS=z.ho8bqBaEsjCPfnB9tTeeLh0QE-"><h3 class="text mb-0">Technical websites</h3></a>
              </div>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/calendar.png" class="lazy img-fluid" alt="complaints">
                <a href="https://r.search.yahoo.com/_ylt=AwrKElYBaw9n6QEAd0K7HAx.;_ylu=Y29sbwNzZzMEcG9zAzEEdnRpZAMEc2VjA3Ny/RV=2/RE=1730273282/RO=10/RU=https%3a%2f%2fwww.india.gov.in%2fcalendar/RK=2/RS=0WB7ZQwGdP5teobbLFPJpOSRCpg-"><h3 class="text mb-0">Government Holidays</h3></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Section III -->
  <div class="se-iii py-90">
    <div class="container">
      <!-- se-head -->
      <div class="se-head">
        <h3 class="se-title-1">What is Your Issue</h3>
        <h4 class="se-title-2">Raise The complaint With The</h4>
      </div>
      <!-- plans -->
      <div class="plans mb-xl-4 mb-2">
        <!-- row -->
        <div class="row mx-xl-0">
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan">

              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Electricity Issues</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Power Outages</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Voltage fluctuations</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Fault transformers</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">streetlight malfunction</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Water shortages</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Contaminated water supply</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Broken water pipes</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Improper drainage systems</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Road and Transpottation</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Potholes and damaged roads</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Lack of Proper Roads </li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Poor Public Transportation</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Bridge and culvert damage</li>
                </ul>
              </div>
            </div>
          </div>
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan popular-plan">
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Public Health</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Lack of Medical Fecilities</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Improper Waste management</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unhygienic conditions in public places</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Vector-borne diseases</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Sanitation</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Open defecation issues</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Improper toilet facilities</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Garbage collection problems</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Sewage leakage</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Education</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Poor infrastructure in schools</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Lack of teachers</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">School facility maintenance</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unavailability of learning materials</li>
                </ul>
              </div>
            </div>
          </div>
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan">
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Agricultural Concerns</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Lack of irrigation facilities</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Issues with government subsidies</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unavailability of fertilizers and seeds</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Crop insurance problems</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Welfare Schemes</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Delays in pension payments</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Issues with ration cards</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Problems with government Welfare distribution</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Non-disbursement of subsidies or grants</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Law and Order</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Safety Concerns</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Illigal activities</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Police inaction</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Domestic voilence</li>
                </ul>
              </div>
            </div>
          </div>
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan">
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Environmental Issues</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Deforestation</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Pollution in rivers or lakes</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Wild animal encroachments</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon"> Illegal sand mining</span></li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Housing and Shelter</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Issues with government housing schemes</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Dilapidated housing conditions</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Rehabilitation for displaced villagers</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Public Works</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Delayed or unfinished public construction projects</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Poor maintenance of public facilities (community centers, playgrounds)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- se-footer -->
      <div class="se-footer d-flex align-items-center justify-content-center flex-wrap">
        <!-- line -->
        <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Complaint Submission</span>
        </div>
         <!-- line -->
         <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Complaint Forwarded to Authorities</span>
        </div>
         <!-- line -->
         <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Authorities Review Complaint</span>
        </div>
        <!-- line -->
        <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Complaint Status Tracking</span>
        </div>
        <!-- line -->
        <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Grievance Resolved .</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Section IV -->
  <div class="se-iv py-90 bg-2">
    <div class="container">
      <!-- se-head -->
      <div class="se-head">
        <!-- <h3 class="se-title-1">More than just a tool</h3> -->
        <h4 class="se-title-2">Benefits of the Grievance Redressal System:</h4>
      </div>
      <!-- space -->
      <div class="space space-sm"></div>
      <!-- row -->
      <div class="row justify-content-center">
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-1">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/accessability.png" class="lazy img-fluid" alt="accessibility">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Accessibility </h4>
            <!-- box-para -->
            <p class="box-para">Villagers can submit complaints from anywhere, reducing the need for physical visits.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-2">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/accountability.png" class="lazy img-fluid" alt="accountability">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Accountability</h4>
            <!-- box-para -->
            <p class="box-para">Government departments are held accountable with automated tracking and monitoring.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-3">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/efficiency.png" class="lazy img-fluid" alt="efficiency">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Efficiency</h4>
            <!-- box-para -->
            <p class="box-para">Faster processing of grievances ensures timely resolution of issues.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-4">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/Empowerment.png" class="lazy img-fluid" alt="empowerment">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Empowerment</h4>
            <!-- box-para -->
            <p class="box-para">The system empowers villagers by giving them a voice in local governance.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-5">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/resolution.png" class="lazy img-fluid" alt="faster-issue-resolution">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Faster Issue Resolution</h4>
            <!-- box-para -->
            <p class="box-para">A formal system streamlines the process of handling grievances, which can lead to quicker resolutions compared to informal methods.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-6">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/transparency.png" class="lazy img-fluid" alt="transparency">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Transparency</h4>
            <!-- box-para -->
            <p class="box-para"> A well-defined GRS makes the process of handling grievances clear and transparent, reducing the potential for favoritism or unfair treatment</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-lg-0 mb-2">
          <!-- box -->
          <div class="box color-1">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/communication.png" class="lazy img-fluid" alt="communication">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Communication</h4>
            <!-- box-para -->
            <p class="box-para">Encourages open communication between parties, which can lead to better understanding and problem-solving.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-lg-0 mb-2">
          <!-- box -->
          <div class="box color-1">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/compliance.png" class="lazy img-fluid" alt="communication">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Legal Compliance</h4>
            <!-- box-para -->
            <p class="box-para">Helps organizations adhere to labor laws and regulations that require grievance mechanisms.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
      </div>
    </div>
  </div>



 <!-- Section VI -->
<div class="se-vi py-90 bg-2">
    <div class="container">
        <!-- se-head -->
        <div class="se-head">
            <h3 class="se-title-1">Happy Peoples!</h3>
            <h4 class="se-title-2">What Happy Peoples Have to Say?</h4>
        </div>

        <!-- Create a row for feedback items -->
        <div class="row">
            <?php foreach($upload as $put): ?>
                <!-- col -->
                <div class="col-xl-3 col-lg-6 col-md-6 col-sm-12 mb-4"> 
                    <!-- box -->
                    <div class="box">
                        <!-- user-info -->
                        <div class="user-info">
                            <img data-src="images/image.png" class="lazy avatar img-fluid" alt="Avatar">
                            <div class="name"><?php echo $put['name']; ?></div>
                            <div class="job"><?php echo $put['feedback_type']; ?></div>
                        </div>
                        <!-- quotes -->
                        <p class="quotes"><?php echo $put['feedback']; ?></p>
                    </div>
                </div>
                <!-- end col -->
            <?php endforeach; ?>
        </div>
        <!-- end row -->

        <!-- space -->
        <div class="space space-sm"></div>
        <!-- buttons -->
        <div class="buttons text-center">
            <a href="#" class="btn btn-fill-primary shadow-off">See All Testimonials</a>
        </div>
    </div>
</div>


<?php
  // FAQs
  include 'templates/faqs.inc.php';
  // Footer
  include 'templates/footer.inc.php';
?>


<?php
include 'templates/connection.inc.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
 $phone = $conn->real_escape_string($_POST['phone']);
 $pass = $conn->real_escape_string($_POST['pass']);


  $result = $conn->query("SELECT * FROM `users` WHERE `phone`='$phone' OR `pass`='$pass'");
  if($result){
    while($user= $result->fetch_assoc()){

     $dpass = $user['pass'];
    $_SESSION['phone'] = $user['phone'];
    }
  

      if( $pass == $dpass){
        echo "<script type ='text/javascript'>alert('Login Successfull!');</script>";
        header("Location:admin/pages/user_dashboard.php");
        
        
          // }
        
        
      }else{
        echo "<script type ='text/javascript'>alert('Invalid password!');</script>";
      }
        
      }

    }

$conn->close();

?>

