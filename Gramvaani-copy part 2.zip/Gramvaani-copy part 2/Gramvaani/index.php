  <?php
    
    // Page vars    
    $__title      = "Gramvaani.com";
    $__meta_title = "Gramvaani | HTML5 Gramvaani Template";    
    $__meta_description = "A digital platform that allows villagers to report grievances directly to the local authorities, track their complaints, and view updates on government services.";
    $__meta_keywords    = "Users can report issues , app notifications , feedback , User Registration";

    // Page class & id
    $__class  = "index-page";
    $__id     = "index-page";

    // Include (init.php) file.
    include 'core/init.php';
        
  ?>

  <!-- Header -->
  <header class="main-header">
    <div class="container">
      <!-- row -->
      <div class="row align-items-center">

        <!-- col -->
        <div class="col-xl-7 text-xl-left text-center">
          <!-- title-1 & para-1 -->
          <h1 class="title-1 text-uppercase mb-2 mx-xl-0 mx-auto">Grievance Redressal System</h1>
          <p class="para-1 mb-2 mx-xl-0 mx-auto">A digital platform that allows villagers to report grievances (e.g., electricity, roads, water) directly to the local authorities, track their complaints, and view updates on government services.</p>
          <!-- notify -->
          <div class="notify glassy mb-4">
            <div class="icon">
              <img data-src="assets/images/icons/bell.svg" class="lazy img-fluid" alt="Bell">
            </div>
            <div class="text">We don't reveal any personal information</div>
          </div>
          <!-- buttons -->
          <div class="buttons">
            <a href="#" class="btn btn-fill-primary shadow-off mr-1 mb-md-0 mb-1">Raise complaint</a>
            <a href="#" class="btn btn-outline-dark shadow-off">Check Status</a>
          </div>
        </div>

        <!-- col -->
        <div class="col-xl-5 d-xl-block d-none">
          <!-- form-container -->
          <div class="form-container" id="form-container">
            <!-- header-form -->
            <form action="#" method="POST" class="header-form ml-auto" id="header-form">

              <!-- form-title -->
              <h2 class="form-title mb-2">Register Form For<br>Gramvaani</h2>

              <!-- inputs -->
              <div class="inputs">

                <!-- form-label -->
                <label for="email" class="form-label">
                  <input type="email" name="email" class="glassy" id="email" placeholder="Email address" autocomplete="off" required>
                </label>

                <!-- form-label -->
                <label for="password" class="form-label">
                  <input type="password" name="password" class="glassy" id="password" placeholder="Password" required>
                </label>

              </div>

              <!-- submit-button -->
              <button type="submit" class="btn btn-fill-success shadow-off w-100 font-500 mb-2 mt-1">Register</button>

              <!-- hr -->
              <div class="hr position-relative"><span>Or sign up with</span></div>

              <!-- links -->
              <div class="row small-gutters mt-2">

                <!-- col -->
                <div class="col-6">
                  <a href="#" class="btn btn-outline-dark level-up shadow-off w-100 font-500"><img data-src="assets/images/icons/google.svg" class="lazy btn-icon img-fluid" alt="Google">Google</a>
                </div>

                <!-- col -->
                <div class="col-6">
                  <a href="#" class="btn btn-outline-dark level-up shadow-off w-100 font-500"><img data-src="https://cdn.pixabay.com/photo/2017/07/03/15/20/mobile-2468068_640.png" class="lazy btn-icon img-fluid" alt="Google">Phone</a>
                </div>

              </div>

              <!-- form-comment -->
              <div class="form-comment mt-2">The platform will generate performance reports, showing metrics like resolution time, the number of complaints, and unresolved grievances. This helps in monitoring government performance.<a href="#">Terms and conditions</a>.</div>

            </form>
          </div>
        </div>

      </div>
    </div>
  </header>

  <!-- Section I -->
  <div class="se-i text-lg-left text-center">
    <div class="container">
      <!-- row -->
      <div class="row">
        <!-- col -->
        <div class="col-lg-3 col-6 mb-lg-0 mb-2">
          <!-- box -->
          <div class="box">
            <h2 id="number">8200+</h2>
            <h2 class="box-title mb-0">Appication accepted</h2>
          </div>
        </div>

        <!-- col -->
        <div class="col-lg-3 col-6 mb-lg-0 mb-2">
          <!-- box -->
          <div class="box">
            <h2 id="number">8000+</h2>
            <h2 class="box-title mb-0">Appication resolved</h2>
          </div>
        </div>

        <!-- col -->
        <div class="col-lg-3 col-6">
          <!-- box -->
          <div class="box">
            <h2 id="number">200+</h2>
            <h2 class="box-title mb-0">Appication pending</h2>
          </div>
        </div>

        <!-- col -->
        <div class="col-lg-3 col-6">
          <!-- box -->
          <div class="box">
            <h2 id="number">2000+</h2>
            <h2 class="box-title mb-0">Feedback recieved</h2>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Section II -->
  <div class="se-ii bg-2">
    <div class="container">
      <!-- row -->
      <div class="row align-items-center">
        <!-- col -->
        <div class="col-xl-4 col-12 text-xl-left text-center mb-xl-0 mb-5">
          <!-- title-1 -->
          <h3 class="mb-1">
            <span >A digital platform</span><br class="d-xl-block d-none">
            <span>That allows villagers to report</span><br class="d-xl-block d-none">
            <!-- <span>Management.</span><br> -->
            <span class="primary-color"> Grievances.</span>
          </h3>
          <!-- para-1 -->
          <p class="para-1 mb-0">Villagers can track the status of their complaint in real time.</p>
        </div>
        <!-- col -->
        <div class="col-xl-8 col-12">
          <!-- row -->
          <div class="row justify-content-center">
            <!-- col -->
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/complaints.png" class="lazy img-fluid" alt="complaints">
                <h3 class="text mb-0">Raise Your complaints</h3>
              </div>
            </div>
            <!-- col -->
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/search.png" class="lazy img-fluid" alt="status">
                <h3 class="text mb-0">Track Your Application</h3>
              </div>
            </div>
            <!-- col -->
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/website.png" class="lazy img-fluid" alt="Gweb">
                <h3 class="text mb-0">e-Govt Websites</h3>
              </div>
            </div>
            <!-- col -->
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/apps.png" class="lazy img-fluid" alt="Gapps">
                <h3 class="text mb-0">Government Apps</h3>
              </div>
            </div>
            <!-- col -->
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/browser.png" class="lazy img-fluid" alt="Tweb">
                <h3 class="text mb-0">Technical websites</h3>
              </div>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
              <!-- item -->
              <div class="item text-center">
                <img data-src="images/calendar.png" class="lazy img-fluid" alt="complaints">
                <h3 class="text mb-0">Government Holidays</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Section III -->
  <div class="se-iii py-90">
    <div class="container">
      <!-- se-head -->
      <div class="se-head">
        <h3 class="se-title-1">What is Your Issue</h3>
        <h4 class="se-title-2">Raise The complaint With The</h4>
      </div>
      <!-- plans -->
      <div class="plans mb-xl-4 mb-2">
        <!-- row -->
        <div class="row mx-xl-0">
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan">

              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Electricity Issues</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Power Outages</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Voltage fluctuations</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Fault transformers</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">streetlight malfunction</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Water shortages</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Contaminated water supply</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Broken water pipes</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Improper drainage systems</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Road and Transpottation</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Potholes and damaged roads</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Lack of Proper Roads </li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Poor Public Transportation</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Bridge and culvert damage</li>
                </ul>
              </div>
            </div>
          </div>
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan popular-plan">
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Public Health</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Lack of Medical Fecilities</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Improper Waste management</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unhygienic conditions in public places</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Vector-borne diseases</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Sanitation</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Open defecation issues</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Improper toilet facilities</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Garbage collection problems</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Sewage leakage</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Education</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Poor infrastructure in schools</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Lack of teachers</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">School facility maintenance</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unavailability of learning materials</li>
                </ul>
              </div>
            </div>
          </div>
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan">
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Agricultural Concerns</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Lack of irrigation facilities</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Issues with government subsidies</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Unavailability of fertilizers and seeds</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Crop insurance problems</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Welfare Schemes</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Delays in pension payments</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Issues with ration cards</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Problems with government Welfare distribution</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Non-disbursement of subsidies or grants</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Law and Order</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Safety Concerns</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Illigal activities</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Police inaction</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Domestic voilence</li>
                </ul>
              </div>
            </div>
          </div>
          <!-- col -->
          <div class="col-xl-3 col-md-6 mb-xl-0 mb-2 px-xl-0">
            <!-- plan -->
            <div class="plan">
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Environmental Issues</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Deforestation</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Pollution in rivers or lakes</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Wild animal encroachments</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon"> Illegal sand mining</span></li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Housing and Shelter</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Issues with government housing schemes</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Dilapidated housing conditions</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Rehabilitation for displaced villagers</li>
                </ul>
              </div>
              <!-- group -->
              <div class="group">
                <!-- title-4 -->
                <h4 class="title-4">Public Works</h4>
                <!-- list -->
                <ul class="list list-unstyled">
                <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Delayed or unfinished public construction projects</li>
                  <li><img data-src="assets/images/pages/shared-hosting/check-circle.svg" class="lazy img-fluid" alt="Icon">Poor maintenance of public facilities (community centers, playgrounds)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- se-footer -->
      <div class="se-footer d-flex align-items-center justify-content-center flex-wrap">
        <!-- line -->
        <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Complaint Submission</span>
        </div>
         <!-- line -->
         <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Complaint Forwarded to Authorities</span>
        </div>
         <!-- line -->
         <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Authorities Review Complaint</span>
        </div>
        <!-- line -->
        <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Complaint Status Tracking</span>
        </div>
        <!-- line -->
        <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Grievance Resolved .</span>
        </div>
      </div>
    </div>
  </div>

  <!-- Section IV -->
  <div class="se-iv py-90 bg-2">
    <div class="container">
      <!-- se-head -->
      <div class="se-head">
        <!-- <h3 class="se-title-1">More than just a tool</h3> -->
        <h4 class="se-title-2">Benefits of the Grievance Redressal System:</h4>
      </div>
      <!-- space -->
      <div class="space space-sm"></div>
      <!-- row -->
      <div class="row justify-content-center">
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-1">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/accessability.png" class="lazy img-fluid" alt="accessibility">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Accessibility </h4>
            <!-- box-para -->
            <p class="box-para">Villagers can submit complaints from anywhere, reducing the need for physical visits.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-2">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/accountability.png" class="lazy img-fluid" alt="accountability">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Accountability</h4>
            <!-- box-para -->
            <p class="box-para">Government departments are held accountable with automated tracking and monitoring.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-3">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/efficiency.png" class="lazy img-fluid" alt="efficiency">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Efficiency</h4>
            <!-- box-para -->
            <p class="box-para">Faster processing of grievances ensures timely resolution of issues.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-4">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/Empowerment.png" class="lazy img-fluid" alt="empowerment">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Empowerment</h4>
            <!-- box-para -->
            <p class="box-para">The system empowers villagers by giving them a voice in local governance.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-5">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/resolution.png" class="lazy img-fluid" alt="faster-issue-resolution">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Faster Issue Resolution</h4>
            <!-- box-para -->
            <p class="box-para">A formal system streamlines the process of handling grievances, which can lead to quicker resolutions compared to informal methods.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-2">
          <!-- box -->
          <div class="box color-6">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/transparency.png" class="lazy img-fluid" alt="transparency">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Transparency</h4>
            <!-- box-para -->
            <p class="box-para"> A well-defined GRS makes the process of handling grievances clear and transparent, reducing the potential for favoritism or unfair treatment</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-lg-0 mb-2">
          <!-- box -->
          <div class="box color-1">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/communication.png" class="lazy img-fluid" alt="communication">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Communication</h4>
            <!-- box-para -->
            <p class="box-para">Encourages open communication between parties, which can lead to better understanding and problem-solving.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-4 col-md-6 mb-lg-0 mb-2">
          <!-- box -->
          <div class="box color-1">
            <!-- link -->
            <!-- <a href="#" class="box-link"></a> -->
            <!-- icon -->
            <div class="icon">
              <img data-src="images/compliance.png" class="lazy img-fluid" alt="communication">
            </div>
            <!-- box-title -->
            <h4 class="box-title">Legal Compliance</h4>
            <!-- box-para -->
            <p class="box-para">Helps organizations adhere to labor laws and regulations that require grievance mechanisms.</p>
            <!-- arrow -->
            <!-- <div class="arrow text-right">
              <img data-src="assets/images/icons/right-arrow.svg" class="lazy img-fluid" alt="Right-Arrow">
            </div> -->
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Section V
  <div class="se-v py-90">
    <div class="container">
      se-head
      <div class="se-head">
        <h3 class="se-title-1">Let's get to the juicy deets</h3>
        <h4 class="se-title-2">Compare HostX VPS Plans and Support Services</h4>
      </div>
      <!-- space -->
      <!-- <div class="space space-sm"></div> -->
      <!-- filter-nav -->
      <!-- <div class="filter-nav" id="filter-nav-v"> -->
        <!-- row -->
        <!-- <div class="row justify-content-center"> -->
          <!-- col -->
          <!-- <div class="col-xl-2 col-lg-3 col-md-4 col-6 mb-xl-0 mb-2"> -->
            <!-- tab -->
            <!-- <div class="tab active" data-filter="hardware">Hardware</div> -->
          <!-- </div> -->
          <!-- col -->
          <!-- <div class="col-xl-2 col-lg-3 col-md-4 col-6 mb-xl-0 mb-2"> -->
            <!-- tab -->
            <!-- <div class="tab tr-hide" data-filter="features">VPS Features</div> -->
          <!-- </div> -->
          <!-- col -->
          <!-- <div class="col-xl-2 col-lg-3 col-md-4 col-6 mb-xl-0 mb-2"> -->
            <!-- tab -->
            <!-- <div class="tab" data-filter="email">Email</div> -->
          <!-- </div> -->
          <!-- col -->
          <!-- <div class="col-xl-2 col-lg-3 col-md-4 col-6 mb-md-0 mb-2"> -->
            <!-- <div class="tab" data-filter="security">Security</div> -->
            <!-- tab -->
          <!-- </div> -->
          <!-- col -->
          <!-- <div class="col-xl-2 col-lg-3 col-md-4 col-6"> -->
            <!-- tab -->
            <!-- <div class="tab" data-filter="network">Network</div> -->
          <!-- </div> -->
          <!-- col -->
          <!-- <div class="col-xl-2 col-lg-3 col-md-4 col-6"> -->
            <!-- tab -->
            <!-- <div class="tab" data-filter="support">Support</div> -->
          <!-- </div> -->
        <!-- </div> -->
      <!-- </div> -->
      <!-- compare-table -->
      <!-- <div class="compare-table-container mb-4"> -->
        <!-- custom-thead -->
        <!-- <div class="custom-thead" id="custom-thead-v"> -->
          <!-- tabs -->
          <!-- <div class="tabs d-flex align-items-center justify-content-start"> -->
            <!-- <div class="tab active flex-grow-1" data-filter="self">Self Managed</div> -->
            <!-- <div class="tab flex-grow-1" data-filter="full">Fully Managed</div> -->
          <!-- </div> -->
          <!-- tab-content -->
          <!-- <div class="tab-content" data-for="self"> -->
            <!-- row -->
            <!-- <div class="row align-items-center"> -->
              <!-- col -->
              <!-- <div class="col-md-6 mb-md-0 mb-2 text-md-left text-center">/ -->
                <!-- table-title-4 -->
                <!-- <span class="table-title-4">As low as</span> -->
                <!-- table-title-1 -->
                <!-- <span class="table-title-1"><span class="coin">$</span>19.99<span class="sm-text">/mo</span></span> -->
              <!-- </div> -->
              <!-- col -->
              <!-- <div class="col-md-6 text-md-left text-center"> -->
                <!-- btn -->
                <!-- <a href="vps.php" class="btn btn-fill-primary btn-sm font-500 shadow-off">See Plans &amp; Pricing </a> -->
              <!-- </div> -->
            <!-- </div> -->
          <!-- </div> -->
          <!-- <div class="tab-content content-hide" data-for="full"> -->
            <!-- row -->
            <!-- <div class="row align-items-center"> -->
              <!-- col -->
              <!-- <div class="col-md-6 mb-md-0 mb-2 text-md-left text-center"> -->
                <!-- table-title-4 -->
                <!-- <span class="table-title-4">As low as</span> -->
                <!-- table-title-1 -->
                <!-- <span class="table-title-1"><span class="coin">$</span>29.99<span class="sm-text">/mo</span></span> -->
              <!-- </div> -->
              <!-- col -->
              <!-- <div class="col-md-6 text-md-left text-center"> -->
                <!-- btn -->
                <!-- <a href="vps.php" class="btn btn-fill-primary btn-sm font-500 shadow-off">See Plans &amp; Pricing </a> -->
              <!-- </div> -->
            <!-- </div> -->
          <!-- </div> -->
        <!-- </div> -->
        <!-- compare-table -->
        <!-- <table class="compare-table" id="compare-table-v"> -->
          <!-- thead -->
          <!-- <thead> -->
            <!-- <tr> -->
              <!-- top-left-corner -->
              <!-- <th class="top-left-corner"> -->
                <!-- table-title-head -->
                <!-- <span class="table-title-head">Swipe to<br>check plans <span>&rightarrow;</span></span> -->
              <!-- </th> -->
              <!-- top-right-corner -->
              <!-- <th class="top-right-corner"> -->
                <!-- table-title-3 -->
                <!-- <span class="table-title-3">Self Managed</span> -->
                <!-- price -->
                <!-- <div class="price"> -->
                  <!-- table-title-4 -->
                  <!-- <span class="table-title-4">As low as</span> -->
                  <!-- table-title-1 -->
                  <!-- <span class="table-title-1"><span class="coin">$</span>19.99<span class="sm-text">/mo</span></span> -->
                <!-- </div> -->
                <!-- btn -->
                <!-- <a href="#" class="btn btn-fill-primary btn-sm font-500 shadow-off">See Plans &amp; Pricing </a> -->
              <!-- </th> -->
              <!-- top-right-corner -->
              <!-- <th class="top-right-corner"> -->
                <!-- table-title-3 -->
                <!-- <span class="table-title-3">Fully Managed</span> -->
                <!-- price -->
                <!-- <div class="price"> -->
                  <!-- table-title-4 -->
                  <!-- <span class="table-title-4">As low as</span> -->
                  <!-- table-title-1 -->
                  <!-- <span class="table-title-1"><span class="coin">$</span>29.99<span class="sm-text">/mo</span></span> -->
                <!-- </div> -->
                <!-- btn -->
                <!-- <a href="#" class="btn btn-fill-primary btn-sm font-500 shadow-off">See Plans &amp; Pricing </a> -->
              <!-- </th> -->
            <!-- </tr> -->
          <!-- </thead> -->
          <!-- tbody -->
          <!-- <tbody> -->
            <!-- <tr class="hovered"> -->
              <!-- <td class="left-corner"></td> -->
              <!-- <td class="right-corner" data-for="self">For experienced users that want full control over their server.</td> -->
              <!-- <td class="right-corner td-hide" data-for="full">For those that don’t have the time or advanced server skills.</td> -->
            <!-- </tr> -->
            <!-- hardware -->
            <!-- <tr data-filter="hardware"> -->
              <!-- <td class="left-corner">vCPU</td> -->
              <!-- <td class="right-corner" data-for="self">2 Cores</td> -->
              <!-- <td class="right-corner td-hide" data-for="full">4 Cores</td> -->
            <!-- </tr> -->
            <!-- <tr data-filter="hardware"> -->
              <!-- <td class="left-corner">Performance / RAM</td> -->
              <!-- <td class="right-corner" data-for="self">1 – 32 GB RAM</td> -->
              <!-- <td class="right-corner td-hide" data-for="full">2 – 32 GB RAM</td> -->
            <!-- </tr> -->
            <!-- <tr data-filter="hardware"> -->
              <!-- <td class="left-corner">Storage</td> -->
              <!-- <td class="right-corner" data-for="self">120 GB SSD</td> -->
              <!-- <td class="right-corner td-hide" data-for="full">240 GB SSD</td> -->
            <!-- </tr> -->
            <!-- <tr data-filter="hardware"> -->
              <!-- <td class="left-corner">Bandwidth</td> -->
              <!-- <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td> -->
              <!-- <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td> -->
            <!-- </tr> -->
            <!-- <tr data-filter="hardware"> -->
              <!-- <td class="left-corner">Dedicated IP</td> -->
              <!-- <td class="right-corner" data-for="self">2 IPs</td> -->
              <!-- <td class="right-corner td-hide" data-for="full">2 IPs</td> -->
            <!-- </tr> -->
            <!-- <tr data-filter="hardware"> -->
              <!-- <td class="left-corner">Additional dedicated IP options</td> -->
              <!-- <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td> -->
              <!-- <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td> -->
            <!-- </tr> -->
            <!-- <tr data-filter="hardware"> -->
              <!-- <td class="left-corner">CPU, RAM, disk & uptime</td> -->
              <!-- <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td> -->
              <!-- <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td> -->
            <!-- </tr> -->
            <!-- <tr data-filter="hardware"> -->
              <!-- <td class="left-corner">Services monitoring</td> -->
              <!-- <td class="right-corner" data-for="self">-</td> -->
              <!-- <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td> -->
            <!-- </tr> -->
            <!-- <tr data-filter="hardware">
              <td class="left-corner">Proactive remediation</td>
              <td class="right-corner" data-for="self">-</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- features -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Root access</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">cPanel/WHM</td>
              <td class="right-corner" data-for="self">Optional</td>
              <td class="right-corner td-hide" data-for="full">Optional</td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Operating Systems</td>
              <td class="right-corner" data-for="self">CentOS, Ubuntu or Windows Server</td>
              <td class="right-corner td-hide" data-for="full">CentOS or Windows Server</td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Softaculous script installer</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">LetsEncrypt SSL included</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Unlimited email accounts</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Free content transfers</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Network guarantee</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">MySQL</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Monitoring and alerts</td>
              <td class="right-corner" data-for="self">5-minute intervals</td>
              <td class="right-corner td-hide" data-for="full">1-minute interval</td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Standard Hosting phone support</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Comprehensive help/how-to video library and technical blogs</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Community peer-to-peer advice</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Dedicated services team - (control panel recommended)</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full">Unlimited service requests.</td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Content migration</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full">5 free site migrations, ‪70%‬ discount off service fee for additional site migrations.</td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Server setup</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">DNS setup and configuration</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">SSL installation</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">HTTP/2 server configuration</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">SQL Server Express install</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Package management</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Email client setup</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">PHP module install/upgrade</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">MySQL optimization</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">WordPress setup</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Disk space audit</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Firewall rules configuration</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="features" class="tr-hide">
              <td class="left-corner">Call for custom service request</td>
              <td class="right-corner" data-for="self">Paid option</td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- email -->
            <!-- <tr data-filter="email" class="tr-hide">
              <td class="left-corner">Maximum outgoing emails</td>
              <td class="right-corner" data-for="self">Unlimited</td>
              <td class="right-corner td-hide" data-for="full">Unlimited</td>
            </tr>
            <tr data-filter="email" class="tr-hide">
              <td class="left-corner">Maximum POP/IMAP connections</td>
              <td class="right-corner" data-for="self">Unlimited</td>
              <td class="right-corner td-hide" data-for="full">Unlimited</td>
            </tr> -->
            <!-- security -->
            <!-- <tr data-filter="security" class="tr-hide">
              <td class="left-corner">Centralized DDoS Protection</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="security" class="tr-hide">
              <td class="left-corner">Weekly offsite backups</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="security" class="tr-hide">
              <td class="left-corner">Create manual backups</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="security" class="tr-hide">
              <td class="left-corner">Create scheduled backups</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr> -->
            <!-- network -->
            <!-- <tr data-filter="network" class="tr-hide">
              <td class="left-corner">Network uptime guarantee</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="network" class="tr-hide">
              <td class="left-corner">US-based Data Centers</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="network" class="tr-hide">
              <td class="left-corner">Fully redundant network</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="network" class="tr-hide">
              <td class="left-corner">Multiple bandwidth providers</td>
              <td class="right-corner" data-for="self">AboveNet, AT&T, Comcast, Global crossing, Level (3), NTT</td>
              <td class="right-corner td-hide" data-for="full">AboveNet, AT&T, Comcast, Global crossing, Level (3), NTT</td>
            </tr> -->
            <!-- support -->
            <!-- <tr data-filter="support" class="tr-hide">
              <td class="left-corner">Premium support</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
            <tr data-filter="support" class="tr-hide">
              <td class="left-corner">Server monitoring and remediation</td>
              <td class="right-corner" data-for="self"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
              <td class="right-corner td-hide" data-for="full"><img data-src="assets/images/icons/check.svg" class="lazy check-icon img-fluid" alt="Check"></td>
            </tr>
          </tbody>
        </table>
      </div> -->
      <!-- se-footer -->
      <!-- <div class="se-footer d-flex align-items-center justify-content-center flex-wrap">
        line -->
        <!-- <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Backups monthly</span>
        </div> -->
        <!-- line -->
        <!-- <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Free white-glove migrations</span>
        </div> -->
        <!-- line -->
        <!-- <div class="line d-flex align-items-center justify-content-start">
          <img data-src="assets/images/icons/check-circle.svg" class="lazy icon img-fluid" alt="Check">
          <span class="text">Staging environments, and more.</span>
        </div>
      </div>
    </div>
  </div> -->

  <!-- Section VI -->
  <div class="se-vi py-90 bg-2">
    <div class="container">
      <!-- se-head -->
      <div class="se-head">
        <h3 class="se-title-1">Happy Peoples!</h3>
        <h4 class="se-title-2">What Happy Peoples Have to Say?</h4>
      </div>
      <!-- space -->
      <div class="space space-sm"></div>
      <!-- row -->
      <div class="row">
        <!-- col -->
        <div class="col-xl-3 col-lg-6">
          <!-- row -->
          <div class="row">
            <!-- col -->
            <div class="col-12">
              <!-- box -->
              <div class="box">
                <!-- user-info -->
                <div class="user-info">
                  <img data-src="images/image.png" class="lazy avatar img-fluid" alt="Avatar">
                  <div class="name">Umakanth K</div>
                  <div class="job">Public</div>
                </div>
                <!-- quotes -->
                <p class="quotes"> The website is straightforward and simple to navigate, making it easy to submit and track grievances.</p>
              </div>
            </div>
          </div>
        </div>
        
        <!-- col -->
        <div class="col-xl-3 col-lg-6">
          <!-- row -->
          <div class="row">
            <!-- col -->
            <div class="col-12">
              <!-- box -->
              <div class="box">
                <!-- user-info -->
                <div class="user-info">
                  <img data-src="images/image.png" class="lazy avatar img-fluid" alt="Avatar">
                  <div class="name">Rajkumar B</div>
                  <div class="job">Youth Leader</div>
                </div>
                <!-- quotes -->
                <p class="quotes">The website is user-friendly and easy to navigate, which is great for quickly filing and tracking grievances.</p>
              </div>
            </div>
          </div>
        </div>
        <!-- col -->
        <div class="col-xl-3 col-lg-6">
          <!-- row -->
          <div class="row">
            <!-- col -->
            <div class="col-12">
              <!-- box -->
              <div class="box">
                <!-- user-info -->
                <div class="user-info">
                  <img data-src="images/image.png" class="lazy avatar img-fluid" alt="Avatar">
                  <div class="name">Sanjay Kumar</div>
                  <div class="job">Teacher</div>
                </div>
                <!-- quotes -->
                <p class="quotes">The status updates on grievances are clear and timely, which helps in tracking progress effectively.</p>
              </div>
            </div>
          </div>
        </div>
            <div class="col-xl-3 col-lg-6">
            <div class="row">
            <!-- col -->
            <div class="col-12">
              
              <!-- box -->
              <div class="box">
                <!-- user-info -->
                <div class="user-info">
                  <img data-src="images/image.png" class="lazy avatar img-fluid" alt="Avatar">
                  <div class="name">Shankar</div>
                  <div class="job">Former</div>
                </div>
                <!-- quotes -->
                <p class="quotes">The system is easy to navigate and intuitive, which makes filing grievances straightforward.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- space -->
      <div class="space space-sm"></div>
      <!-- buttons -->
      <div class="buttons text-center">
        <a href="#" class="btn btn-fill-primary shadow-off">See All Testimonials</a>
      </div>
    </div>
  </div>

<?php
  // FAQs
  include 'templates/faqs.inc.php';
  // Footer
  include 'templates/footer.inc.php';
?>
