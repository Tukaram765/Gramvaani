<?php
include 'connection.inc.php';

$sql = "CREATE TABLE IF NOT EXISTS Users (
user_id BIGINT(12) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
username VARCHAR(30) NOT NULL,
email VARCHAR(30) NOT NULL,
phone VARCHAR(50),
pass varchar(20),
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
)";
if ($conn->query($sql) === TRUE) {
  echo "Table 'users' created successfully.";
} else {
  echo "Error creating table: " . $conn->error;
}


if($_SERVER['REQUEST_METHOD']=='POST'){
  $username = $conn->real_escape_string($_POST['username']);
  $email  = $conn->real_escape_string($_POST['email']);
  $phone = $conn->real_escape_string($_POST['phone']);
  $pass = password_hash($_POST['pass'],PASSWORD_BCRYPT);


  $check_user = $conn->query("select * from `users` where `username`='$username' OR `phone`='$phone'");
  
  if($check_user->num_rows>0){
    echo "<script type ='text/javascript'>alert('user already exists!');</script>";

  }else{
    $sql= ("INSERT INTO `users`(`username`, `email`, `phone`, `pass`) VALUES ('$username','$email','$phone','$pass')");
  
    if($conn->query($sql)==true){
      echo "<script type='text/javascript'>alert('Registration successfull!');</script>";
      
    }else{
      echo "error".$conn->error;
    }

    function generateUniqueNumber() {
      return mt_rand(100000000000, 999999999999);
  }
  
  function isNumberUnique($conn, $uniqueNumber) {
      $sql = "SELECT COUNT(*) FROM numbers WHERE unique_number = :unique_number";
      $stmt = $conn->prepare($sql);
      $stmt->execute(['unique_number' => $uniqueNumber]);
      return $stmt->fetchColumn() == 0;
  }
  
  function insertUniqueNumber($conn) {
      do {
          $uniqueNumber = generateUniqueNumber();
      } while (!isNumberUnique($conn, $uniqueNumber));
  
      $sql = "INSERT INTO numbers (unique_number) VALUES (:unique_number)";
      $stmt = $conn->prepare($sql);
      $stmt->execute(['unique_number' => $uniqueNumber]);
  
      echo "The unique 12-digit number $uniqueNumber has been inserted into the database.<br>";
  }
  insertUniqueNumber($conn);
  }
}

?>



