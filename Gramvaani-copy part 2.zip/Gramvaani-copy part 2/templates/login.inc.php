
<?php
session_start();
include '../templates/connection.inc.php';

if($_SERVER['REQUEST_METHOD']=='POST'){
 $phone = $conn->real_escape_string($_POST['phone']);
echo $pass = $conn->real_escape_string($_POST['pass']);


  $result = $conn->query("SELECT * FROM `users` WHERE `phone`='$phone' OR `pass`='$pass'");
  if($result){
    while($user= $result->fetch_assoc()){

    echo $dpass = $user['pass'];
      $_SESSION['phone'] = $user['phone'];
    }
  

      if( $pass == $dpass){
        echo "<script type ='text/javascript'>alert('Login Successfull!');</script>";
        header("Location:../admin/pages/user_dashboard.php");
        
        
          // }
        
        
      }else{
        echo "<script type ='text/javascript'>alert('Invalid password!');</script>";
      }
        
      }

    }
   


    

$conn->close();

?>