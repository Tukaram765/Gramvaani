<!-- Preloader -->
<div class="preloader" id="preloader">
  <div class="content d-flex align-items-center justify-content-center">
    <div class="spinner"></div>
  </div>
</div>