<!-- FAQs -->
<div class="faqs py-90" id="faqs">
  <div class="container">
    <!-- se-head -->
    <div class="se-head">
      <h3 class="se-title-1">FAQS</h3>
      <h4 class="se-title-2">Got questions?<br>Well, we've got answers.</h4>
    </div>
    <!-- space -->
    <div class="space space-sm"></div>
    <!-- row -->
    <div class="row">
      <!-- col -->
      <div class="col-xl-4 pr-xl-3 mb-xl-0 mb-2">
        <!-- category -->
        <div class="category" id="faqs-category">
          <!-- item -->
          <div class="item active" data-category="general">
            <img src="images/general.png" class="icon img-fluid" alt="Icon">
            <div class="text">
              <h5 class="item-title">General inquiries</h5>
              <p class="item-des">I hope these questions finds you well.</p>
            </div>
          </div>
          <!-- item -->
          <div class="item" data-category="features">
            <img src="images/report.png" class="icon img-fluid" alt="Icon">
            <div class="text">
              <h5 class="item-title">Reporting a Grievance</h5>
              <p class="item-des">I would appreciate it if this matter could be investigated and addressed accordingly.</p>
            </div>
          </div>
          <!-- item -->
          <div class="item" data-category="privacy">
            <img src="images/feedback.png" class="icon img-fluid" alt="Icon">
            <div class="text">
              <h5 class="item-title">Feedback and Resolution</h5>
              <p class="item-des">Once the issue is resolved, the user can provide feedback on the resolution.</p>
            </div>
          </div>
          <!-- item -->
          <div class="item" data-category="pricing">
            <img src="images/tracking.png" class="icon img-fluid" alt="Icon">
            <div class="text">
              <h5 class="item-title">Tracking Complaints</h5>
              <p class="item-des">Each villager can view the current status of their complaints in real-time.</p>
            </div>
          </div>
        </div>
      </div>
      <!-- col -->
      <div class="col-xl-8">
        <!-- content -->
        <div class="content">
          <!-- box -->
          <div class="box category-general">
            <!-- box-head -->
            <div class="box-head">
              <img src="images/general.png" class="icon img-fluid" alt="Icon">
              <div class="text">
                <h5 class="box-title">General inquiries</h5>
                <p class="box-des">I hope these questions finds you well.</p>
              </div>
            </div>
            <!-- box-body -->
            <div class="box-body">
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">How do I register on the platform?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>To register, click on "Register Now" and provide your mobile number. You’ll receive an OTP to verify your identity. Complete the registration by filling in basic information such as your name, village, and contact details.</p>
                </div>
              </div>
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">Is the platform available in my language?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>Yes, the platform supports multiple languages. You can choose your preferred language, such as English, Kannada, Hindi, and more, from the language selector.</p>
                </div>
              </div>
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">Is there a mobile app for this platform?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>Yes, the platform is available as a mobile app for both Android and iOS devices, allowing you to report and track complaints on the go.</p>
                </div>
              </div>
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">Who can I contact for additional support?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p> If you need further assistance, visit the “Contact Us” section to get in touch with our support team via phone or email.</p>
                </div>
              </div>
              <!-- q -->
            </div>
          </div>
          <!-- box -->
          <div class="box category-features">
            <!-- box-head -->
            <div class="box-head">
              <img src="images/report.png" class="icon img-fluid" alt="Icon">
              <div class="text">
                <h5 class="box-title">Reporting a Grievance</h5>
                <p class="box-des">I would appreciate it if this matter could be investigated and addressed accordingly.</p>
              </div>
            </div>
            <!-- box-body -->
            <div class="box-body">
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">How do I report a grievance?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>To report a grievance, simply log in to the platform, click on "Raise an Issue," choose the problem category, provide a brief description of the issue, and attach any photos or videos if applicable.</p>
                </div>
              </div>
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">Can I report multiple grievances at once?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>Yes, you can submit multiple grievances, but each issue should be reported separately to ensure proper tracking and resolution.</p>
                </div>
              </div>
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">What kind of problems can I report?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>You can report various issues such as electricity outages, water shortages, road damage, sanitation problems, and more. Visit the "Problem Categories" section for a full list.</p>
                </div>
              </div>
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">Will my personal details be shared with authorities?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>No, your personal details remain confidential and are only used to communicate with you about your grievance.</p>
                </div>
              </div>
              <!-- q -->
            </div>
          </div>
          <!-- box -->
          <div class="box category-privacy">
            <!-- box-head -->
            <div class="box-head">
              <img src="images/feedback.png" class="icon img-fluid" alt="Icon">
              <div class="text">
                <h5 class="box-title">Feedback and Resolution</h5>
                <p class="box-des">Once the issue is resolved, the user can provide feedback on the resolution.</p>
              </div>
            </div>
            <!-- box-body -->
            <div class="box-body">
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">How do I provide feedback on a resolved complaint?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p> Once your issue is marked as “Resolved,” you will receive a notification to rate the resolution. You can leave your feedback and suggest improvements if necessary.</p>
                </div>
              </div>
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">What if my problem is not resolved satisfactorily?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p> If you're not satisfied with the resolution, you can reopen the complaint and provide additional details or escalate it to higher authorities for further review.</p>
                </div>
              </div>
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text"> How long does it take for a complaint to be resolved?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>The time varies depending on the complexity of the issue and the department responsible. However, you will receive updates at each stage of the process.</p>
                </div>
              </div>
            </div>
          </div>
          <!-- box -->
          <div class="box category-pricing">
            <!-- box-head -->
            <div class="box-head">
              <img src="images/tracking.png" class="icon img-fluid" alt="Icon">
              <div class="text">
                <h5 class="box-title">Tracking Complaints</h5>
                <p class="box-des">Each villager can view the current status of their complaints in real-time.</p>
              </div>
            </div>
            <!-- box-body -->
            <div class="box-body">
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">How can I check the status of my complaint?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>After logging in, go to the "My Complaints" section, where you can see the current status of all your submitted grievances, along with any updates from the authorities.</p>
                </div>
              </div>
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text">What do the different status terms mean?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>Pending: Your complaint has been submitted and is awaiting action.
In Progress: Authorities are currently working on resolving your issue.
Resolved: Your complaint has been addressed and closed.
Closed: Your grievance has been closed, but may not have been resolved.</p>
                </div>
              </div>
              <!-- q -->
              <div class="q">
                <!-- q-h -->
                <div class="q-h">
                  <!-- text -->
                  <h4 class="text"> Can I cancel a complaint after submission?</h4>
                  <!-- plus -->
                  <div class="plus">
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <!-- q-b -->
                <div class="q-b">
                  <p>Once a complaint is submitted, it cannot be canceled, but you can update the authorities with new information or corrections via the “Update Complaint” feature.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>