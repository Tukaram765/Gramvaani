<?php
session_start();
ob_start();
?>
<?php if (isset($__hide_header) && $__hide_header == 'false' || !isset($__hide_header)) : ?>
<nav class="theme-navbar" id="theme-navbar">
  <div class="container-fluid">
    <!-- nav-top -->
    <div class="nav-top d-flex align-items-center">
      <!-- menu-icon -->
      <div class="menu-icon" id="open-links-btn">
      <img src="assets/images/templates/navbar/hamburger.png" class="menu-icon img-fluid" alt="HostX">
      </div>
      <!-- brand -->
      <a href="#" class="brand d-flex align-items-center">
      <img src="images/g_logow.png" class="dt-img img-fluid" alt="Gramvaani">
        <img src="images/g_logo.png" class="lt-img img-fluid" alt="Gramvaani">
      </a>
      <!-- options -->
      <div class="options d-md-flex d-none align-items-center justify-content-end ml-auto">
        <!-- buttons -->
        <div class="buttons">
          <a href="register.php" class="btn btn-outline-dark btn-sm btn-rounded shadow-off text-uppercase">Register</a>
        </div>
        <!-- lang -->
        <div class="lang" id="lang">
          <!-- current -->
          <div class="current cate-title">Language
            <img src="assets/images/icons/outline-font-icons/fi-rr-angle-small-down.svg" class="img-fluid" alt="Icon">
          </div>
          <!-- lang-menu -->
          <div class="lang-menu" id="lang-menu">
            <a href="#" class="lang-item active">English</a>
            <a href="#" class="lang-item" onclick="changeLanguage('kn')">ಕನ್ನಡ</a>
            <a href="#" class="lang-item" onclick="changeLanguage('hi')">हिंदी</a>
          </div>
        </div>
      </div>
      <!-- second-options -->
      <div class="second-options d-md-none d-flex align-content-center justify-content-end ml-auto">
        <!-- o-link -->
        <a href="kb.php" class="o-link">
          <img src="assets/images/templates/navbar/question-mark.png" class="icon" alt="Icon">
        </a>
        <!-- o-link -->
        <div class="o-link user-link" id="user-menu-btn">
          <img src="assets/images/templates/navbar/profile.png" class="icon" alt="Icon">
          <!-- user-dropdown-menu -->
          <ul class="user-dropdown-menu list-unstyled" id="user-dropdown-menu">
          </ul>
        </div>
      </div>
    </div>
    <!-- nav-bottom -->
    <div class="nav-bottom d-flex align-items-center justify-content-between">
      <!-- info -->
      <div class="info d-flex align-items-center">
        <!-- item -->
        <a href="tel:0000" class="item">
          <img src="assets/images/icons/fill-font-icons/fi-sr-phone-call.svg" class="img-fluid" alt="Icon">
          <span class="text">+91 8050061666</span>
        </a>
      </div>
      <!-- links -->
      <div class="links d-xl-flex align-items-center ml-auto" id="theme-navbar-links">
        <!-- close-links-btn -->
        <div class="close-links-btn" id="close-links-btn">
          <img src="assets/images/templates/navbar/close.png" class="img-fluid" alt="Close">
        </div>
        <!-- link -->
        <div class="link active">
          <a href="./">Home</a>
        </div>
        <!-- link -->
        <div class="link">
          <a href="../../Gramvaani/admin/pages/complaint_formate.php">Raise a Complaint</a>
        </div>
        <!-- link -->
        <div class="link">
          <a href="../../Gramvaani/timeline/check_timeline.php">Track complaint</a>
        </div>
        <!-- link -->
        <div class="link">
          <a href="../../Gramvaani/feedback.php">Give Feedback</a>
        </div>
      
        <div class="link has-dropdown-menu">
          <a href="#">Login</a>
          <ul class="dropdown-menu list-unstyled">
            <li><a href="../../Gramvaani/admin_login.php" class="dm-link">Admin Login</a></li>
            <li><a href="../../Gramvaani/employee_login.php" class="dm-link">Employee Login</a></li>
            <li><a href="../../Gramvaani/login.php" class="dm-link">User Login</a></li>
          </ul>
        </div>
        <!-- link -->
        <!-- <div class="link has-dropdown-menu">
          <a href="#">Community Voices</a>
          <ul class="dropdown-menu list-unstyled">
            <li><a href="#" class="dm-link">Testimonials from Villagers</a></li>
            <li><a href="#" class="dm-link">Success Stories</a></li>
            <li><a href="#" class="dm-link">Featured Citizen Contributions</a></li>
          </ul>
        </div> -->
    
        <!-- indicator -->
        <span class="indicator"></span>
      </div>
      <!-- side-box-btn -->
      <div class="side-box-btn" id="side-box-btn">
          <span class="lines">
            <span></span>
            <span></span>
            <span></span>
          </span>Side Menu
      </div>
    </div>
    <!-- side-box -->
    <div class="side-box scroll-area" id="side-box">
      <!-- mega-menu -->
      <div class="mega-menu">
        <!-- f-nav -->
        <div class="f-nav d-flex align-items-center justify-content-start flex-wrap">
          <span class="f-nav-tab active" data-filter="all">All</span>
        </div>
        <!-- content -->
        <div class="content">
          <!-- f-area & all -->
          <div class="f-area all">
            <!-- apps -->
            <div class="apps mb-3">
              <!-- cate-title -->
              <h3 class="cate-title">Login</h3>
              <!-- boxes -->
              <div class="boxes">
                <!-- app-box -->
                <a href="../../Gramvaani/login.php" class="app-box">
                    <span class="frame">
                      <img src="images/user.png" class="img-fluid" alt="userlogin">
                    </span>
                  <span class="title">User Login</span>
                </a>
               <!--app-box -->
                <a href="#" class="app-box">
                    <span class="frame">
                      <img src="images/department.png" class="img-fluid" alt="Discord">
                    </span>
                  <span class="title">Department Login</span>
                </a>
                <!-- app-box-->
                <a href="../../Gramvaani/admin_login.php" class="app-box">
                    <span class="frame">
                      <img src="images/admin.png" class="img-fluid" alt="adminlogin">
                    </span>
                  <span class="title">Admin Login</span>
                </a>
                <!-- app-box -->
                <a href="../../Gramvaani/employee_login.php" class="app-box">
                    <span class="frame">
                      <img src="images/employee.png" class="img-fluid" alt="employeelogin">
                    </span>
                  <span class="title">Employee Login</span>
                </a>
              </div>
            </div>
            <!-- others -->
            <div class="others">
              <!-- cate-title -->
              <h3 class="cate-title">Recommended</h3>
              <!-- items -->
              <div class="items">
                <!-- item -->
                <a href="../../Gramvaani/admin/pages/complaint_formate.php" class="item">
                  <!-- icon -->
                  <img src="images/complaints.png" class="icon img-fluid" alt="Icon">
                  <!-- item-con -->
                  <span class="item-con">
                      <span class="name">Raise a Complaint</span>
                      <span class="des">Voice Your Concerns</span>
                    </span>
                </a>
                <!-- item -->
                <a href="../../Gramvaani/timeline/check_timeline.php" class="item">
                  <!-- icon -->
                  <img src="images/tracking.png" class="icon img-fluid" alt="Icon">
                  <!-- item-con -->
                  <span class="item-con">
                      <span class="name">Track The Complaint</span>
                      <span class="des">Stay Informed</span>
                    </span>
                </a>
                <!-- item -->
                <a href="../../Gramvaani/feedback.php" class="item">
                  <!-- icon -->
                  <img src="images/feedback.png" class="icon img-fluid" alt="Icon">
                  <!-- item-con -->
                  <span class="item-con">
                      <span class="name">Feedback</span>
                      <span class="des">Share Your Thoughts</span>
                    </span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- close-side-box-btn -->
      <div class="close-side-box-btn" id="close-side-box-btn">
        <img src="assets/images/templates/navbar/close.png" class="img-fluid" alt="Close">
      </div>
    </div>
  </div>
</nav>
<?php endif; ?>
