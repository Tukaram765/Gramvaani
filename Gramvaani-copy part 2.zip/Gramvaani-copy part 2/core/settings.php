<?php

  // Default title.
  $page_title = "Buy VPS Hosting | 7-Days Free Trial | HostX.com";
  /** ------------------------------------------------------------------ **/
  
  // Active theme [ Dark - Light ].
  $active_theme = 'Light';
  /** ------------------------------------------------------------------ **/  

  // Meta title.
  $meta_title = "HostX | HTML5 Hosting Template";
  /** ------------------------------------------------------------------ **/

  // Meta theme-color.
  $meta_theme_color = "#0060fe";
  /** ------------------------------------------------------------------ **/

  // Meta description.
  $meta_description = "Your all in one solution to grow online. Start a free trial to create a beautiful website, get a domain name, fast hosting, online marketing and award-winning 24/7 support.";
  /** ------------------------------------------------------------------ **/

  // Meta keywords.
  $meta_keywords = "Buy VPS, Buy VPS Hosting,Buy Cheap VPS, Free VPS, Trial VPS";
  /** ------------------------------------------------------------------ **/

?>