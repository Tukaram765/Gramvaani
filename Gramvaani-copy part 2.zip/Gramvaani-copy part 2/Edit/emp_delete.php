<?php
include '../templates/connection.inc.php';

if($emp_id = isset($_GET['emp_id'])) {
   $emp_id = $_GET['emp_id'];
    }


    $delete = $conn->query("DELETE FROM `employee` WHERE `emp_id`='$emp_id'");

    if($delete){
        echo "<script type='text/javascript'>
        alert('deleted successfull');
        function setTime() {
            window.location.href = '../List/list.php';
        }
        setTime(); // Call the function to redirect
    </script>";
        }else{
        echo "<script type='text/javascript'>
        alert('failed');
        function setTime() {
            window.location.href = '../List/list.php';
        }
        setTime(); 
    </script>";
    
    }


?>

