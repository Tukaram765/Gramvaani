<?php
include '../templates/connection.inc.php';

if($admin_id = isset($_GET['admin_id'])) {
   $admin_id = $_GET['admin_id'];
    }


    $delete = $conn->query("DELETE FROM `admin` WHERE `admin_id`='$admin_id'");

    if($delete){
        echo "<script type='text/javascript'>
        alert('deleted successfull');
        function setTime() {
            window.location.href = '../List/list.php';
        }
        setTime(); // Call the function to redirect
    </script>";
        }else{
        echo "<script type='text/javascript'>
        alert('failed');
        function setTime() {
            window.location.href = '../List/list.php';
        }
        setTime(); 
    </script>";
    
    }


?>

