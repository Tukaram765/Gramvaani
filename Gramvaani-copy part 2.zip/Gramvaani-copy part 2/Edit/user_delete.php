<?php
include '../templates/connection.inc.php';

if($user_id = isset($_GET['user_id'])) {
   $user_id = $_GET['user_id'];
    }


    $delete = $conn->query("DELETE FROM `users` WHERE `user_id`='$user_id'");

    if($delete){
        echo "<script type='text/javascript'>
        alert('deleted successfull');
        function setTime() {
            window.location.href = '../List/list.php';
        }
        setTime(); // Call the function to redirect
    </script>";
        }else{
            echo "<script type='text/javascript'>
            alert('failed');
            function setTime() {
                window.location.href = '../List/list.php';
            }
            setTime(); // Call the function to redirect
        </script>";
                
    }


?>

