<?php
include '../templates/connection.inc.php';

if($Dep_id = isset($_GET['Dep_id'])) {
   $Dep_id = $_GET['Dep_id'];
    }


    $delete = $conn->query("DELETE FROM `department` WHERE `Dep_id`='$Dep_id'");

    if($delete){
        echo "<script type='text/javascript'>
        alert('deleted successfull');
        function setTime() {
            window.location.href = '../admin/pages/department.php';
        }
        setTime(); // Call the function to redirect
    </script>";
        }else{
        echo "<script type='text/javascript'>
        alert('failed');
        function setTime() {
            window.location.href = '../admin/pages/department.php';
        }
        setTime(); 
    </script>";
    
    }


?>

